**Table 4. Robustness of the measured remodelling peak.**

| Analysis                      | Peak (pcw)   | Note                                                      |
|:------------------------------|:-------------|:----------------------------------------------------------|
| Primary (all dynamic CpGs)    | 15.36        | bootstrap median 15.11, 95% CI 13.86-16.61                |
| Equal donors per week         | 15.36        | n = 6 per week; rank correlation with primary rho = 1.000 |
| Leave one gestational bin out | 14.86-15.86  | range over 12 analyses                                    |
| Stratum: Island               | 15.36        | 12,062 CpGs                                               |
| Stratum: N_Shore              | 15.11        | 10,701 CpGs                                               |
| Stratum: S_Shore              | 15.11        | 8,215 CpGs                                                |
| Stratum: OpenSea              | 15.36        | 32,336 CpGs                                               |
| Stratum: TSS200               | 15.11        | 5,262 CpGs                                                |
| Stratum: TSS1500              | 15.36        | 10,102 CpGs                                               |
| Stratum: Body                 | 15.36        | 25,145 CpGs                                               |
| Stratum: Intergenic           | 15.36        | 19,983 CpGs                                               |
