**Table 1. Public datasets used, with the role of each in the analysis.**

| Dataset   | Reference          | Assay                                  | Tissue                               |   Samples | Age range (pcw)   | CpGs after QC   | Role                                     |
|:----------|:-------------------|:---------------------------------------|:-------------------------------------|----------:|:------------------|:----------------|:-----------------------------------------|
| GSE58885  | Spiers et al. 2015 | Illumina HumanMethylation450           | human fetal brain                    |       179 | 3.3-26.3          | 335178          | discovery: remodelling intensity         |
| GSE74193  | Jaffe et al. 2016  | Illumina HumanMethylation450           | human dorsolateral prefrontal cortex |        35 | 12.0-18.0         | 335178          | independent replication                  |
| BrainSpan | Kang et al. 2011   | RNA-seq (GENCODE v10, gene-level RPKM) | human neocortex                      |       162 | 8-37              | n/a (99 genes)  | proliferation and machinery trajectories |
