**Table 6. Sensitivity of the permanence window to assumptions about the unmeasured third trimester.**

| Scenario         |   Global peak (pcw) | 95% CI      |   P(peak after 20 pcw) |   Draws with a late local maximum |
|:-----------------|--------------------:|:------------|-----------------------:|----------------------------------:|
| measured decline |              16.880 | 15.84-17.96 |                  0.000 |                             0.530 |
| slow decline     |              16.900 | 15.78-17.94 |                  0.000 |                             0.530 |
| plateau          |              16.910 | 15.80-36.00 |                  0.044 |                             0.190 |
| late rise        |              16.930 | 15.81-36.00 |                  0.097 |                             0.180 |
| late surge       |              17.040 | 15.81-36.00 |                  0.245 |                             0.170 |
