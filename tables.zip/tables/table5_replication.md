**Table 5. Cross-cohort comparison over the shared gestational window (12-18 post-conception weeks).**

| Quantity                                                  |   Value | Interpretation                            |
|:----------------------------------------------------------|--------:|:------------------------------------------|
| Per-probe mean methylation, cross-cohort r                |   0.981 | datasets are directly comparable          |
| Per-probe mean methylation, RMSE                          |   0.068 | beta units                                |
| Developmental slope, observed cross-cohort r              |   0.051 | agreement of the age signal               |
| Developmental slope, expected r if the signal were shared |   0.924 | attenuation-corrected ceiling             |
| Observed / expected                                       |   0.056 | a value near 1 would indicate replication |
| Sign concordance of slopes                                |   0.494 | 0.5 is chance                             |
| Discovery split-half slope agreement                      |   0.914 | internal consistency, discovery           |
| Replication split-half slope agreement                    |   0.437 | internal consistency, replication         |
| Discovery PC1 correlation with age                        |  -0.648 | PC1 holds 35.5% of variance               |
| Replication PC1 correlation with age                      |  -0.107 | PC1 holds 19.1% of variance               |
