# A permanence window for prenatal epigenetic programming: why the critical week is biophysically narrow and epidemiologically invisible

**[AUTHOR 1]**^1^, **[AUTHOR 2]**^1^, **[AUTHOR 3]**^1,2,\*^

^1^ [DEPARTMENT], [INSTITUTION], [CITY], [COUNTRY]
^2^ [SECOND AFFILIATION], [INSTITUTION], [CITY], [COUNTRY]

\*Correspondence: lgonzalezpaz@gmail.com ([INITIALS])

---

## Abstract

Environmental exposures in pregnancy are associated with neurodevelopmental outcomes, yet the gestational timing at which an exposure becomes permanently inscribed in the fetal epigenome is unknown, and the field has not resolved it beyond the trimester. We show that this question has a closed-form answer once vulnerability is decomposed into two factors that are usually conflated. A perturbation leaves a permanent trace only if the methylation machinery is actively writing when it arrives, which we call inducibility, and only if the displacement survives to term, which we call retention. Their product defines a permanence kernel whose maximum satisfies a simple stationarity condition: the relaxation rate of the epigenetic state equals the fractional rate of decline of inducibility. Because inducibility falls as the machinery is switched off while relaxation falls as proliferation ceases, the window is interior, being neither the period of maximal plasticity nor the end of gestation. Applying this to 408,608 CpGs in 179 human fetal brains, we measure remodelling intensity directly and place the permanence window at 16.9 post-conception weeks, with a half-maximum span of 13.2 to 19.0 weeks. The estimate is internally robust but does not transfer between tissue dissections, and no existing dataset constrains the third trimester. Simulation shows that a kernel this narrow produces trimester associations that track exposure correlation rather than biology, and that about one million pregnancies would be needed to localise it. We therefore specify the measurements that would settle the question.

**Keywords:** DNA methylation; fetal brain development; critical window; epigenetic inheritance; distributed lag models; gene–environment interaction; neurodevelopmental disorders; identifiability

---

## Introduction

Prenatal environmental exposures, among them air pollution, maternal infection, anticonvulsant medication and micronutrient deficiency, are reproducibly associated with neurodevelopmental outcomes including autism spectrum disorder.^1,2^ The mechanistic account that has attracted most attention proposes that such exposures act by altering the fetal epigenome, so that a transient event in pregnancy is converted into a durable change in gene regulation that persists into postnatal life.^56,57^ This proposal is attractive because it explains persistence, and because it offers a molecular substrate on which genetic susceptibility and environmental insult could converge. It has, however, resisted quantitative test, and the central obstacle is temporal.

The difficulty is that correlation is abundant and causation is scarce. Within-family designs show that several associations previously attributed to pregnancy exposures are explained by familial confounding,^3^ and reviews of the environmental literature identify the absence of reliable exposure timing relative to developmental events as the principal barrier to causal inference.^1,2,4^ Where timing has been examined, resolution has stopped at the trimester. A systematic review that mapped 148 studies onto gestational stages assigned trimesters even when the primary studies reported weeks, and concluded that alignment within stages remains poorly defined.^5^ Reviews of pollutant exposure reach the same impasse.^6,58^

Worse, the trimester-level literature does not agree with itself. In the Nurses' Health Study II the third-trimester odds ratio for particulate matter and autism was 1.42, against 1.06 and 1.00 for the first and second trimesters;^7^ an independent analysis of particulate matter reported a third-trimester odds ratio of 1.36 with a first-trimester estimate below unity;^8^ a third study found all three trimesters associated and stated that they could not be disentangled.^9^ The three largest cohorts to apply weekly distributed-lag models are no more consistent, identifying windows of gestational weeks 1 to 27 in 294,937 pregnancies,^10^ 14 to 32 in 2,183,324,^11^ and 23 to 31 in 1,547,244.^12^ A recent meta-analysis pooled a third-trimester odds ratio of 1.17 with 94% heterogeneity.^13^ Studies of maternal infection and fever divide similarly between the first,^14^ second^15,16^ and third trimesters. Valproate exposure, the clearest pharmacological risk, yields hazard ratios near 2.9 with no resolvable window at all.^17^ Only folate supplementation has a window stated in weeks, from four weeks before conception through the first trimester.^4,18,19^

Two explanations for this disorder are usually offered, and both are incomplete. The first is measurement error in exposure assessment. The second is collinearity: exposures in different parts of pregnancy are correlated, so trimester-average regressions are biased and can assign an effect to the wrong period.^20,21,22^ These are real, and the statistical literature has characterised them carefully.^23,24,25^ What has not been done is to ask the prior question. Before asking whether a study design can recover a window, one must know what shape the window has. If the true kernel of vulnerability is broad, trimester resolution may be adequate; if it is narrow, no amount of trimester-level analysis will find it, and even weekly analysis may fail. The field has been estimating a quantity whose expected form was never derived.

Here we derive it. Our central claim is that the gestational vulnerability of the epigenome is not a single quantity but the product of two, which behave oppositely in time. Early gestation is the period of greatest epigenetic plasticity, and it is also the period in which a perturbation is most reliably erased, because rapid progenitor proliferation dilutes any mark that imperfect maintenance methylation fails to copy.^26,27,28^ Late gestation retains what it acquires, but by then the de novo machinery has been largely switched off. Permanence requires both, so it peaks between. We formalise this as an inducibility–retention decomposition, show that the location of the window obeys a simple analytic condition, anchor both factors on measurements in human fetal brain rather than on assumption, and then ask what study design could detect the window we obtain. The answer to that last question is the most consequential part of this work.

---

## Methods

### Overview and design

The analysis has four parts. First, we measure the intensity of DNA methylation remodelling across human fetal brain development directly from cross-sectional methylome data, without assuming a functional form. Second, we construct the relaxation rate of the epigenetic state from measured proliferation trajectories and from published maintenance-methylation fidelity. Third, we combine the two into a permanence kernel and locate its maximum with uncertainty propagated from all inputs. Fourth, we ask, by simulation, what epidemiological design could recover a kernel of the shape obtained. All analyses are deterministic given a fixed random seed (20261027), run on one CPU core in under three hours in total, and depend only on NumPy, SciPy, pandas and Matplotlib.

### Data sources

Three public datasets were used (Table 1). Fetal brain DNA methylation came from GEO accession GSE58885, 179 human fetal brain samples profiled on the Illumina HumanMethylation450 array across 23 to 184 days post-conception.^29^ Beta values were taken from the deposited series matrix. Of 485,577 probes, 408,608 were present with at least four observations, and 335,178 were retained after removing probes on sex chromosomes and probes overlapping documented SNPs.

Independent replication used GEO accession GSE74193, dorsolateral prefrontal cortex profiled on the same array.^30^ Only prenatal, non-psychiatric control arrays passing the depositors' quality flag were used: 64 arrays from 35 subjects, which collapse to 35 unique subject-age samples spanning 12.0 to 18.0 post-conception weeks. Technical replicates of the same subject were averaged.

Developmental trajectories of proliferation and of the methylation machinery came from the BrainSpan Developmental Transcriptome (RNA-seq, GENCODE v10, gene-level RPKM), restricted to neocortical structures.^31^ Gene modules are listed in Supplementary Code (`02_brainspan_machinery.py`). Module activity was computed as the mean across genes of the relative log2 expression, exponentiated to a linear scale and smoothed by a Gaussian kernel weighted by donor count, with timepoints having fewer than three donors excluded.

**[Table 1 near here]**

### Gestational-age binning and quality control

Donors were grouped into 13 gestational-age bins chosen so that each held at least six donors (bin edges at 3, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20 and 27 post-conception weeks). Array slide was checked against gestational age and found to be well randomised (one-way ANOVA *F* = 0.83, *P* = 0.64, η² = 0.071), so any time trend in the results is not attributable to batch.

Developmentally dynamic probes were identified by a one-way ANOVA across bins, computed from bin means, within-bin variances and bin sizes, with Benjamini–Hochberg control of the false discovery rate. At FDR < 0.05, 70,000 probes (20.9%) were dynamic; these form the primary probe set.

### Measuring remodelling intensity

Differencing adjacent bin means is noise dominated, because the sampling error of a bin mean is comparable to the one-week change. We therefore used all pairwise distances between bins. For bins *a* and *b*, the noise-corrected squared methylomic distance is

&nbsp;&nbsp;&nbsp;&nbsp;Δ²(a,b) = mean_i[(m̄_i(a) − m̄_i(b))²] − mean_i[s²_i(a) + s²_i(b)]&nbsp;&nbsp;&nbsp;&nbsp;(1)

where m̄_i(b) is the mean beta of probe *i* in bin *b* and s²_i(b) is the squared standard error of that mean. The subtracted term removes the upward bias from sampling error and makes Δ² unbiased for the squared true separation. Because bins differ in width, the within-bin linear trend in gestational age was removed before computing s², so that genuine developmental change inside a bin is not counted as noise. Δ² was not truncated at zero, since truncation biases sparsely sampled bins towards apparent stasis.

If remodelling follows a single dominant trajectory, then Δ(a,b) ≈ |G(b) − G(a)| for a monotone cumulative coordinate *G*. We obtained *G* by solving

&nbsp;&nbsp;&nbsp;&nbsp;min over g ≥ 0 of Σ_{a<b} w_ab [ Δ²(a,b) − ( Σ_{j=a}^{b−1} g_j )² ]²&nbsp;&nbsp;&nbsp;&nbsp;(2)

over non-negative increments g_j = G_{j+1} − G_j, with weights w_ab equal to the harmonic mean of the two bin sizes, by bounded nonlinear least squares. Remodelling intensity is

&nbsp;&nbsp;&nbsp;&nbsp;Φ(t) = dG/dt&nbsp;&nbsp;&nbsp;&nbsp;(3)

obtained from a local-linear smooth of *G* with a 2-week bandwidth. The adequacy of the one-dimensional assumption was tested by classical multidimensional scaling of the distance matrix.

### The inducibility–retention decomposition

Let *S*(τ) denote inducibility, the magnitude of the methylation displacement produced by a standardised environmental perturbation delivered at gestational time τ, and let *k*(t) denote the local relaxation rate, the rate at which such a displacement decays. The probability that the displacement survives to horizon *T* is

&nbsp;&nbsp;&nbsp;&nbsp;R(τ) = exp( − ∫_τ^T k(t) dt )&nbsp;&nbsp;&nbsp;&nbsp;(4)

and the permanence kernel is

&nbsp;&nbsp;&nbsp;&nbsp;P(τ) = S(τ) · R(τ).&nbsp;&nbsp;&nbsp;&nbsp;(5)

Differentiating the logarithm of (5) and setting the derivative to zero gives the stationarity condition

&nbsp;&nbsp;&nbsp;&nbsp;k(τ\*) = − d ln S / dτ |_{τ=τ\*}&nbsp;&nbsp;&nbsp;&nbsp;(6)

since d ln R/dτ = + k(τ). Equation (6) states that the permanence window sits where the relaxation rate has fallen to the fractional rate of decline of inducibility. Because *k* decreases as proliferation ceases while *S* decreases as the machinery is switched off, (6) has a single interior solution on the gestational interval.

### Anchoring inducibility

A locus being actively rewritten is a locus whose machinery is engaged there and therefore perturbable; a static locus is not. We accordingly set *S*(τ) = Φ(τ), the measured remodelling intensity, smoothed on a 0.25-week grid. Beyond the measured range, *S* continues from the boundary value with exponential decay at rate γ, fitted to the terminal measured segment (γ̂ = 0.529 week⁻¹) and varied widely in sensitivity analysis. We deliberately did not use machinery mRNA abundance to predict flux; the reason is reported in Results.

### Anchoring retention

The relaxation rate has two terms,

&nbsp;&nbsp;&nbsp;&nbsp;k(t) = [ ρ₀ ψ_P(t) + η Φ(t) / ( m̄ (1 − m̄) ) ] · (1 − c_coop ψ_R(t))&nbsp;&nbsp;&nbsp;&nbsp;(7)

where ψ_P is the BrainSpan proliferation profile normalised to a peak of one, and ψ_R the methyl-CpG reader profile. The first term is replicative dilution. Per cell division a methylated site is retained with maintenance efficiency *f*, so the continuous loss rate is λ(t)·(−ln f); ρ₀ is its peak value. Measured maintenance efficiencies are 0.96 aggregate and 0.90 to 0.98 across sites at the human *FMR1* island,^32,33^ rising to 0.976 after correction for bisulfite conversion error,^34^ with pattern fidelity of 0.9985 to 0.9992 per generation at unmethylated islands.^35^ Combined with primate cortical cell-cycle lengths of 22.7 to 54.1 h,^36^ these give ρ₀ between 0.076 and 0.30 week⁻¹, which we used as a lognormal prior with 95% of its mass on that interval. No in vivo human cell-cycle measurement exists; human stem-cell-derived progenitors give 46.5 to 47.1 h,^37^ inside this range.

The second term is enzymatic turnover. For a two-state locus at equilibrium the gross flux equals k·m̄(1 − m̄), so the measured net drift Φ divided by m̄(1 − m̄) is a lower bound on the enzymatic relaxation rate; η ≥ 1 is the gross-to-net flux ratio, given a lognormal prior with 95% mass on 1 to 10. This ties retention to measurement rather than to enzyme abundance. Cooperative stabilisation of the methylated state, which is required for somatic inheritance over biologically relevant timescales,^38,39^ and for which in vitro Hill coefficients near 2.2 and a co-methylation correlation length of a few hundred base pairs have been reported,^40,41,42^ enters as a multiplicative reduction c_coop ~ U(0, 0.5). The horizon *T* was drawn from U(37, 42) post-conception weeks. All parameters, their prior distributions and the measurements each is based on are listed in Table 2.

**[Table 2 near here]**

### Statistics, uncertainty and sensitivity

All confidence intervals on measured quantities come from a donor-level bootstrap with 300 replicates, resampling donors with replacement within bins and repeating the entire estimation. Parameter uncertainty in the kernel was propagated by Monte Carlo over 20,000 prior draws, in each of which Φ was also perturbed by its bootstrap standard error, so that measurement and parameter uncertainty enter jointly; the reported interval is the 2.5th to 97.5th percentile of τ\*. A prior-predictive comparison was performed by inspecting the distribution of model-implied quantities before conditioning. Global sensitivity was quantified by first-order variance-based effect indices, Var_x(E[τ\*|x]) / Var(τ\*), computed on twelve quantile bins of each parameter.

Four further controls were applied to the measured peak. An equal-sampling control resampled every bin down to the smallest donor count and refitted, so that the shape of Φ cannot arise from unequal precision. A leave-one-bin-out analysis removed each gestational bin in turn. The analysis was repeated within strata defined by CpG-island relation and gene region. Finally, the leading sample-space principal components were projected out as a deliberately conservative control for cell composition.

### Independent replication

The same estimator was applied to GSE74193 over its 12 to 18 post-conception week span, with bins merged until each held at least four samples. Because binning is weak at this sample size, the primary replication test was binning-free: the per-probe developmental slope was computed in each cohort over the shared window and compared. To distinguish genuine disagreement from attenuation by noise, we computed the correlation expected under a perfectly shared signal,

&nbsp;&nbsp;&nbsp;&nbsp;r_expected = σ²_true / sqrt[ (σ²_true + σ²_err,1)(σ²_true + σ²_err,2) ]&nbsp;&nbsp;&nbsp;&nbsp;(8)

with σ²_true estimated as the variance of observed slopes minus the mean squared standard error in each cohort. Internal consistency was assessed by split-half resampling of donors within each cohort. Comparability of the two datasets was verified by correlating per-probe mean methylation.

### Identifiability and the simulated epidemiology

Weekly exposure for pregnancy *i* was simulated as

&nbsp;&nbsp;&nbsp;&nbsp;E_i(w) = L_i + A sin( 2π ( θ_i + w/52 ) + φ_i ) + ε_iw&nbsp;&nbsp;&nbsp;&nbsp;(9)

with L_i ~ N(0, σ²_L) a time-invariant location level, θ_i ~ U(0,1) the conception date in the year, and ε_iw ~ N(0, σ²_ε). The location term makes exposures in different trimesters positively correlated; the seasonal term makes first- and third-trimester exposures negatively correlated, because they fall about six months apart. Tuning A against σ_L reproduces the full range of first-to-third-trimester correlations reported in real cohorts, from −0.76 for particulate matter in Shanghai^43^ and −0.7 for PM₁₀,^8^ through +0.20 to +0.43 in the Study to Explore Early Development^44^ and +0.33 to +0.54 in a Southern California cohort.^45^

Risk followed logit Pr(Y_i = 1) = β₀ + β Z_i with Z_i = Σ_w V(w) E_i(w), the biologically effective dose under the estimated permanence kernel V, standardised, with an odds ratio of 1.30 per standard deviation and an outcome prevalence of 0.02. Each simulated cohort was analysed three ways: three separate trimester-average logistic regressions, one joint logistic regression containing all three trimester averages, and a distributed-lag model using a six-element cubic B-spline basis over weeks, which is the basis used by the published weekly analyses.^25^ Logistic models were fitted by iteratively reweighted least squares. Twenty replicate cohorts of 60,000 pregnancies were simulated per correlation setting. Statistical power to localise the window was assessed separately at cohort sizes from 10⁴ to 10⁶.

### Reporting

Gestational age is reported in post-conception weeks (pcw) throughout the molecular analyses; epidemiological results are reported in gestational weeks (GW), which are approximately pcw + 2. Gene symbols are italicised and protein names are not. Exact *P* values are given where computed.

---

## Results

### Fetal cortical methylomes follow a single developmental trajectory

Across 70,000 developmentally dynamic CpGs, the matrix of noise-corrected methylomic distances between gestational-age bins is almost perfectly one-dimensional: classical multidimensional scaling places 98.4% of the distance structure on a single axis (Figure 1b, c). The leading temporal mode of the per-probe trajectories carries 88.3% of trajectory variance, and the monotone cumulative embedding of equation (2) explains 96.2% of the weighted variance in the pairwise distances. Total remodelling across the measured interval is 0.109 beta units.

One bin was excluded from the primary analysis. Samples at 3.3 to 7.0 post-conception weeks sit near the middle of the trajectory axis rather than at its early end, closer in methylomic distance to 13-week samples than to 10-week samples. At 23 days post-conception the tissue is neural tube rather than neocortex, so this bin does not represent an earlier point on the same progression; excluding it raised the embedding fit from 0.874 to 0.962. The primary window is therefore 8.4 to 22.1 post-conception weeks.

**[Figure 1 near here]**

### Remodelling intensity peaks at 15 post-conception weeks

The derivative of the cumulative curve gives remodelling intensity Φ(t) (Figure 2a). It rises from 3.8 × 10⁻³ beta week⁻¹ at 9 weeks to a maximum of 16.9 × 10⁻³ at 15.4 weeks, then falls to 5.9 × 10⁻³ by 19 weeks and 1.3 × 10⁻³ by 21 weeks (Table 3). The donor-level bootstrap places the peak at 15.1 weeks with a 95% confidence interval of 13.9 to 16.6.

This timing is not an artefact of uneven sampling. Donor counts per bin range from 6 to 25, and the magnitude of the noise correction scales inversely with bin size, so we resampled every bin down to six donors and refitted. The peak moved by 0.24 weeks and the rank correlation between the full and equal-sampling profiles was ρ = 1.000 (Figure 2b). Removing any single gestational bin leaves the peak between 14.85 and 16.10 weeks (Figure 2d, Table 4). The peak is identical at 15.36 weeks in every genomic stratum examined: CpG islands, northern and southern shores, open sea, promoters and gene bodies (Figure 2c), although the total extent of remodelling differs between them, from 0.077 beta units at islands to 0.114 at open-sea probes.

**[Table 3 near here]**

**[Table 4 near here]**

**[Figure 2 near here]**

### Machinery abundance does not predict remodelling flux

Proliferation collapses early. In BrainSpan neocortex, *MKI67* and *UHRF1* fall roughly tenfold between 9 and 12 post-conception weeks, with *UHRF1*, whose expression is replication-coupled, tracking the cell-cycle module closely; *DNMT3A*, *TET1* and *TET3* decline progressively and more slowly (Figure 3a, b). These trajectories are the empirical basis for the proliferation profile used in equation (7).

They do not, however, predict when remodelling happens. Over the interval where both are measured, the correlation between combined de novo and demethylation machinery mRNA and measured remodelling intensity is *r* = 0.18, and between proliferation and remodelling intensity it is *r* = −0.29 (Figure 3c, d). Bulk transcript abundance of the enzymes is therefore not a usable proxy for the flux they catalyse, which is unsurprising given that targeting rather than enzyme concentration is expected to be limiting, but which has a practical consequence: models of developmental epigenetic dynamics parameterised from expression data alone are not anchored on the quantity they intend to represent. This is why inducibility here is anchored on measured remodelling instead.

**[Figure 3 near here]**

### The permanence window falls at 16.9 post-conception weeks

Combining the measured inducibility with the relaxation rate of equation (7) yields the permanence kernel (Figure 4a). Retention rises monotonically through gestation: a displacement introduced at 9 weeks has a 12.8% chance of surviving to term, at 12 weeks 18.5%, at 17 weeks 45.1% and at 20 weeks 61.6%. Inducibility peaks at 15.4 weeks and then falls steeply. Their product peaks at 16.9 post-conception weeks, with a 95% credible interval of 15.8 to 18.0 and a half-maximum span of 13.2 to 19.0 weeks.

The stationarity condition of equation (6) is satisfied at that point: the relaxation rate there is 0.175 week⁻¹ and the fractional decline of inducibility is 0.152 week⁻¹ (Figure 4c). The window is displaced about 1.5 weeks later than the peak of plasticity itself, which is the quantitative content of the decomposition. Decomposing the relaxation rate shows why the early period is protected rather than vulnerable: before 12 weeks, replicative dilution contributes most of *k*, and it is this that erases early perturbations (Figure 4b).

Across 20,000 Monte Carlo draws no parameter combination placed the peak after 20 weeks when the search was unconstrained. Global sensitivity analysis attributes 58.9% of the variance in τ\* to the gross-to-net flux ratio η, 6.7% to cooperative stabilisation and only 0.9% to the replicative dilution rate ρ₀; the retention horizon and the extrapolation rate contribute less than 0.1% each. The window is therefore insensitive to precisely those parameters that are least well measured in humans, and a tenfold prior range on η moves the peak by just over two weeks in total.

**[Figure 4 near here]**

### The measured remodelling signal does not transfer between dissections

We attempted replication in dorsolateral prefrontal cortex from an independent cohort over the shared window of 12 to 18 post-conception weeks. The two datasets are directly comparable: per-probe mean methylation agrees at *r* = 0.981 with a root-mean-square difference of 0.068 beta units, so there is no processing or annotation mismatch. Each cohort also contains an internally reproducible developmental signal: split-half resampling of donors gives a slope agreement of 0.914 (SD 0.016) in the discovery cohort and 0.437 (SD 0.137) in the replication cohort.

Yet the two signals are unrelated to each other. The per-CpG developmental slopes correlate at *r* = 0.051 between cohorts, with a Spearman ρ of 0.007 and a sign concordance of 0.494, which is chance. This is not attenuation by noise. Given the estimated variance of true slopes and the measured standard errors in each cohort, equation (8) gives an expected correlation of 0.924 if the signal were shared; the observed value is 5.6% of that (Table 5). Restricting to the 5% of probes with the strongest discovery signal does not improve agreement (*r* = 0.067).

The likely reason is visible in the principal component structure. In whole fetal brain, the leading component carries 35.5% of variance among dynamic probes and correlates −0.648 with gestational age; in dorsolateral prefrontal cortex it carries 19.1% and correlates only −0.107. A single large axis that tracks age dominates the whole-brain data and is absent from the regionally consistent dissection. Whole fetal brain samples change in composition with age, both through the germinal-zone-to-cortical-plate transition and through the changing regional makeup of a whole-brain dissection, whereas a prefrontal dissection does not change in the same way. Regional heterogeneity of developmental trajectories, which is well documented in the developing human cortex,^46,47^ would produce the same result.

We could not separate the two by adjustment, and the failure is instructive. Projecting out the leading principal component, which carries 54.6% of the variance of the dynamic probe set and correlates −0.583 with age, reduces the embedding fit from 0.962 to 0.450; removing two or three components reduces it to 0.287 and 0.034 and destabilises the peak. The developmental trajectory *is* the leading component, so adjusting for composition in bulk fetal tissue removes the signal of interest by construction. Composition and development are the same axis in this material, and no statistical adjustment of bulk data can separate them.

The measured remodelling profile, and therefore the kernel built on it, should accordingly be read as specific to whole fetal brain as sampled in GSE58885, and as provisional pending cell-type-resolved data.

**[Table 5 near here]**

**[Figure 5 near here]**

### No existing data constrain the third trimester

GSE58885 contains a single sample beyond 182 days post-conception and the replication cohort ends at 18 weeks, so remodelling intensity after about 20 post-conception weeks is unmeasured in every available human fetal brain methylome dataset. We therefore recomputed the kernel under five assumptions about the unmeasured interval, including a plateau and two scenarios in which inducibility rises again in late gestation, as would be expected if the synaptogenesis-associated methylome reconfiguration described in human cortex^48^ began before term (Table 6).

The mid-gestation peak is the global maximum under all five: the median global peak ranges only from 16.88 to 17.04 post-conception weeks. But a second, late window cannot be excluded. Under the measured decline the probability that the global peak lies after 20 weeks is 0.000; under a plateau it is 0.044, under a 50% late rise 0.097, and under a 200% late surge 0.245. The honest statement is that the mid-gestation window is robust, and that the existence of an additional third-trimester window is not a question these data can answer.

**[Table 6 near here]**

### A narrow kernel produces trimester associations that track correlation, not biology

The estimated kernel places 11.8% of its mass in the first trimester, 87.9% in the second and 0.3% in the third, with a peak at gestational week 19 and a half-maximum span of weeks 16 to 21. We simulated cohorts in which this kernel is the true generating mechanism and varied only the correlation structure of exposure.

The apparent first-trimester odds ratio from separate trimester-average regressions ranges from 1.10 to 1.23 as the first-to-third-trimester correlation moves from −0.76 to +0.40, even though the first trimester carries little of the kernel's mass. The apparent third-trimester odds ratio ranges from 0.98 to 1.17, crossing unity, so that under strongly negative seasonal correlation the third trimester appears mildly protective while under positive correlation it appears harmful (Figure 6b, Table 7). Both patterns are present in the published literature, including protective weekly estimates for ozone and for early-pregnancy particulate matter in two of the three large weekly cohorts.^10,12^ Nothing about the biology changed between these simulations; only the exposure correlation did.

Distributed-lag analysis is better but not sufficient. The peak recovered by a spline-basis distributed-lag model, the standard approach, is biased by −4.2 to +5.1 weeks depending on the correlation setting, and the apparent significant window spans weeks 14 to 24 across settings (Figure 6a, c). The ranges reported by the three large published cohorts, weeks 1 to 27, 14 to 32 and 23 to 31,^10,11,12^ are comfortably inside the spread that a single fixed kernel generates.

**[Table 7 near here]**

**[Figure 6 near here]**

### About one million pregnancies would be needed to localise the window

We then asked what it would take. With an odds ratio of 1.30 per standard deviation of biologically effective dose and a 2% outcome prevalence, a distributed-lag analysis recovers the peak within four weeks in 9% of cohorts of 10,000 pregnancies, 47% at 100,000, 83% at 300,000 and 100% at 1,000,000; localisation within two weeks reaches 54% only at 300,000 and 58% at 1,000,000 (Table 8, Figure 6d). The standard deviation of the recovered peak falls from 14.5 weeks at 10,000 pregnancies to 0.9 weeks at one million.

This places the published cohorts precisely. At 294,937 pregnancies^10^ a four-week localisation is expected about 83% of the time and a two-week localisation about half the time; at 1.5 to 2.2 million^11,12^ four-week localisation should be reliable. That these cohorts nonetheless disagree indicates that between-cohort differences in exposure correlation structure, which our simulations show are sufficient on their own to move the apparent window by five weeks, dominate the remaining sampling error. Larger cohorts alone will not resolve the discrepancy; harmonised weekly exposure modelling with explicit reporting of the within-pregnancy correlation matrix is the missing ingredient, and that matrix is almost never published.

**[Table 8 near here]**

---

## Discussion

We set out to ask whether the gestational week at which an environmental perturbation becomes permanently fixed in the fetal epigenome can be determined. The answer has three parts, and they point in different directions.

First, the question has a well-posed form that it previously lacked. Decomposing vulnerability into inducibility and retention converts a verbal argument about plasticity into equation (6), which states that the window occurs where the relaxation rate of the epigenetic state has fallen to the fractional rate of decline of inducibility. This yields a prediction that the field's intuition does not: the most plastic period is not the most dangerous one. Early gestation combines maximal writing activity with maximal erasure, because the same proliferation that expands the progenitor pool dilutes any mark that imperfect maintenance fails to copy.^32,33,34^ On our estimates a perturbation at 9 post-conception weeks has roughly a one-in-eight chance of surviving to term, against nearly one-in-two at 17 weeks. The decomposition also clarifies why morphogenetic and epigenetic critical periods need not coincide: the classical teratogenic windows for thalidomide and rubella fall in the first trimester, where organ primordia are forming but epigenetic marks are least likely to persist.

Second, applied to the only human fetal brain methylome series of adequate size, the framework places the permanence window at 16.9 post-conception weeks, about gestational week 19, with a half-maximum span of 13.2 to 19.0 post-conception weeks. The underlying measurement, that remodelling intensity peaks at 15.4 weeks, is strikingly robust internally. It survives equal-donor resampling, removal of any gestational bin, and stratification by CpG-island context and gene region, and the one-dimensionality of the trajectory is near-complete. The kernel's location is also insensitive to the parameters least well measured in humans, since replicative dilution rate contributes under 1% of the variance in the peak estimate.

Third, and against this, the measured remodelling signal does not transfer between tissue dissections. The per-CpG developmental slopes in whole fetal brain and in dorsolateral prefrontal cortex agree at 5.6% of the value expected if the signal were shared, despite the datasets being comparable and each internally consistent. We take this seriously rather than attributing it to power, because the attenuation calculation excludes that explanation. The most economical reading is that much of the apparent developmental remodelling in bulk whole fetal brain reflects the changing cellular and regional composition of the sample rather than a cell-intrinsic programme common to cortical neurons, with genuine regional heterogeneity of trajectories^46,47^ contributing as well. Our attempt to adjust for this failed in a way that is itself a finding: the developmental axis *is* the leading principal component of the data, so projecting out composition removes development. In bulk fetal tissue the two are not separable, and this conclusion applies to the large existing literature on developmental methylome trajectories in bulk fetal brain, not only to our use of it.

The consequence is that our kernel should be read as the best current estimate conditional on whole fetal brain sampling, and as provisional. We think this is the correct posture, and we note that it does not undermine the framework, which is independent of the particular Φ used, nor the identifiability results, which depend on the kernel only through its width.

Those identifiability results are, in our view, the most immediately consequential part of this work. A kernel with a half-maximum width of five to six weeks, placed in mid-gestation, generates first-trimester odds ratios between 1.10 and 1.23 and third-trimester odds ratios between 0.98 and 1.17 purely as a function of how exposures correlate within a pregnancy. Both the positive first-trimester findings and the apparently protective late-pregnancy findings that appear in the literature are reproduced by a single fixed biology. The statistical literature has shown that trimester-average regressions are biased under collinearity and that distributed-lag models are preferable;^20,21,23^ our contribution is to quantify how large the resulting distortion is for a kernel of the shape the biology implies, and to show that it exceeds the sampling error of even very large cohorts. The three largest weekly studies of particulate matter and autism disagree by more than fifteen weeks,^10,11,12^ and the spread we generate from one kernel covers that disagreement entirely.

Several limitations bound these conclusions beyond the replication failure already discussed. The third trimester is unmeasured in all available human fetal brain methylome data, and although the mid-gestation peak remains the global maximum under every scenario we tested, a second late window cannot be excluded and becomes appreciable under a strong late rise in remodelling. Our inducibility measure is the net drift of bulk methylation, which is a lower bound on gross enzymatic flux; the ratio between them, η, is the dominant source of uncertainty in the peak, and it is not directly measured in any human tissue. The 450K array samples about 1.6% of CpGs with a bias towards genic and island-proximal regions, so remodelling in distal regulatory elements is under-represented. The relaxation rate treats loci as independent two-state systems, whereas collaborative methylation over a few hundred base pairs is well established^38,39,41^ and will make some loci more bistable than the model allows; we absorbed this into a single cooperativity parameter rather than modelling it explicitly. The model concerns persistence of a methylation state, not its functional consequence; a mark can persist without affecting transcription, and a transient exposure can have lasting effects through routes that are not epigenetic at all. Finally, our epidemiological simulations assume a correctly specified exposure model and no confounding, so the sample sizes we report are optimistic.

The framework makes testable predictions. Perturbations delivered at equivalent stages in a system where timing can be controlled, such as human cortical organoids, should show a retention profile that rises steeply across the proliferative-to-postmitotic transition, with an inflection tracking the fall in cell-cycle gene expression rather than the fall in DNMT or TET expression. Loci with higher local CpG density, and therefore stronger collaborative stabilisation, should have systematically later and narrower permanence windows than isolated CpGs, which our ensemble treatment deliberately averages over. In cohorts, exposures whose weekly profiles are more sharply peaked should show larger apparent effects than chronic exposures of the same cumulative magnitude, which is the opposite of the usual assumption that cumulative dose is the relevant quantity.

What would settle the question is specific. Three measurements are needed. Cell-type-resolved methylomes of human fetal cortex across gestation, whether by sorting or single-cell methods, would separate the composition change from the cell-intrinsic programme that our replication analysis shows bulk data cannot distinguish. Fetal brain methylome data from the third trimester, which do not currently exist at any sample size, would close the one interval in which a second window remains possible. Direct measurement of methylation turnover, rather than net drift, in human neural progenitors and postmitotic neurons would pin the single parameter that dominates our uncertainty. On the epidemiological side, the requirement is not simply larger cohorts but publication of the within-pregnancy weekly exposure correlation matrix alongside every distributed-lag analysis, so that the distortion we characterise can be corrected rather than inherited.

---

## Conclusions

The gestational timing of permanent epigenetic programming is not a single quantity but the product of two that move oppositely: the machinery must be writing, and the writing must not be erased. This decomposition gives an analytic condition for the window, which falls where the relaxation rate equals the fractional decline of inducibility, and predicts that the window is interior rather than coincident with the period of maximal plasticity. Measured in human fetal brain, remodelling intensity peaks at 15.4 post-conception weeks and the permanence window at 16.9, spanning 13.2 to 19.0 weeks at half maximum. This estimate is robust within the discovery data but does not transfer between tissue dissections, and the third trimester remains unmeasured; it should therefore be treated as provisional. Independently of its exact location, a window of this width cannot be recovered by trimester-level epidemiology, and reproduces the full spread of published and mutually inconsistent findings from a single fixed biology. Resolving the critical week will require cell-type-resolved fetal methylomes extending into the third trimester, direct measurement of methylation turnover, and routine reporting of within-pregnancy exposure correlation.

---

## CRediT authorship contribution statement

**[AUTHOR 1]:** Conceptualization, Methodology, Software, Formal analysis, Investigation, Data curation, Writing – original draft, Visualization. **[AUTHOR 2]:** Methodology, Validation, Formal analysis, Writing – review & editing. **[AUTHOR 3]:** Conceptualization, Methodology, Resources, Writing – review & editing, Supervision, Project administration, Funding acquisition. All authors read and approved the final manuscript.

## Ethics Statement

This study used only publicly available, fully de-identified human data obtained from open-access repositories: the Gene Expression Omnibus (accessions GSE58885 and GSE74193) and the BrainSpan Developmental Transcriptome. No new human or animal subjects were recruited, no identifiable private information was accessed, and no new biological samples were collected. Ethical approval and informed consent for the original collections were obtained by the respective primary investigators and are documented in the source publications.^29,30,31^ Under institutional policy, secondary analysis of anonymised public data of this kind does not require additional review board approval. The authors affirm that the fetal tissue datasets were generated with appropriate consent as described by the original depositors.

## Funding

This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit sectors. [If applicable, replace with: This work was supported by [FUNDER], grant number [NUMBER].]

## Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Data Availability Statement

All data analysed in this study are publicly available and were not generated by the authors. Human fetal brain DNA methylation data are available from the NCBI Gene Expression Omnibus under accession GSE58885 (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE58885). Independent replication data are available under accession GSE74193 (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE74193). The BrainSpan Developmental Transcriptome is available at https://www.brainspan.org. The Illumina HumanMethylation450 manifest is available from the GEO platform record GPL13534.

All analysis code, together with the derived result tables, figure-generation scripts, a pinned software environment and documentation sufficient to reproduce every number and figure in this manuscript from the raw public data, is openly available at [GITHUB URL] and archived at Zenodo under DOI [ZENODO DOI] (version v1.0.0). The repository includes a single driver script that downloads the source data, runs the full pipeline and regenerates all figures and tables. No restrictions apply to its reuse under the stated licence.

## Declaration of Generative AI and AI-Assisted Technologies in the Writing Process

During the preparation of this work the authors used a large language model (Anthropic Claude) to assist with literature retrieval and verification, analysis code drafting, and language editing of the manuscript. All study design decisions, modelling choices, interpretations and conclusions are the authors' own. Every bibliographic reference was programmatically verified against the Crossref registry (see `code/11_build_references.py`), and every numerical result reported in this manuscript was produced by the deposited analysis code and can be regenerated from the public source data. The authors reviewed and edited the content as needed and take full responsibility for the content of the publication.

---

## References

*(The full verified reference list is maintained in `manuscript/references.md`, generated programmatically from the Crossref registry by `code/11_build_references.py`, and is reproduced in the compiled manuscript.)*

---

## Figure legends

**Figure 1. The human fetal cortical methylome follows a single developmental trajectory.**
(**a**) Gestational-age distribution of the 179 donors of the discovery cohort (GSE58885); triangles mark the weekly bins of the independent replication cohort (GSE74193). (**b**) Noise-corrected methylomic distance between gestational-age bins, computed from equation (1) over 70,000 developmentally dynamic CpGs; colour encodes root-mean-square difference in beta. (**c**) Coordinate of each bin on the first axis of a classical multidimensional scaling of that distance matrix, which carries 98.4% of the distance structure. The earliest bin, spanning 3.3 to 7.0 post-conception weeks, lies in the middle of the axis rather than at its early end and was excluded from the primary analysis. (**d**) Cumulative remodelling G(t) from the monotone embedding of equation (2), with the shaded band giving the 95% interval from a 300-replicate donor-level bootstrap.

**Figure 2. Remodelling intensity peaks at mid-gestation and the timing is robust.**
(**a**) Remodelling intensity Φ(t), the derivative of the cumulative curve, with the 95% donor-bootstrap interval; the dashed line marks the maximum at 15.4 post-conception weeks. (**b**) The same profile after resampling every gestational bin down to six donors, which equalises the magnitude of the noise correction across bins; the rank correlation with the full-data profile is ρ = 1.000. (**c**) Φ(t) computed separately within genomic strata. The timing is identical in all strata although the total extent of remodelling differs. (**d**) Peak location when each gestational bin is removed in turn; the shaded band is ± 2 weeks around the full-data estimate.

**Figure 3. Machinery abundance does not predict when remodelling happens.**
(**a**) Relative activity profiles of proliferation, de novo methylation, demethylation, maintenance methylation and methyl-CpG readers across human neocortical development (BrainSpan), each normalised to a peak of one. (**b**) Individual gene trajectories; the replication-coupled genes *MKI67* and *UHRF1* fall about tenfold between 9 and 12 post-conception weeks, well before the peak of remodelling. (**c**) Measured remodelling intensity against combined de novo and demethylation machinery mRNA over the interval where both are available (Pearson *r* = 0.18). (**d**) Measured remodelling intensity against proliferation (*r* = −0.29). Each point is one quarter-week of the common grid.

**Figure 4. The inducibility–retention decomposition locates the permanence window.**
(**a**) Inducibility S, retention R and their product, the permanence kernel P, normalised to unit maximum; the dashed line marks the peak of P and the shaded region is beyond the last gestational week with methylome data. (**b**) The relaxation rate k(t) of equation (7), separated into replicative dilution and enzymatic turnover. Replicative dilution dominates before 12 post-conception weeks and is what erases early perturbations. (**c**) Graphical solution of the stationarity condition of equation (6): the permanence window is where k(τ) crosses −d ln S/dτ. (**d**) Distribution of the peak location over 20,000 Monte Carlo draws in which parameter priors and the bootstrap uncertainty of Φ were sampled jointly; the solid line is the median and dashed lines the 95% credible interval.

**Figure 5. Independent replication and the unmeasured third trimester.**
(**a**) Remodelling intensity over the window shared by the two cohorts, each scaled to its own maximum. (**b**) Agreement of per-CpG developmental slopes between cohorts, for all CpGs and for the top decile by discovery effect size; the dashed line marks chance sign concordance. Agreement is at chance despite per-probe mean methylation agreeing between the cohorts at *r* = 0.981. (**c**) Permanence kernel recomputed under five assumptions about inducibility after the last measured week, which is marked by the dashed line. The mid-gestation peak is the global maximum in every case. (**d**) Probability that the global maximum of the kernel falls after 20 post-conception weeks under each scenario, over 3,000 Monte Carlo draws.

**Figure 6. A narrow kernel is not recoverable by conventional epidemiology.**
(**a**) The true permanence kernel used to generate the simulated cohorts, and the lag–response curves recovered by a spline-basis distributed-lag model, under exposure correlation structures spanning the range reported in real cohorts. (**b**) Apparent odds ratios per standard deviation from separate trimester-average logistic regressions, plotted against the simulated first-to-third-trimester exposure correlation. Nothing about the biology changes along the horizontal axis. The third-trimester estimate crosses unity. (**c**) Bias of the distributed-lag peak relative to the truth; error bars are the standard deviation across 20 replicate cohorts of 60,000 pregnancies; the shaded band is ± 2 weeks. (**d**) Probability that a distributed-lag analysis localises the peak within 2 and within 4 weeks, as a function of cohort size, with the sizes of three published weekly cohorts marked.
