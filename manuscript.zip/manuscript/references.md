# References

1. Modabbernia A, Velthorst E, Reichenberg A. Environmental risk factors for autism: an evidence-based review of systematic reviews and meta-analyses. Mol Autism. 2017;8(1):13. doi:10.1186/s13229-017-0121-4

2. Ng M, de Montigny J, Ofner M, Do M. Environmental factors associated with autism spectrum disorder: a scoping review for the years 2003–2013. Health Promot Chronic Dis Prev Can. 2017;37(1):1-23. doi:10.24095/hpcdp.37.1.01

3. Carlsson T, Molander F, Taylor MJ, Jonsson U, Bölte S. Early environmental risk factors for neurodevelopmental disorders – a systematic review of twin and sibling studies. Dev Psychopathol. 2021;33(4):1448-1495. doi:10.1017/S0954579420000620

4. Mandy W, Lai M. Annual Research Review: The role of the environment in the developmental psychopathology of autism spectrum condition. J Child Psychol Psychiatry. 2016;57(3):271-292. doi:10.1111/jcpp.12501

5. Khawar M, Tayyab B, Naz I. Gestational Windows Where Genetic and Neurobiological Mechanisms Converge in Autism Risk: A Systematic Review. J Health Wellness Community Res. 2025;3(14):e864. doi:10.61919/z7fb7t85

6. Tartaglione A, Camoni L, Calamandrei G, Chiarotti F, Venerosi A. The contribution of environmental pollutants to the risk of autism and other neurodevelopmental disorders: A systematic review of case-control studies. Neurosci Biobehav Rev. 2024;164:105815. doi:10.1016/j.neubiorev.2024.105815

7. Raz R, Roberts AL, Lyall K, Hart JE, Just AC, Laden F, et al. Autism Spectrum Disorder and Particulate Matter Air Pollution before, during, and after Pregnancy: A Nested Case–Control Analysis within the Nurses’ Health Study II Cohort. Environ Health Perspect. 2015;123(3):264-270. doi:10.1289/ehp.1408133

8. Kalkbrenner AE, Windham GC, Serre ML, Akita Y, Wang X, Hoffman K, et al. Particulate Matter Exposure, Prenatal and Postnatal Windows of Susceptibility, and Autism Spectrum Disorders. Epidemiology. 2015;26(1):30-42. doi:10.1097/EDE.0000000000000173

9. Volk HE, Lurmann F, Penfold B, Hertz-Picciotto I, McConnell R. Traffic-Related Air Pollution, Particulate Matter, and Autism. JAMA Psychiatry. 2013;70(1):71. doi:10.1001/jamapsychiatry.2013.266

10. Rahman MM, Shu YH, Chow T, Lurmann FW, Yu X, Martinez MP, et al. Prenatal Exposure to Air Pollution and Autism Spectrum Disorder: Sensitive Windows of Exposure and Sex Differences. Environ Health Perspect. 2022;130(1):017008. doi:10.1289/EHP9509

11. Cloutier M, Yu C, Talarico R, Hawken S, Chen H, Weichenthal S, et al. Prenatal Exposure to Fine Particulate Matter Components and Autism Risk in Childhood. JAMA Netw Open. 2025;8(10):e2538882. doi:10.1001/jamanetworkopen.2025.38882

12. Shupler M, Qiu X, Huybrechts KF, Hernandez-Diaz S, Huang W, Choi HM, et al. Preconception, Prenatal and Postnatal PM2.5 Exposure and Neurodevelopmental Disorder Risk among Medicaid Recipients. Environ Sci Technol. 2026;60(40):28312-28324. doi:10.1021/acs.est.6c03766

13. Nazneen S, Ibarra-Mejia G, Mahmud S, Ojo B, Khanjani N, Jeon S, et al. Prenatal exposure to particulate matter (PM) and autism spectrum disorder (ASD) among children: a systematic review and meta-analysis. Rev Environ Health. 2026;41(3):353-374. doi:10.1515/reveh-2025-0157

14. Atladóttir HÓ, Thorsen P, Østergaard L, Schendel DE, Lemcke S, Abdallah M, et al. Maternal Infection Requiring Hospitalization During Pregnancy and Autism Spectrum Disorders. J Autism Dev Disord. 2010;40(12):1423-1430. doi:10.1007/s10803-010-1006-y

15. Hornig M, Bresnahan MA, Che X, Schultz AF, Ukaigwe JE, Eddy ML, et al. Prenatal fever and autism risk. Mol Psychiatry. 2018;23(3):759-766. doi:10.1038/mp.2017.119

16. Croen LA, Qian Y, Ashwood P, Zerbo O, Schendel D, Pinto‐Martin J, et al. Infection and Fever in Pregnancy and Autism Spectrum Disorders: Findings from the Study to Explore Early Development. Autism Res. 2019;12(10):1551-1561. doi:10.1002/aur.2175

17. Christensen J, Grønborg TK, Sørensen MJ, Schendel D, Parner ET, Pedersen LH, et al. Prenatal Valproate Exposure and Risk of Autism Spectrum Disorders and Childhood Autism. JAMA. 2013;309(16):1696. doi:10.1001/jama.2013.2270

18. Surén P, Roth C, Bresnahan M, Haugen M, Hornig M, Hirtz D, et al. Association Between Maternal Use of Folic Acid Supplements and Risk of Autism Spectrum Disorders in Children. JAMA. 2013;309(6):570. doi:10.1001/jama.2012.155925

19. Levine SZ, Kodesh A, Viktorin A, Smith L, Uher R, Reichenberg A, et al. Association of Maternal Use of Folic Acid and Multivitamin Supplements in the Periods Before and During Pregnancy With the Risk of Autism Spectrum Disorder in Offspring. JAMA Psychiatry. 2018;75(2):176. doi:10.1001/jamapsychiatry.2017.4050

20. Wilson A, Chiu YHM, Hsu HHL, Wright RO, Wright RJ, Coull BA. Potential for Bias When Estimating Critical Windows for Air Pollution in Children’s Health. Am J Epidemiol. 2017;186(11):1281-1289. doi:10.1093/aje/kwx184

21. Wilson A, Chiu YHM, Hsu HHL, Wright RO, Wright RJ, Coull BA. Bayesian distributed lag interaction models to identify perinatal windows of vulnerability in children’s health. Biostatistics. 2017;18(3):537-552. doi:10.1093/biostatistics/kxx002

22. Basagaña X, Barrera-Gómez J. Reflection on modern methods: visualizing the effects of collinearity in distributed lag models. Int J Epidemiol. 2022;51(1):334-344. doi:10.1093/ije/dyab179

23. Gasparrini A, Armstrong B, Kenward MG. Distributed lag non‐linear models. Stat Med. 2010;29(21):2224-2234. doi:10.1002/sim.3940

24. Liao J, Zhang Y, Yang Z, Qiu C, Chen W, Zhang JJ, et al. Identifying critical windows of air pollution exposure during preconception and gestational period on birthweight: a prospective cohort study. Environ Health. 2023;22(1):71. doi:10.1186/s12940-023-01022-6

25. Jo H, Eckel SP, Wang X, Chen JC, Cockburn M, Martinez MP, et al. Sex-specific associations of autism spectrum disorder with residential air pollution exposure in a large Southern California pregnancy cohort. Environ Pollut. 2019;254:113010. doi:10.1016/j.envpol.2019.113010

26. McGuinn LA, Wiggins LD, Volk HE, Di Q, Moody EJ, Kasten E, et al. Pre- and Postnatal Fine Particulate Matter Exposure and Childhood Cognitive and Adaptive Function. Int J Environ Res Public Health. 2022;19(7):3748. doi:10.3390/ijerph19073748

27. Spiers H, Hannon E, Schalkwyk LC, Smith R, Wong CC, O’Donovan MC, et al. Methylomic trajectories across human fetal brain development. Genome Res. 2015;25(3):338-352. doi:10.1101/gr.180273.114

28. Jaffe AE, Gao Y, Deep-Soboslay A, Tao R, Hyde TM, Weinberger DR, et al. Mapping DNA methylation across development, genotype and schizophrenia in the human frontal cortex. Nat Neurosci. 2016;19(1):40-47. doi:10.1038/nn.4181

29. Kang HJ, Kawasawa YI, Cheng F, Zhu Y, Xu X, Li M, et al. Spatio-temporal transcriptome of the human brain. Nature. 2011;478(7370):483-489. doi:10.1038/nature10523

30. Hannon E, Spiers H, Viana J, Pidsley R, Burrage J, Murphy TM, et al. Methylation QTLs in the developing brain and their enrichment in schizophrenia risk loci. Nat Neurosci. 2016;19(1):48-54. doi:10.1038/nn.4182

31. Laird CD, Pleasant ND, Clark AD, Sneeden JL, Hassan KMA, Manley NC, et al. Hairpin-bisulfite PCR: Assessing epigenetic methylation patterns on complementary strands of individual DNA molecules. Proc Natl Acad Sci U S A. 2004;101(1):204-209. doi:10.1073/pnas.2536758100

32. Genereux DP, Miner BE, Bergstrom CT, Laird CD. A population-epigenetic model to infer site-specific methylation rates from double-stranded DNA methylation patterns. Proc Natl Acad Sci U S A. 2005;102(16):5802-5807. doi:10.1073/pnas.0502036102

33. Fu AQ, Genereux DP, Stöger R, Laird CD, Stephens M. Statistical inference of transmission fidelity of DNA methylation patterns over somatic cell divisions in mammals. Ann Appl Stat. 2010;4(2):871-892. doi:10.1214/09-AOAS297

34. Ushijima T, Watanabe N, Okochi E, Kaneda A, Sugimura T, Miyamoto K. Fidelity of the Methylation Pattern and Its Variation in the Genome. Genome Res. 2003;13(5):868-874. doi:10.1101/gr.969603

35. Ming X, Zhang Z, Zou Z, Lv C, Dong Q, He Q, et al. Kinetics and mechanisms of mitotic inheritance of DNA methylation and their roles in aging-associated methylome deterioration. Cell Res. 2020;30(11):980-996. doi:10.1038/s41422-020-0359-9

36. Charlton J, Downing TL, Smith ZD, Gu H, Clement K, Pop R, et al. Global delay in nascent strand DNA methylation. Nat Struct Mol Biol. 2018;25(4):327-332. doi:10.1038/s41594-018-0046-4

37. Haerter JO, Lövkvist C, Dodd IB, Sneppen K. Collaboration between CpG sites is needed for stable somatic inheritance of DNA methylation states. Nucleic Acids Res. 2014;42(4):2235-2244. doi:10.1093/nar/gkt1235

38. Lövkvist C, Dodd IB, Sneppen K, Haerter JO. DNA methylation in human epigenomes depends on local topology of CpG sites. Nucleic Acids Res. 2016;44(11):5123-5132. doi:10.1093/nar/gkw124

39. Rajavelu A, Jurkowska RZ, Fritz J, Jeltsch A. Function and disruption of DNA Methyltransferase 3a cooperative DNA binding and nucleoprotein filament formation. Nucleic Acids Res. 2012;40(2):569-580. doi:10.1093/nar/gkr753

40. Emperle M, Rajavelu A, Reinhardt R, Jurkowska RZ, Jeltsch A. Cooperative DNA Binding and Protein/DNA Fiber Formation Increases the Activity of the Dnmt3a DNA Methyltransferase. J Biol Chem. 2014;289(43):29602-29613. doi:10.1074/jbc.M114.572032

41. Eckhardt F, Lewin J, Cortese R, Rakyan VK, Attwood J, Burger M, et al. DNA methylation profiling of human chromosomes 6, 20 and 22. Nat Genet. 2006;38(12):1378-1385. doi:10.1038/ng1909

42. Bachman M, Uribe-Lewis S, Yang X, Williams M, Murrell A, Balasubramanian S. 5-Hydroxymethylcytosine is a predominantly stable DNA modification. Nat Chem. 2014;6(12):1049-1055. doi:10.1038/nchem.2064

43. Kornack DR, Rakic P. Changes in cell-cycle kinetics during the development and evolution of primate neocortex. Proc Natl Acad Sci U S A. 1998;95(3):1242-1246. doi:10.1073/pnas.95.3.1242

44. Otani T, Marchetto MC, Gage FH, Simons BD, Livesey FJ. 2D and 3D Stem Cell Models of Primate Cortical Development Identify Species-Specific Differences in Progenitor Behavior Contributing to Brain Size. Cell Stem Cell. 2016;18(4):467-480. doi:10.1016/j.stem.2016.03.003

45. Malik S, Vinukonda G, Vose LR, Diamond D, Bhimavarapu BBR, Hu F, et al. Neurogenesis Continues in the Third Trimester of Pregnancy and Is Suppressed by Premature Birth. J Neurosci. 2013;33(2):411-423. doi:10.1523/JNEUROSCI.4445-12.2013

46. Bystron I, Blakemore C, Rakic P. Development of the human cerebral cortex: Boulder Committee revisited. Nat Rev Neurosci. 2008;9(2):110-122. doi:10.1038/nrn2252

47. Workman AD, Charvet CJ, Clancy B, Darlington RB, Finlay BL. Modeling Transformations of Neurodevelopmental Sequences across Mammalian Species. J Neurosci. 2013;33(17):7368-7383. doi:10.1523/JNEUROSCI.5746-12.2013

48. Lui JH, Hansen DV, Kriegstein AR. Development and Evolution of the Human Neocortex. Cell. 2011;146(1):18-36. doi:10.1016/j.cell.2011.06.030

49. Nowakowski TJ, Bhaduri A, Pollen AA, Alvarado B, Mostajo-Radji MA, Di Lullo E, et al. Spatiotemporal gene expression trajectories reveal developmental hierarchies of the human cortex. Science. 2017;358(6368):1318-1323. doi:10.1126/science.aap8809

50. Lister R, Mukamel EA, Nery JR, Urich M, Puddifoot CA, Johnson ND, et al. Global Epigenomic Reconfiguration During Mammalian Brain Development. Science. 2013;341(6146):1237905. doi:10.1126/science.1237905

51. Price AJ, Collado-Torres L, Ivanov NA, Xia W, Burke EE, Shin JH, et al. Divergent neuronal DNA methylation patterns across human cortical development reveal critical periods and a unique role of CpH methylation. Genome Biol. 2019;20(1):196. doi:10.1186/s13059-019-1805-1

52. Stroud H, Su SC, Hrvatin S, Greben AW, Renthal W, Boxer LD, et al. Early-Life Gene Expression in Neurons Modulates Lasting Epigenetic States. Cell. 2017;171(5):1151-1164.e16. doi:10.1016/j.cell.2017.09.047

53. Azevedo FA, Carvalho LR, Grinberg LT, Farfel JM, Ferretti RE, Leite RE, et al. Equal numbers of neuronal and nonneuronal cells make the human brain an isometrically scaled‐up primate brain. Journal of Comparative Neurology. 2009;513(5):532-541. doi:10.1002/cne.21974

54. Weisskopf MG, Seals RM, Webster TF. Bias Amplification in Epidemiologic Analysis of Exposure to Mixtures. Environ Health Perspect. 2018;126(4):047003. doi:10.1289/EHP2450

55. Leung M, Neophytou AM, Wilson A. Gestational misalignment with fixed exposure windows: the potential dangers of zero-filling in distributed lag models. Int J Epidemiol. 2026;55(5):dyag162. doi:10.1093/ije/dyag162

56. Lv J, Zhang Y, He J. Perinatal insults, genetic susceptibility, and the pathogenesis of neurodevelopmental disorders: from epigenetic remodeling to neural circuit dysfunction—a narrative review. Transl Pediatr. 2026;15(9):389-389. doi:10.21037/tp-2026-0615

57. Qi X, Zhang Y, Liu X, Xu Y, Jin C, Liang Z, et al. Epigenetic Regulation of Imprinted Genes in the Neurodevelopment of Offspring Born to Women with Preeclampsia: A Review. Int J Womens Health. 2026;Volume 18:1-8. doi:10.2147/IJWH.S598686

58. Almeida-Toledano L, Navarro-Tapia E, Sebastiani G, Ferrero-Martínez S, Ferrer-Aguilar P, García-Algar Ó, et al. Effect of prenatal phthalate exposure on fetal development and maternal/neonatal health consequences: A systematic review. Sci Total Environ. 2024;950:175080. doi:10.1016/j.scitotenv.2024.175080
