#!/usr/bin/env python3
"""
01_extract_methylation_stats.py

Single-pass, memory-bounded extraction of per-probe developmental statistics from
the human fetal brain Illumina 450K methylome series matrix (GEO: GSE58885;
Spiers et al., Genome Res 2015).

For every CpG probe this script computes:
  * n valid observations, mean and SD of beta
  * ordinary-least-squares regression of beta on post-conception week (pcw):
    slope, intercept, residual SD, standard error of slope, t statistic, R^2
  * mean and unbiased variance of beta within 13 gestational-age bins

Outputs a compressed .npz consumed by downstream scripts. Runtime is a few
minutes on one core; peak memory stays below ~1 GB by streaming in row chunks.

Usage:
  python 01_extract_methylation_stats.py --matrix <series_matrix.txt.gz> \
      --meta <gse58885_meta.csv> --out <results/methylation_probe_stats.npz>
"""
from __future__ import annotations

import argparse
import csv
import gzip
import sys

import numpy as np
import pandas as pd

# Gestational-age bins (post-conception weeks). Left-closed, right-open.
# Chosen so that every bin holds >= 6 donors in GSE58885.
BIN_EDGES = [3, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 27]
CHUNK_ROWS = 25_000


def read_sample_order(matrix_path: str) -> list[str]:
    """Return the GSM accessions in column order, read from the matrix header."""
    with gzip.open(matrix_path, "rt") as fh:
        for line in fh:
            if line.startswith("!Sample_geo_accession"):
                return [tok.strip().strip('"') for tok in line.rstrip("\n").split("\t")[1:]]
            if line.startswith("!series_matrix_table_begin"):
                break
    raise RuntimeError("!Sample_geo_accession line not found in matrix header")


def read_metadata(meta_path: str) -> dict[str, tuple[float, str]]:
    """Map GSM -> (days post-conception, sex)."""
    out: dict[str, tuple[float, str]] = {}
    with open(meta_path, newline="") as fh:
        for row in csv.DictReader(fh):
            dpc = row.get("days post-conception", "").strip()
            if dpc:
                out[row["gsm"].strip()] = (float(dpc), row.get("gender", "").strip())
    return out


def header_offset(matrix_path: str) -> int:
    """Number of lines to skip so that pandas starts at the ID_REF header row."""
    with gzip.open(matrix_path, "rt") as fh:
        for i, line in enumerate(fh):
            if line.startswith("!series_matrix_table_begin"):
                return i + 1
    raise RuntimeError("!series_matrix_table_begin not found")


def nan_ols(Y: np.ndarray, x: np.ndarray):
    """NaN-aware vectorised simple linear regression of each row of Y on x.

    Y : (p, n) array of responses, may contain NaN
    x : (n,) array of predictors
    Returns slope, intercept, resid_sd, se_slope, tstat, r2, nvalid.
    """
    mask = np.isfinite(Y)
    Xb = np.broadcast_to(x, Y.shape)
    Yz = np.where(mask, Y, 0.0)
    Xz = np.where(mask, Xb, 0.0)

    n = mask.sum(axis=1).astype(np.float64)
    Sx = Xz.sum(axis=1)
    Sy = Yz.sum(axis=1)
    Sxx = (Xz * Xz).sum(axis=1)
    Sxy = (Xz * Yz).sum(axis=1)
    Syy = (Yz * Yz).sum(axis=1)

    with np.errstate(divide="ignore", invalid="ignore"):
        denom = n * Sxx - Sx * Sx
        slope = (n * Sxy - Sx * Sy) / denom
        intercept = (Sy - slope * Sx) / n
        # residual sum of squares, computed from sufficient statistics
        ss_tot = Syy - Sy * Sy / n
        ss_res = ss_tot - slope * (Sxy - Sx * Sy / n)
        ss_res = np.maximum(ss_res, 0.0)
        dof = np.maximum(n - 2.0, 1.0)
        resid_sd = np.sqrt(ss_res / dof)
        sxx_c = Sxx - Sx * Sx / n
        se_slope = resid_sd / np.sqrt(np.maximum(sxx_c, 1e-12))
        tstat = slope / se_slope
        r2 = 1.0 - ss_res / np.where(ss_tot > 0, ss_tot, np.nan)

    bad = ~np.isfinite(denom) | (n < 4)
    for arr in (slope, intercept, resid_sd, se_slope, tstat, r2):
        arr[bad] = np.nan
    return slope, intercept, resid_sd, se_slope, tstat, r2, n


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    gsms = read_sample_order(args.matrix)
    meta = read_metadata(args.meta)
    missing = [g for g in gsms if g not in meta]
    if missing:
        raise RuntimeError(f"{len(missing)} samples lack metadata, e.g. {missing[:3]}")

    dpc = np.array([meta[g][0] for g in gsms], dtype=np.float64)
    sex = np.array([meta[g][1] for g in gsms])
    pcw = dpc / 7.0
    print(f"[info] {len(gsms)} samples, pcw range {pcw.min():.2f}-{pcw.max():.2f}", flush=True)

    # Bin assignment
    bin_idx = np.digitize(pcw, BIN_EDGES, right=False) - 1
    n_bins = len(BIN_EDGES) - 1
    bin_members = [np.where(bin_idx == b)[0] for b in range(n_bins)]
    bin_centres = np.array([pcw[m].mean() for m in bin_members])
    bin_counts = np.array([len(m) for m in bin_members])
    print("[info] bin counts:", bin_counts.tolist(), flush=True)
    print("[info] bin centres:", np.round(bin_centres, 2).tolist(), flush=True)

    skip = header_offset(args.matrix)
    reader = pd.read_csv(
        args.matrix,
        sep="\t",
        skiprows=skip,
        header=0,
        index_col=0,
        chunksize=CHUNK_ROWS,
        comment="!",
        na_values=["", "NA", "null", "NaN"],
        quotechar='"',
        low_memory=False,
    )

    probe_ids: list[np.ndarray] = []
    acc = {k: [] for k in
           ("mean", "sd", "slope", "intercept", "resid_sd", "se_slope", "t", "r2", "n")}
    bin_mean_parts, bin_var_parts = [], []
    sample_sum = np.zeros(len(gsms))
    sample_cnt = np.zeros(len(gsms))

    total = 0
    for ci, chunk in enumerate(reader):
        chunk = chunk.reindex(columns=gsms)
        Y = chunk.to_numpy(dtype=np.float32, na_value=np.nan).astype(np.float64, copy=False)
        keep = np.isfinite(Y).sum(axis=1) >= 4
        Y = Y[keep]
        ids = chunk.index.to_numpy()[keep]
        if Y.size == 0:
            continue
        probe_ids.append(np.asarray([str(s).strip().strip('"') for s in ids]))

        acc["mean"].append(np.nanmean(Y, axis=1))
        acc["sd"].append(np.nanstd(Y, axis=1, ddof=1))
        sl, ic, rsd, se, tt, r2, nn = nan_ols(Y, pcw)
        acc["slope"].append(sl); acc["intercept"].append(ic)
        acc["resid_sd"].append(rsd); acc["se_slope"].append(se)
        acc["t"].append(tt); acc["r2"].append(r2); acc["n"].append(nn)

        bm = np.empty((Y.shape[0], n_bins)); bv = np.empty((Y.shape[0], n_bins))
        with np.errstate(invalid="ignore"):
            for b, members in enumerate(bin_members):
                sub = Y[:, members]
                bm[:, b] = np.nanmean(sub, axis=1)
                bv[:, b] = np.nanvar(sub, axis=1, ddof=1)
        bin_mean_parts.append(bm.astype(np.float32))
        bin_var_parts.append(bv.astype(np.float32))

        finite = np.isfinite(Y)
        sample_sum += np.where(finite, Y, 0.0).sum(axis=0)
        sample_cnt += finite.sum(axis=0)

        total += Y.shape[0]
        if ci % 4 == 0:
            print(f"[info] chunk {ci}: {total} probes processed", flush=True)

    print(f"[info] total probes retained: {total}", flush=True)
    out = {
        "probe_id": np.concatenate(probe_ids),
        "bin_edges": np.array(BIN_EDGES, dtype=np.float64),
        "bin_centres": bin_centres,
        "bin_counts": bin_counts,
        "pcw": pcw,
        "dpc": dpc,
        "sex": sex,
        "gsm": np.array(gsms),
        "sample_global_mean": sample_sum / np.maximum(sample_cnt, 1),
        "bin_mean": np.concatenate(bin_mean_parts, axis=0),
        "bin_var": np.concatenate(bin_var_parts, axis=0),
    }
    for k, v in acc.items():
        out[k] = np.concatenate(v).astype(np.float32)

    np.savez_compressed(args.out, **out)
    print(f"[done] wrote {args.out}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
