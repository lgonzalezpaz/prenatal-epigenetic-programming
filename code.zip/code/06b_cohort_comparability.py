#!/usr/bin/env python3
"""
06b_cohort_comparability.py

Diagnostic that distinguishes three explanations for a failure of the per-CpG
developmental slopes to agree between GSE58885 (discovery) and GSE74193
(replication) over the same gestational window:

  (i)  the two datasets are not comparable at all (processing, annotation or
       platform mismatch), which would also destroy the agreement of per-probe
       MEAN methylation;
  (ii) the slopes disagree because the replication cohort lacks power, which an
       attenuation calculation can settle;
  (iii) the datasets are comparable and adequately powered, in which case the
       developmental signal itself differs between a whole fetal brain
       dissection and a dorsolateral prefrontal cortex dissection.

The script recomputes, from the replication matrix, each probe's mean, its
developmental slope and the residual variance, and compares all three with the
discovery cohort restricted to the same window. It also measures how much of
each cohort's developmental signal is explained by the first few principal
components, which in bulk fetal tissue track cell composition.

Usage:
  python 06b_cohort_comparability.py --proc <GSE74193_procData.csv.gz> \
      --meta <gse74193_meta.csv> --probes results/methylation_probe_stats.npz \
      --annot results/probe_annotation.csv.gz --beta results/beta_matrix.npy \
      --outdir results
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd

import importlib.util
import pathlib

_here = pathlib.Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location("ic", _here / "06_independent_cohort.py")
ic = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ic)


def slopes_and_stats(mat: np.ndarray, ages: np.ndarray):
    xc = ages - ages.mean()
    sxx = float(xc @ xc)
    mu = mat.mean(axis=1)
    slope = (mat - mu[:, None]) @ xc / sxx
    pred = mu[:, None] + slope[:, None] * xc[None, :]
    resid = mat - pred
    s2 = (resid ** 2).sum(axis=1) / max(len(ages) - 2, 1)
    return mu, slope, s2 / sxx, s2


def pc_share(mat: np.ndarray, ages: np.ndarray, npc: int = 3):
    """Fraction of the age signal captured by the leading principal components."""
    Xc = mat - mat.mean(axis=1, keepdims=True)
    G = Xc.T @ Xc
    w, V = np.linalg.eigh(G)
    order = np.argsort(w)[::-1]
    w = w[order]; V = V[:, order]
    out = {"var_share": (w[:npc] / w.sum()).tolist()}
    for i in range(npc):
        r = float(np.corrcoef(ages, V[:, i])[0, 1])
        out[f"pc{i+1}_age_r"] = r
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proc", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--probes", required=True)
    ap.add_argument("--annot", required=True)
    ap.add_argument("--beta", default="results/beta_matrix.npy")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    pren = ic.load_meta(args.meta)
    st = np.load(args.probes, allow_pickle=True)
    annot = pd.read_csv(args.annot, low_memory=False).set_index("probe_id")
    annot = annot.reindex(st["probe_id"])
    ok = (annot["sex_chrom"].to_numpy() == 0) & (annot["has_snp"].to_numpy() == 0)
    pid_d = np.asarray(st["probe_id"])[ok]
    probe_keep = set(pid_d.tolist())

    ids, B = ic.stream_betas(args.proc, pren["sample_tag"].tolist(), probe_keep)
    print(f"[info] replication matrix {B.shape}", flush=True)

    pren = pren.reset_index(drop=True)
    key = pren["brnum"].astype(str) + "_" + pren["pcw"].round(3).astype(str)
    uniq = key.unique()
    Bs = np.empty((B.shape[0], len(uniq)), dtype=np.float64)
    pcw_r = np.empty(len(uniq))
    for j, k in enumerate(uniq):
        sel = np.where((key == k).to_numpy())[0]
        Bs[:, j] = np.nanmean(B[:, sel], axis=1)
        pcw_r[j] = pren["pcw"].to_numpy()[sel][0]
    good = np.all(np.isfinite(Bs), axis=1)
    Bs = Bs[good]; ids = ids[good]
    print(f"[info] {Bs.shape[1]} replication samples, {Bs.shape[0]} complete probes",
          flush=True)

    mu_r, sl_r, se2_r, s2_r = slopes_and_stats(Bs, pcw_r)

    # discovery, restricted to the same window
    pcw_d = st["pcw"].astype(float)
    Bd = np.load(args.beta, mmap_mode="r")
    Bd = np.ascontiguousarray(Bd[ok], dtype=np.float64)
    win = (pcw_d >= pcw_r.min() - 0.1) & (pcw_d <= pcw_r.max() + 0.1)
    print(f"[info] discovery donors in the same window: {int(win.sum())}", flush=True)
    mu_d, sl_d, se2_d, s2_d = slopes_and_stats(Bd[:, win], pcw_d[win])

    pos = {p: i for i, p in enumerate(pid_d.tolist())}
    sel_d = np.array([pos[p] for p in ids])
    mu_d2, sl_d2, se2_d2 = mu_d[sel_d], sl_d[sel_d], se2_d[sel_d]

    # ---- (i) comparability of probe means --------------------------------
    r_mu = float(np.corrcoef(mu_r, mu_d2)[0, 1])
    rmse_mu = float(np.sqrt(np.mean((mu_r - mu_d2) ** 2)))
    print(f"\n[control] per-probe MEAN methylation agreement: r = {r_mu:.4f}, "
          f"RMSE = {rmse_mu:.4f} beta units", flush=True)

    # ---- (ii) attenuation-corrected expectation for slopes ---------------
    var_true_d = max(float(np.var(sl_d2, ddof=1)) - float(np.mean(se2_d2)), 0.0)
    var_true_r = max(float(np.var(sl_r, ddof=1)) - float(np.mean(se2_r)), 0.0)
    exp_r = var_true_d / np.sqrt((var_true_d + float(np.mean(se2_d2)))
                                 * (var_true_d + float(np.mean(se2_r))))
    obs_r = float(np.corrcoef(sl_r, sl_d2)[0, 1])
    ra = np.argsort(np.argsort(sl_r)); rb = np.argsort(np.argsort(sl_d2))
    obs_rho = float(np.corrcoef(ra, rb)[0, 1])
    conc = float(np.mean(np.sign(sl_r) == np.sign(sl_d2)))
    print(f"[slopes] observed r = {obs_r:.4f}, rho = {obs_rho:.4f}, "
          f"sign concordance = {conc:.4f}", flush=True)
    print(f"[slopes] expected r under a perfect shared signal = {exp_r:.4f} "
          f"(discovery reliability {var_true_d/max(var_true_d+np.mean(se2_d2),1e-12):.3f}, "
          f"replication reliability {var_true_r/max(var_true_r+np.mean(se2_r),1e-12):.3f})",
          flush=True)
    disagreement = obs_r / exp_r if exp_r > 0 else np.nan
    print(f"[slopes] observed / expected = {disagreement:.3f}", flush=True)

    # same test on the probes with the strongest discovery signal
    top = np.argsort(-np.abs(sl_d2))[: max(len(sl_d2) // 20, 100)]
    print(f"[slopes] top 5% by discovery effect: r = "
          f"{np.corrcoef(sl_r[top], sl_d2[top])[0,1]:.4f}, sign concordance = "
          f"{np.mean(np.sign(sl_r[top]) == np.sign(sl_d2[top])):.4f}", flush=True)

    # ---- (iii) is each cohort's own age signal internally consistent? ----
    # split-half within each cohort: do independent halves of donors agree?
    rng = np.random.default_rng(20261027)
    def split_half(mat, ages, nrep=20):
        out = []
        n = len(ages)
        for _ in range(nrep):
            idx = rng.permutation(n)
            h1, h2 = idx[: n // 2], idx[n // 2:]
            if len(set(np.round(ages[h1], 1))) < 3 or len(set(np.round(ages[h2], 1))) < 3:
                continue
            _, s1, _, _ = slopes_and_stats(mat[:, h1], ages[h1])
            _, s2, _, _ = slopes_and_stats(mat[:, h2], ages[h2])
            out.append(float(np.corrcoef(s1, s2)[0, 1]))
        return out

    sh_d = split_half(Bd[:, win][sel_d], pcw_d[win])
    sh_r = split_half(Bs, pcw_r)
    print(f"\n[internal] discovery split-half slope agreement: "
          f"{np.mean(sh_d):.3f} (SD {np.std(sh_d):.3f}, {len(sh_d)} splits)",
          flush=True)
    print(f"[internal] replication split-half slope agreement: "
          f"{np.mean(sh_r):.3f} (SD {np.std(sh_r):.3f}, {len(sh_r)} splits)",
          flush=True)

    pc_d = pc_share(Bd[:, win][sel_d], pcw_d[win])
    pc_r = pc_share(Bs, pcw_r)
    print(f"\n[composition] discovery PC1 variance share "
          f"{pc_d['var_share'][0]:.3f}, PC1-age r = {pc_d['pc1_age_r']:+.3f}",
          flush=True)
    print(f"[composition] replication PC1 variance share "
          f"{pc_r['var_share'][0]:.3f}, PC1-age r = {pc_r['pc1_age_r']:+.3f}",
          flush=True)

    out = {
        "n_probes": int(len(ids)),
        "n_discovery_donors_in_window": int(win.sum()),
        "n_replication_samples": int(Bs.shape[1]),
        "window_pcw": [float(pcw_r.min()), float(pcw_r.max())],
        "probe_mean_r": r_mu, "probe_mean_rmse": rmse_mu,
        "slope_observed_r": obs_r, "slope_observed_rho": obs_rho,
        "slope_sign_concordance": conc,
        "slope_expected_r_perfect_signal": float(exp_r),
        "slope_observed_over_expected": float(disagreement),
        "discovery_slope_reliability": float(var_true_d / max(var_true_d + np.mean(se2_d2), 1e-12)),
        "replication_slope_reliability": float(var_true_r / max(var_true_r + np.mean(se2_r), 1e-12)),
        "discovery_split_half_mean": float(np.mean(sh_d)) if sh_d else None,
        "replication_split_half_mean": float(np.mean(sh_r)) if sh_r else None,
        "discovery_pc": pc_d, "replication_pc": pc_r,
    }
    os.makedirs(args.outdir, exist_ok=True)
    with open(os.path.join(args.outdir, "cohort_comparability.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    np.savez_compressed(
        os.path.join(args.outdir, "cohort_slopes.npz"),
        probe_id=ids, slope_rep=sl_r, slope_disc=sl_d2,
        mean_rep=mu_r, mean_disc=mu_d2, se2_rep=se2_r, se2_disc=se2_d2,
        pcw_rep=pcw_r, split_half_disc=np.asarray(sh_d),
        split_half_rep=np.asarray(sh_r),
    )
    print("\n[done] wrote cohort_comparability.json, cohort_slopes.npz", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
