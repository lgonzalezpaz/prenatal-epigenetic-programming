#!/usr/bin/env python3
"""
08_third_trimester_scenarios.py

What the data cannot settle, stated explicitly.

GSE58885 contains one sample beyond 182 days post-conception and none in the
third trimester, and GSE74193 is second-trimester only, so no human fetal brain
methylome dataset constrains remodelling intensity after about 20 post-conception
weeks. The permanence kernel of script 05 therefore extrapolates inducibility
beyond the measured range by exponential decay at the rate fitted to the
terminal measured segment. This script asks how the conclusion changes under
alternative, deliberately unfavourable assumptions about that unmeasured
interval, including one in which inducibility rises again in late gestation as
would be expected if the synaptogenesis-associated methylome reconfiguration
described by Lister et al. (2013) began before term.

Scenarios for inducibility after the last measured week t_max:
  measured_decline  S(t) = S(t_max) exp(-gamma_hat (t - t_max))
  slow_decline      S(t) = S(t_max) exp(-gamma_hat/2 (t - t_max))
  plateau           S(t) = S(t_max)
  late_rise         S(t) = S(t_max) (1 + r_late . ramp(t)) with a ramp rising
                    linearly from t_max to term
  late_surge        as late_rise with a larger amplitude

For each scenario the global maximum of the permanence kernel, any secondary
local maximum after 20 pcw, and the ratio of the two are reported, with
uncertainty propagated over the same priors as script 05.

Usage:
  python 08_third_trimester_scenarios.py --remodelling results/cumulative_remodelling_primary.csv \
      --outdir results [--ndraw 4000]
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd

import importlib.util
import pathlib

_here = pathlib.Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location("pm", _here / "05_permanence_model.py")
pm = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(pm)

RNG_SEED = 20261027
GRID = np.arange(pm.GRID_LO, pm.GRID_HI + 1e-9, pm.GRID_STEP)


def inducibility_scenario(obs_pcw, obs_phi, grid, gamma, scenario, r_late=0.0):
    lo, hi = obs_pcw.min(), obs_pcw.max()
    S = np.interp(grid, obs_pcw, obs_phi)
    S = pm.kernel_smooth(grid, S, np.ones_like(grid), grid, 0.5)
    s_hi = float(np.interp(hi, obs_pcw, obs_phi))
    s_lo = float(np.interp(lo, obs_pcw, obs_phi))
    above = grid > hi
    below = grid < lo
    if scenario == "plateau":
        tail = np.full(grid.shape, s_hi)
    elif scenario in ("late_rise", "late_surge"):
        ramp = np.clip((grid - hi) / max(40.0 - hi, 1e-6), 0.0, 1.0)
        tail = s_hi * (1.0 + r_late * ramp)
    else:
        tail = s_hi * np.exp(-gamma * (grid - hi))
    S = np.where(above, tail, S)
    S = np.where(below, s_lo * np.exp(-gamma * (lo - grid)), S)
    return np.maximum(S, 1e-10), (lo, hi)


def local_maxima(grid, P, lo, hi):
    sel = (grid >= lo) & (grid <= hi) & np.isfinite(P)
    g, p = grid[sel], P[sel]
    out = []
    for i in range(1, len(g) - 1):
        if p[i] >= p[i - 1] and p[i] > p[i + 1]:
            out.append((float(g[i]), float(p[i])))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--remodelling", default="results/cumulative_remodelling_primary.csv")
    ap.add_argument("--genes", default="results/brainspan_genes.csv")
    ap.add_argument("--modules", default="results/brainspan_modules.csv")
    ap.add_argument("--profiles", default="results/empirical_profiles.npz")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--ndraw", type=int, default=4000)
    args = ap.parse_args()

    rem = pd.read_csv(args.remodelling)
    obs_pcw = rem["pcw"].to_numpy(); obs_phi = rem["Phi"].to_numpy()
    sd_phi = np.maximum((rem["Phi_hi95"].to_numpy() - rem["Phi_lo95"].to_numpy())
                        / (2 * 1.959964), 1e-6)
    prof = np.load(args.profiles, allow_pickle=True)
    mbar = float(np.nanmean(prof["mean_beta"]))
    act = pm.build_activities(args.genes, args.modules, GRID)

    tail = obs_pcw >= obs_pcw[int(np.nanargmax(obs_phi))]
    gamma_hat = float(-np.polyfit(obs_pcw[tail],
                                  np.log(np.maximum(obs_phi[tail], 1e-8)), 1)[0])
    print(f"[info] measured terminal decline gamma_hat = {gamma_hat:.3f} /week; "
          f"last measured week = {obs_pcw.max():.2f} pcw", flush=True)

    scenarios = [
        ("measured_decline", gamma_hat, 0.0),
        ("slow_decline", gamma_hat / 2.0, 0.0),
        ("plateau", 0.0, 0.0),
        ("late_rise", 0.0, 0.5),
        ("late_surge", 0.0, 2.0),
    ]

    rng = np.random.default_rng(RNG_SEED)
    N = args.ndraw

    def lognorm_range(lo, hi, size):
        mu = 0.5 * (np.log(lo) + np.log(hi))
        sd = (np.log(hi) - np.log(lo)) / (2 * 1.959964)
        return np.exp(rng.normal(mu, sd, size))

    rho0 = lognorm_range(0.076, 0.30, N)
    eta = lognorm_range(1.0, 10.0, N)
    c_coop = rng.uniform(0.0, 0.5, N)
    horizon = rng.uniform(37.0, 42.0, N)

    rows, curves = [], {"pcw": GRID}
    for name, gam, r_late in scenarios:
        glob_peaks, late_peaks, ratios = [], [], []
        for i in range(N):
            phi_i = np.maximum(obs_phi + rng.normal(0, sd_phi), 1e-8)
            S_i, _ = inducibility_scenario(obs_pcw, phi_i, GRID, gam, name, r_late)
            k_i, _, _ = pm.relaxation_rate(GRID, act, S_i, mbar, rho0[i],
                                           eta[i], c_coop[i])
            _, P_i = pm.permanence(GRID, S_i, k_i, horizon[i])
            gp = pm.peak_of(GRID, P_i, 9.0, 36.0)
            glob_peaks.append(gp)
            mx = local_maxima(GRID, P_i, 20.0, 36.0)
            if mx:
                w, v = max(mx, key=lambda z: z[1])
                late_peaks.append(w)
                early = np.nanmax(np.where((GRID >= 9) & (GRID <= 20), P_i, np.nan))
                ratios.append(v / early if early > 0 else np.nan)
        gp = np.asarray(glob_peaks); gp = gp[np.isfinite(gp)]
        S_c, _ = inducibility_scenario(obs_pcw, obs_phi, GRID, gam, name, r_late)
        k_c, _, _ = pm.relaxation_rate(GRID, act, S_c, mbar,
                                       float(np.median(rho0)),
                                       float(np.median(eta)), 0.25)
        _, P_c = pm.permanence(GRID, S_c, k_c, 40.0)
        curves[f"P_{name}"] = P_c / np.nanmax(P_c)
        curves[f"S_{name}"] = S_c
        row = {
            "scenario": name, "gamma": gam, "late_amplitude": r_late,
            "global_peak_median_pcw": float(np.median(gp)),
            "global_peak_lo95": float(np.percentile(gp, 2.5)),
            "global_peak_hi95": float(np.percentile(gp, 97.5)),
            "frac_global_peak_after_20pcw": float(np.mean(gp > 20.0)),
            "frac_draws_with_late_local_max": float(len(late_peaks) / N),
            "late_local_max_median_pcw": float(np.median(late_peaks)) if late_peaks else np.nan,
            "late_to_early_height_ratio_median": float(np.nanmedian(ratios)) if ratios else np.nan,
        }
        rows.append(row)
        print(f"[result] {name:17s} global peak "
              f"{row['global_peak_median_pcw']:.2f} pcw "
              f"[{row['global_peak_lo95']:.2f}, {row['global_peak_hi95']:.2f}]; "
              f"P(peak > 20 pcw) = {row['frac_global_peak_after_20pcw']:.3f}; "
              f"late local maximum in {row['frac_draws_with_late_local_max']:.2f} "
              f"of draws", flush=True)

    os.makedirs(args.outdir, exist_ok=True)
    pd.DataFrame(rows).to_csv(
        os.path.join(args.outdir, "third_trimester_scenarios.csv"), index=False)
    pd.DataFrame(curves).to_csv(
        os.path.join(args.outdir, "third_trimester_curves.csv"), index=False)
    with open(os.path.join(args.outdir, "third_trimester_summary.json"), "w") as fh:
        json.dump({"gamma_hat": gamma_hat,
                   "last_measured_pcw": float(obs_pcw.max()),
                   "n_draws": N, "scenarios": rows}, fh, indent=2)
    print("[done] wrote third_trimester_scenarios.csv, third_trimester_curves.csv, "
          "third_trimester_summary.json", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
