#!/usr/bin/env python3
"""
02_brainspan_machinery.py

Extracts developmental expression trajectories of DNA-methylation machinery,
cell-cycle, progenitor and post-mitotic neuronal gene modules from the BrainSpan
Developmental Transcriptome (RNA-seq, Gencode v10, gene-level RPKM).

Trajectories are restricted to neocortical samples and summarised per
post-conception week (pcw). Module scores are means of per-gene z-scores of
log2(RPKM + 1) computed across the fetal neocortical samples, so each module
score is dimensionless and centred on the fetal period.

Outputs results/brainspan_modules.csv (one row per pcw) and
results/brainspan_genes.csv (one row per gene per pcw).

Usage:
  python 02_brainspan_machinery.py --dir <brainspan_csv_dir> --outdir results
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd

# Neocortical structure acronyms used by BrainSpan (early coarse + later fine).
NEOCORTEX = {
    "Ocx", "PCx", "TCx", "M1C-S1C", "DFC", "VFC", "MFC", "OFC",
    "M1C", "S1C", "IPC", "A1C", "STC", "ITC", "V1C",
}

MODULES: dict[str, list[str]] = {
    # Canonical S/G2M cell-cycle programme: proxy for the proliferative fraction
    "cell_cycle": [
        "MKI67", "TOP2A", "CCNB1", "CCNB2", "CDK1", "PCNA", "AURKA", "AURKB",
        "BUB1", "CENPF", "PLK1", "MCM2", "MCM3", "MCM7", "TYMS", "RRM2",
        "E2F1", "CCNA2", "CDC20", "FOXM1", "ASPM", "NUSAP1", "UBE2C", "BIRC5",
        "TK1", "GINS2", "CDC6", "CHEK1",
    ],
    # Apical/basal neural progenitors
    "progenitor": [
        "PAX6", "SOX2", "HES1", "HES5", "VIM", "NES", "FABP7", "SLC1A3",
        "EOMES", "HOPX", "GLI3", "SOX9",
    ],
    # Post-mitotic neurons
    "postmitotic_neuron": [
        "RBFOX3", "SYN1", "SNAP25", "MAP2", "NEFL", "STMN2", "SYT1",
        "TBR1", "SATB2", "BCL11B", "NEFM", "SYP",
    ],
    # Maintenance methylation
    "maintenance_methylation": ["DNMT1", "UHRF1"],
    # De novo methylation
    "de_novo_methylation": ["DNMT3A", "DNMT3B", "DNMT3L"],
    # Active demethylation
    "demethylation": ["TET1", "TET2", "TET3", "TDG", "GADD45A", "GADD45B"],
    # Methyl-CpG readers (cooperative reinforcement of the methylated state)
    "mcpg_readers": ["MECP2", "MBD1", "MBD2", "MBD3", "MBD4", "ZBTB33"],
    # One-carbon / S-adenosylmethionine supply (environmental coupling node)
    "one_carbon": [
        "MAT2A", "MAT2B", "AHCY", "MTR", "MTRR", "MTHFR", "SHMT1", "SHMT2",
        "BHMT", "CBS", "SLC19A1", "FOLR1",
    ],
    # Repressive chromatin writers that co-stabilise methylated states
    "repressive_chromatin": [
        "EZH2", "SUZ12", "EED", "SETDB1", "SUV39H1", "SUV39H2", "CBX5",
    ],
    # Oxidative-stress / inflammation responsive nodes (environmental coupling)
    "redox_inflammation": [
        "NFE2L2", "HMOX1", "SOD1", "SOD2", "CAT", "GPX1", "TXN", "NQO1",
        "NFKB1", "IL6ST", "STAT3",
    ],
}

# Individually tracked genes (reported gene-by-gene in the manuscript)
FOCUS_GENES = sorted({
    g for m in ("maintenance_methylation", "de_novo_methylation",
                "demethylation", "mcpg_readers") for g in MODULES[m]
} | {"MKI67", "PAX6", "SOX2", "EOMES", "RBFOX3", "SATB2", "MECP2", "CHD8"})


def parse_age(age: str) -> tuple[float, str]:
    """Convert a BrainSpan age label to (pcw_equivalent, period).

    Postnatal ages are mapped to pcw = 40 + weeks since birth, which keeps the
    axis monotone; only the prenatal samples are used for model fitting.
    """
    age = age.strip().strip('"')
    val, unit = age.split()
    v = float(val)
    if unit == "pcw":
        return v, "prenatal"
    if unit == "mos":
        return 40.0 + v * 4.345, "postnatal"
    if unit == "yrs":
        return 40.0 + v * 52.14, "postnatal"
    raise ValueError(f"unrecognised age unit: {age}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="directory with BrainSpan csv files")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    cols = pd.read_csv(os.path.join(args.dir, "columns_metadata.csv"))
    rows = pd.read_csv(os.path.join(args.dir, "rows_metadata.csv"))
    print(f"[info] {len(cols)} samples, {len(rows)} genes", flush=True)

    ages = cols["age"].apply(parse_age)
    cols["pcw"] = [a[0] for a in ages]
    cols["period"] = [a[1] for a in ages]
    cols["is_ncx"] = cols["structure_acronym"].str.strip().str.strip('"').isin(NEOCORTEX)

    wanted = sorted({g for gs in MODULES.values() for g in gs})
    sym = rows["gene_symbol"].astype(str).str.strip().str.strip('"')
    sel = rows.index[sym.isin(wanted)].to_numpy()          # 0-based row positions
    sel_sym = sym.iloc[sel].to_numpy()
    print(f"[info] {len(sel)} of {len(wanted)} requested gene symbols found", flush=True)
    missing = sorted(set(wanted) - set(sel_sym))
    if missing:
        print(f"[warn] not in BrainSpan: {missing}", flush=True)

    # Stream the expression matrix, keeping only the selected rows.
    keep = set(sel.tolist())
    data = np.full((len(sel), len(cols)), np.nan, dtype=np.float64)
    pos = {r: i for i, r in enumerate(sel.tolist())}
    with open(os.path.join(args.dir, "expression_matrix.csv")) as fh:
        for i, line in enumerate(fh):
            if i in keep:
                parts = line.rstrip("\n").split(",")
                data[pos[i], :] = np.asarray(parts[1:], dtype=np.float64)
    print(f"[info] expression submatrix {data.shape}", flush=True)

    expr = pd.DataFrame(data, index=sel_sym, columns=cols["column_num"].astype(str))
    expr = expr.groupby(level=0).mean()                    # collapse duplicate symbols
    log_expr = np.log2(expr + 1.0)

    ncx_fetal = (cols["is_ncx"] & (cols["period"] == "prenatal")).to_numpy()
    print(f"[info] fetal neocortical samples: {ncx_fetal.sum()}", flush=True)

    # z-score each gene across fetal neocortical samples
    base = log_expr.loc[:, ncx_fetal]
    mu = base.mean(axis=1)
    sd = base.std(axis=1, ddof=1).replace(0.0, np.nan)
    z = log_expr.sub(mu, axis=0).div(sd, axis=0)

    fetal_cols = np.where(ncx_fetal)[0]
    pcw_vals = cols["pcw"].to_numpy()[fetal_cols]

    # ---- module trajectories per pcw -------------------------------------
    recs = []
    for w in sorted(set(pcw_vals)):
        idx = fetal_cols[pcw_vals == w]
        row = {"pcw": w, "n_samples": len(idx)}
        for mod, genes in MODULES.items():
            present = [g for g in genes if g in z.index]
            if not present:
                continue
            sub = z.iloc[:, idx].loc[present]
            row[mod] = float(np.nanmean(sub.to_numpy()))
            row[mod + "_sem"] = float(
                np.nanstd(np.nanmean(sub.to_numpy(), axis=0), ddof=1)
                / max(np.sqrt(len(idx)), 1.0)
            ) if len(idx) > 1 else np.nan
        recs.append(row)
    mod_df = pd.DataFrame(recs).sort_values("pcw")

    # ---- per-gene trajectories (log2 RPKM, mean per pcw) -----------------
    grecs = []
    for w in sorted(set(pcw_vals)):
        idx = fetal_cols[pcw_vals == w]
        for g in FOCUS_GENES:
            if g not in log_expr.index:
                continue
            vals = log_expr.iloc[:, idx].loc[g].to_numpy(dtype=float)
            grecs.append({
                "pcw": w, "gene": g, "n": len(idx),
                "log2_rpkm_mean": float(np.nanmean(vals)),
                "log2_rpkm_sd": float(np.nanstd(vals, ddof=1)) if len(vals) > 1 else np.nan,
            })
    gene_df = pd.DataFrame(grecs)

    os.makedirs(args.outdir, exist_ok=True)
    mod_df.to_csv(os.path.join(args.outdir, "brainspan_modules.csv"), index=False)
    gene_df.to_csv(os.path.join(args.outdir, "brainspan_genes.csv"), index=False)

    # Also export the full (prenatal + postnatal) module trajectory for context.
    all_recs = []
    for w in sorted(set(cols["pcw"][cols["is_ncx"]])):
        idx = np.where(cols["is_ncx"].to_numpy() & (cols["pcw"].to_numpy() == w))[0]
        row = {"pcw": w, "n_samples": len(idx),
               "period": cols["period"].to_numpy()[idx][0]}
        for mod, genes in MODULES.items():
            present = [g for g in genes if g in z.index]
            if present:
                row[mod] = float(np.nanmean(z.iloc[:, idx].loc[present].to_numpy()))
        all_recs.append(row)
    pd.DataFrame(all_recs).sort_values("pcw").to_csv(
        os.path.join(args.outdir, "brainspan_modules_lifespan.csv"), index=False)

    print(mod_df[["pcw", "n_samples", "cell_cycle", "progenitor",
                  "postmitotic_neuron", "maintenance_methylation",
                  "de_novo_methylation", "demethylation"]].to_string(index=False))
    print("[done] wrote brainspan_modules.csv, brainspan_genes.csv, "
          "brainspan_modules_lifespan.csv", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
