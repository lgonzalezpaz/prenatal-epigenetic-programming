#!/usr/bin/env python3
"""
01b_dump_beta_matrix.py

Second streaming pass over the GSE58885 series matrix that materialises the full
probe x sample beta matrix as a float32 .npy file (~0.3 GB for 408k x 179).
Holding the matrix in memory lets every downstream analysis (principal
components for cell-composition adjustment, donor-level bootstrap, drift-field
estimation) run in seconds without re-reading the 567 MB compressed archive.

Usage:
  python 01b_dump_beta_matrix.py --matrix <series_matrix.txt.gz> \
      --stats results/methylation_probe_stats.npz --outdir results
"""
from __future__ import annotations

import argparse
import gzip
import os

import numpy as np
import pandas as pd

CHUNK_ROWS = 25_000


def header_offset(path: str) -> int:
    with gzip.open(path, "rt") as fh:
        for i, line in enumerate(fh):
            if line.startswith("!series_matrix_table_begin"):
                return i + 1
    raise RuntimeError("table start not found")


def sample_order(path: str) -> list[str]:
    with gzip.open(path, "rt") as fh:
        for line in fh:
            if line.startswith("!Sample_geo_accession"):
                return [t.strip().strip('"') for t in line.rstrip("\n").split("\t")[1:]]
    raise RuntimeError("accession line not found")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    st = np.load(args.stats, allow_pickle=True)
    keep_ids = set(st["probe_id"].tolist())
    gsms = sample_order(args.matrix)
    order = {p: i for i, p in enumerate(st["probe_id"].tolist())}

    out = np.full((len(order), len(gsms)), np.nan, dtype=np.float32)
    skip = header_offset(args.matrix)
    reader = pd.read_csv(args.matrix, sep="\t", skiprows=skip, header=0,
                         index_col=0, chunksize=CHUNK_ROWS, comment="!",
                         na_values=["", "NA", "null", "NaN"], quotechar='"',
                         low_memory=False)
    n = 0
    for ci, chunk in enumerate(reader):
        chunk = chunk.reindex(columns=gsms)
        ids = [str(s).strip().strip('"') for s in chunk.index]
        rows = [(i, order[p]) for i, p in enumerate(ids) if p in keep_ids]
        if not rows:
            continue
        src = np.fromiter((r[0] for r in rows), dtype=np.int64, count=len(rows))
        dst = np.fromiter((r[1] for r in rows), dtype=np.int64, count=len(rows))
        vals = chunk.to_numpy(dtype=np.float32, na_value=np.nan)
        out[dst] = vals[src]
        n += len(rows)
        if ci % 5 == 0:
            print(f"[info] chunk {ci}: {n} rows placed", flush=True)

    os.makedirs(args.outdir, exist_ok=True)
    path = os.path.join(args.outdir, "beta_matrix.npy")
    np.save(path, out)
    print(f"[done] {path} shape={out.shape} "
          f"nan_frac={np.isnan(out).mean():.5f}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
