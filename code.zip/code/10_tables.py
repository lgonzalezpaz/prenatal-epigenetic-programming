#!/usr/bin/env python3
"""
10_tables.py

Assembles every manuscript table from the analysis outputs, writing each as a
CSV and as a Markdown block ready to paste into the manuscript.

Usage:
  python 10_tables.py --results results --outdir tables
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd


def load_json(path):
    with open(path) as fh:
        return json.load(fh)


def write(df: pd.DataFrame, outdir: str, name: str, caption: str,
          floatfmt: str = "%.3f"):
    df.to_csv(os.path.join(outdir, f"{name}.csv"), index=False)
    md = df.to_markdown(index=False, floatfmt=floatfmt.replace("%", "").replace("f", "f"))
    with open(os.path.join(outdir, f"{name}.md"), "w") as fh:
        fh.write(f"**{caption}**\n\n{md}\n")
    print(f"[table] {name}", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--outdir", default="tables")
    args = ap.parse_args()
    R, O = args.results, args.outdir
    os.makedirs(O, exist_ok=True)

    perm = load_json(os.path.join(R, "permanence_summary.json"))

    # ---- Table 1: datasets ----------------------------------------------
    st = np.load(os.path.join(R, "methylation_probe_stats.npz"), allow_pickle=True)
    pcw = st["pcw"].astype(float)
    rows = [
        {"Dataset": "GSE58885", "Reference": "Spiers et al. 2015",
         "Assay": "Illumina HumanMethylation450",
         "Tissue": "human fetal brain",
         "Samples": int(len(pcw)),
         "Age range (pcw)": f"{pcw.min():.1f}-{pcw.max():.1f}",
         "CpGs after QC": 335178,
         "Role": "discovery: remodelling intensity"},
    ]
    comp_path = os.path.join(R, "cohort_comparability.json")
    if os.path.exists(comp_path):
        cj = load_json(comp_path)
        rows.append({
            "Dataset": "GSE74193", "Reference": "Jaffe et al. 2016",
            "Assay": "Illumina HumanMethylation450",
            "Tissue": "human dorsolateral prefrontal cortex",
            "Samples": cj["n_replication_samples"],
            "Age range (pcw)": f"{cj['window_pcw'][0]:.1f}-{cj['window_pcw'][1]:.1f}",
            "CpGs after QC": cj["n_probes"],
            "Role": "independent replication"})
    bs = pd.read_csv(os.path.join(R, "brainspan_modules.csv"))
    rows.append({
        "Dataset": "BrainSpan", "Reference": "Kang et al. 2011",
        "Assay": "RNA-seq (GENCODE v10, gene-level RPKM)",
        "Tissue": "human neocortex", "Samples": int(bs["n_samples"].sum()),
        "Age range (pcw)": f"{bs['pcw'].min():.0f}-{bs['pcw'].max():.0f}",
        "CpGs after QC": "n/a (99 genes)",
        "Role": "proliferation and machinery trajectories"})
    write(pd.DataFrame(rows), O, "table1_datasets",
          "Table 1. Public datasets used, with the role of each in the analysis.")

    # ---- Table 2: parameters and priors ---------------------------------
    p = [
        {"Symbol": "rho_0", "Meaning": "peak replicative dilution rate",
         "Units": "week^-1", "Prior / value": "lognormal, 95% mass 0.076-0.30",
         "Basis": ("maintenance fidelity 0.960 (Laird 2004), 0.90-0.98 across "
                   "sites (Genereux 2005), 0.976 error-corrected (Fu 2010); "
                   "cell-cycle length 22.7-54.1 h (Kornack & Rakic 1998)")},
        {"Symbol": "eta", "Meaning": "gross-to-net enzymatic flux ratio",
         "Units": "dimensionless", "Prior / value": "lognormal, 95% mass 1-10",
         "Basis": "weakly informative; eta >= 1 by definition"},
        {"Symbol": "c_coop", "Meaning": "cooperative stabilisation of the methylated state",
         "Units": "dimensionless", "Prior / value": "uniform 0-0.5",
         "Basis": ("collaborative methylation required for somatic inheritance "
                   "(Haerter 2014; Lovkvist 2016)")},
        {"Symbol": "T", "Meaning": "retention horizon",
         "Units": "pcw", "Prior / value": "uniform 37-42",
         "Basis": "term birth"},
        {"Symbol": "gamma", "Meaning": "decline rate of inducibility beyond the measured range",
         "Units": "week^-1",
         "Prior / value": f"lognormal centred on {perm['gamma_terminal_decline_per_week']:.2f}",
         "Basis": "fitted to the terminal measured segment of Phi; varied in scenarios"},
        {"Symbol": "Phi(t)", "Meaning": "remodelling intensity (inducibility anchor)",
         "Units": "beta week^-1", "Prior / value": "measured, with donor bootstrap",
         "Basis": "GSE58885, 70,000 developmentally dynamic CpGs"},
        {"Symbol": "psi_P(t)", "Meaning": "proliferation profile",
         "Units": "relative (peak = 1)", "Prior / value": "measured",
         "Basis": "BrainSpan cell-cycle module, neocortex"},
    ]
    write(pd.DataFrame(p), O, "table2_parameters",
          "Table 2. Model parameters, prior distributions and their empirical basis.")

    # ---- Table 3: remodelling intensity by week -------------------------
    rem = pd.read_csv(os.path.join(R, "cumulative_remodelling_primary.csv"))
    # The estimation grid runs in quarter-week steps from the first bin centre
    # (8.357 pcw), so it never lands exactly on an integer week. Reporting
    # values at whole weeks therefore requires interpolation, not selection;
    # selecting on (pcw % 1 == 0) returns an empty table.
    weeks = np.arange(int(np.ceil(rem["pcw"].min())),
                      int(np.floor(rem["pcw"].max())) + 1)
    interp = lambda col: np.interp(weeks, rem["pcw"].to_numpy(),
                                   rem[col].to_numpy()) * 1e3
    t3 = pd.DataFrame({
        "Post-conception week": weeks,
        "Phi (x10^-3 beta/week)": interp("Phi").round(2),
        "95% CI lower": interp("Phi_lo95").round(2),
        "95% CI upper": interp("Phi_hi95").round(2),
        "Phi, equal n per week": interp("Phi_equal_n").round(2),
    })
    if t3.empty:
        raise RuntimeError("Table 3 is empty; check the remodelling grid")
    write(t3, O, "table3_remodelling_by_week",
          "Table 3. Measured epigenetic remodelling intensity by gestational week, "
          "with donor-bootstrap confidence intervals and the equal-sampling control.")

    # ---- Table 4: robustness of the measured peak -----------------------
    cr = np.load(os.path.join(R, "cumulative_remodelling_primary.npz"), allow_pickle=True)
    lobo = pd.read_csv(os.path.join(R, "leave_one_bin_out_primary.csv"))
    strata = pd.read_csv(os.path.join(R, "remodelling_strata_primary.csv"))
    pk = cr["peak_boot"]
    r4 = [
        {"Analysis": "Primary (all dynamic CpGs)",
         "Peak (pcw)": f"{cr['grid'][int(np.nanargmax(cr['Phi']))]:.2f}",
         "Note": f"bootstrap median {np.median(pk):.2f}, 95% CI "
                 f"{np.percentile(pk,2.5):.2f}-{np.percentile(pk,97.5):.2f}"},
        {"Analysis": "Equal donors per week",
         "Peak (pcw)": f"{cr['grid'][int(np.nanargmax(np.nanmean(cr['Phi_equal_n'],axis=0)))]:.2f}",
         "Note": f"n = {int(cr['n_equal'])} per week; rank correlation with "
                 f"primary rho = {float(cr['rank_corr_equal_n']):.3f}"},
        {"Analysis": "Leave one gestational bin out",
         "Peak (pcw)": f"{lobo['peak_pcw'].min():.2f}-{lobo['peak_pcw'].max():.2f}",
         "Note": f"range over {len(lobo)} analyses"},
    ]
    for s in strata["stratum"].unique():
        sub = strata[strata["stratum"] == s]
        if s == "dynamic_all":
            continue
        r4.append({"Analysis": f"Stratum: {s.replace('dyn_','')}",
                   "Peak (pcw)": f"{sub.loc[sub['Phi'].idxmax(),'pcw']:.2f}",
                   "Note": f"{int(sub['n_probes'].iloc[0]):,} CpGs"})
    write(pd.DataFrame(r4), O, "table4_robustness",
          "Table 4. Robustness of the measured remodelling peak.")

    # ---- Table 5: third-trimester scenarios -----------------------------
    sc = pd.read_csv(os.path.join(R, "third_trimester_scenarios.csv"))
    t5 = pd.DataFrame({
        "Scenario": sc["scenario"].str.replace("_", " "),
        "Global peak (pcw)": sc["global_peak_median_pcw"].round(2),
        "95% CI": [f"{a:.2f}-{b:.2f}" for a, b in
                   zip(sc["global_peak_lo95"], sc["global_peak_hi95"])],
        "P(peak after 20 pcw)": sc["frac_global_peak_after_20pcw"].round(3),
        "Draws with a late local maximum": sc["frac_draws_with_late_local_max"].round(2),
    })
    write(t5, O, "table6_scenarios",
          "Table 6. Sensitivity of the permanence window to assumptions about the "
          "unmeasured third trimester.")

    # ---- Table 6: identifiability ---------------------------------------
    ds = pd.read_csv(os.path.join(R, "deconvolution_settings.csv"))
    t6 = pd.DataFrame({
        "r(T1,T3)": ds["achieved_r_T1T3"].round(2),
        "Apparent OR, T1": ds["sep_T1_OR"].round(3),
        "Apparent OR, T2": ds["sep_T2_OR"].round(3),
        "Apparent OR, T3": ds["sep_T3_OR"].round(3),
        "DLM peak (GW)": ds["dlm_peak_mean_gw"].round(1),
        "Peak bias (weeks)": ds["dlm_peak_bias_gw"].round(1),
        "Apparent window (GW)": [f"{a:.0f}-{b:.0f}" for a, b in
                                 zip(ds["dlm_sig_lo_mean"], ds["dlm_sig_hi_mean"])],
    })
    write(t6, O, "table7_identifiability",
          "Table 7. A single permanence kernel produces different apparent windows "
          "depending only on the correlation structure of exposure.")

    pw = pd.read_csv(os.path.join(R, "deconvolution_power.csv"))
    t7 = pd.DataFrame({
        "Pregnancies": pw["n"].map(lambda v: f"{int(v):,}"),
        "Expected cases": pw["n_cases"].map(lambda v: f"{int(v):,}"),
        "Recovered peak (GW), mean": pw["peak_mean_gw"].round(1),
        "SD (weeks)": pw["peak_sd_gw"].round(1),
        "P(within 2 weeks)": pw["frac_within_2wk"].round(2),
        "P(within 4 weeks)": pw["frac_within_4wk"].round(2),
    })
    write(t7, O, "table8_power",
          "Table 8. Cohort size required to localise the permanence window by a "
          "distributed-lag analysis.")

    # ---- Table 8: replication -------------------------------------------
    if os.path.exists(comp_path):
        cj = load_json(comp_path)
        t8 = pd.DataFrame([
            {"Quantity": "Per-probe mean methylation, cross-cohort r",
             "Value": f"{cj['probe_mean_r']:.4f}",
             "Interpretation": "datasets are directly comparable"},
            {"Quantity": "Per-probe mean methylation, RMSE",
             "Value": f"{cj['probe_mean_rmse']:.4f}",
             "Interpretation": "beta units"},
            {"Quantity": "Developmental slope, observed cross-cohort r",
             "Value": f"{cj['slope_observed_r']:.4f}",
             "Interpretation": "agreement of the age signal"},
            {"Quantity": "Developmental slope, expected r if the signal were shared",
             "Value": f"{cj['slope_expected_r_perfect_signal']:.4f}",
             "Interpretation": "attenuation-corrected ceiling"},
            {"Quantity": "Observed / expected",
             "Value": f"{cj['slope_observed_over_expected']:.3f}",
             "Interpretation": "a value near 1 would indicate replication"},
            {"Quantity": "Sign concordance of slopes",
             "Value": f"{cj['slope_sign_concordance']:.4f}",
             "Interpretation": "0.5 is chance"},
            {"Quantity": "Discovery split-half slope agreement",
             "Value": f"{cj['discovery_split_half_mean']:.3f}"
                      if cj.get("discovery_split_half_mean") is not None else "n/a",
             "Interpretation": "internal consistency, discovery"},
            {"Quantity": "Replication split-half slope agreement",
             "Value": f"{cj['replication_split_half_mean']:.3f}"
                      if cj.get("replication_split_half_mean") is not None else "n/a",
             "Interpretation": "internal consistency, replication"},
            {"Quantity": "Discovery PC1 correlation with age",
             "Value": f"{cj['discovery_pc']['pc1_age_r']:+.3f}",
             "Interpretation": f"PC1 holds {cj['discovery_pc']['var_share'][0]:.1%} of variance"},
            {"Quantity": "Replication PC1 correlation with age",
             "Value": f"{cj['replication_pc']['pc1_age_r']:+.3f}",
             "Interpretation": f"PC1 holds {cj['replication_pc']['var_share'][0]:.1%} of variance"},
        ])
        write(t8, O, "table5_replication",
              "Table 5. Cross-cohort comparison over the shared gestational window "
              "(12-18 post-conception weeks).")

    print("[done] tables written", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
