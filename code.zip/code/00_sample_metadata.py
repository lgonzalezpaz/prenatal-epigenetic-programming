#!/usr/bin/env python3
"""
00_sample_metadata.py

Builds the sample metadata tables the pipeline needs:
  gse58885_meta.csv   GSM, days post-conception, sex   (from the SOFT family file)
  sample_metadata.csv GSM, pcw, array slide, sex       (slide parsed from titles)
  gse74193_meta.csv   GSM, age, group, plate, QC flag, cell-composition estimates
"""
from __future__ import annotations

import argparse
import csv
import gzip
import os
import re


def parse_soft(path):
    recs, cur = [], None
    with gzip.open(path, "rt", errors="replace") as fh:
        for line in fh:
            if line.startswith("^SAMPLE"):
                if cur:
                    recs.append(cur)
                cur = {"gsm": line.split("=")[1].strip()}
            elif line.startswith("!Sample_characteristics_ch1") and cur is not None:
                v = line.split("=", 1)[1].strip()
                if ":" in v:
                    k, val = v.split(":", 1)
                    cur[k.strip()] = val.strip()
            elif line.startswith("!series_matrix_table_begin"):
                break
    if cur:
        recs.append(cur)
    return recs


def header_rows(path, wanted):
    out = {}
    with gzip.open(path, "rt", errors="replace") as fh:
        for line in fh:
            for w in wanted:
                if line.startswith(w):
                    out.setdefault(w, []).append(
                        [t.strip().strip('"') for t in line.rstrip("\n").split("\t")[1:]])
            if line.startswith("!series_matrix_table_begin"):
                break
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--soft", required=True)
    ap.add_argument("--matrix", required=True)
    ap.add_argument("--meta74193", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    os.makedirs(a.results, exist_ok=True)

    recs = parse_soft(a.soft)
    with open(os.path.join(a.outdir, "gse58885_meta.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["gsm", "days post-conception", "gender"],
                           extrasaction="ignore")
        w.writeheader(); w.writerows(recs)
    print(f"[00] GSE58885: {len(recs)} samples")

    h = header_rows(a.matrix, ["!Sample_geo_accession", "!Sample_title"])
    gsms = h["!Sample_geo_accession"][0]
    titles = h["!Sample_title"][0]
    dpc = {r["gsm"]: r.get("days post-conception") for r in recs}
    sex = {r["gsm"]: r.get("gender") for r in recs}
    with open(os.path.join(a.results, "sample_metadata.csv"), "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["gsm", "pcw", "slide", "sex"])
        for g, t in zip(gsms, titles):
            m = re.search(r"\((\d+)_R\d+C\d+\)", t)
            w.writerow([g, float(dpc[g]) / 7.0, m.group(1) if m else "NA", sex[g]])
    print("[00] wrote results/sample_metadata.csv")

    h2 = header_rows(a.meta74193,
                     ["!Sample_geo_accession", "!Sample_title",
                      "!Sample_characteristics_ch1"])
    gsm2 = h2["!Sample_geo_accession"][0]
    ttl2 = h2["!Sample_title"][0]
    rows = [{"gsm": g, "title": t} for g, t in zip(gsm2, ttl2)]
    for row in h2.get("!Sample_characteristics_ch1", []):
        for i, v in enumerate(row):
            if ":" in v:
                k, val = v.split(":", 1)
                rows[i][k.split("(")[0].strip()] = val.strip()
    keys = sorted({k for r in rows for k in r})
    with open(os.path.join(a.outdir, "gse74193_meta.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    print(f"[00] GSE74193: {len(rows)} arrays")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
