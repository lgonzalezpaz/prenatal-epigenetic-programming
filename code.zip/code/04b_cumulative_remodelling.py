#!/usr/bin/env python3
"""
04b_cumulative_remodelling.py

Robust estimation of the cumulative epigenetic remodelling curve G(t) and of the
instantaneous remodelling intensity Phi(t) = dG/dt in the human fetal brain
(GSE58885; 179 donors, 3.3-26.3 post-conception weeks).

Estimator
---------
Adjacent-week differences of binned means are noise dominated, so all 78
pairwise distances between the 13 gestational-age bins are used jointly. For
bins a and b the noise-corrected squared methylomic distance is

    Delta2(a,b) = mean_i[(mbar_i(a) - mbar_i(b))^2] - mean_i[sem2_i(a) + sem2_i(b)]  (1)

which is unbiased for the squared true separation. Delta2 is NOT clipped at
zero, because clipping biases bins with few donors towards no remodelling. If
remodelling follows a single dominant trajectory (the leading temporal mode
explains 88% of trajectory variance) then Delta2(a,b) ~ (G(b) - G(a))^2, and a
monotone embedding is obtained by solving

    min_{g >= 0} sum_{a<b} w_ab ( Delta2(a,b) - ( sum_{j=a}^{b-1} g_j )^2 )^2   (2)

over non-negative increments g_j = G_{j+1} - G_j. Phi(t) is the derivative of a
local-linear smooth of G.

Confound control
----------------
Bin sizes range from 6 to 25 donors, and the magnitude of the noise correction
scales with 1/n. An equal-n diagnostic therefore resamples every bin down to a
common donor count and refits, so that the shape of Phi cannot be produced by
unequal precision. A core-window variant restricted to bins with at least 10
donors is also reported.

Outputs results/cumulative_remodelling.csv, results/methylomic_distance.csv,
results/remodelling_strata.csv, results/equal_n_diagnostic.csv and
results/cumulative_remodelling.npz.

Usage:
  python 04b_cumulative_remodelling.py --beta results/beta_matrix.npy \
      --stats results/methylation_probe_stats.npz \
      --annot results/probe_annotation.csv.gz \
      --profiles results/empirical_profiles.npz --outdir results [--nboot 200]
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd
from scipy.optimize import least_squares

RNG_SEED = 20261027
MIN_N_CORE = 10


def binned(beta: np.ndarray, members, ages: np.ndarray | None = None):
    """Per-probe bin mean, noise variance and bin size.

    Bins differ in width (the first spans 3.3-7.0 and the last 20-26 pcw), so a
    raw within-bin variance absorbs genuine developmental change and inflates
    the noise term, over-correcting the distances at the extremes. When ages are
    supplied the within-bin linear trend in post-conception week is removed and
    the residual variance (df = n - 2) is used as the noise estimate. The bin
    mean is unchanged, because the bin centre is the mean age and an
    ordinary-least-squares line passes through the mean of the predictor.
    """
    nb = len(members)
    bm = np.empty((beta.shape[0], nb)); bv = np.empty((beta.shape[0], nb))
    bn = np.empty(nb)
    for b, idx in enumerate(members):
        sub = beta[:, idx]
        n = len(idx)
        bm[:, b] = sub.mean(axis=1)
        bn[b] = n
        if n < 2:
            bv[:, b] = np.nan
            continue
        if ages is None or n < 4:
            bv[:, b] = sub.var(axis=1, ddof=1)
            continue
        x = ages[idx]
        xc = x - x.mean()
        sxx = float(np.dot(xc, xc))
        if sxx <= 1e-12:
            bv[:, b] = sub.var(axis=1, ddof=1)
            continue
        slope = (sub - sub.mean(axis=1, keepdims=True)) @ xc / sxx
        resid = sub - sub.mean(axis=1, keepdims=True) - slope[:, None] * xc[None, :]
        bv[:, b] = (resid * resid).sum(axis=1) / (n - 2)
    return bm, bv, bn


def distance2(bm: np.ndarray, bv: np.ndarray, bn: np.ndarray) -> np.ndarray:
    """Unbiased, unclipped noise-corrected squared methylomic distance."""
    nb = bm.shape[1]
    sem2 = bv / bn[None, :]
    D2 = np.zeros((nb, nb))
    for a in range(nb):
        for b in range(a + 1, nb):
            d = bm[:, a] - bm[:, b]
            val = float(np.nanmean(d * d)) - float(np.nanmean(sem2[:, a] + sem2[:, b]))
            D2[a, b] = D2[b, a] = val
    return D2


def fit_monotone(D2: np.ndarray, weights: np.ndarray, nb: int):
    """Solve (2): monotone 1-D embedding fitted on squared distances."""
    pairs = [(a, b) for a in range(nb) for b in range(a + 1, nb)]
    y = np.array([D2[a, b] for a, b in pairs])
    A = np.zeros((len(pairs), nb - 1))
    for r, (a, b) in enumerate(pairs):
        A[r, a:b] = 1.0
    w = np.sqrt(weights)

    scale = np.sqrt(max(np.nanmax(y), 1e-8)) / max(nb - 1, 1)
    x0 = np.full(nb - 1, scale)

    def resid(g):
        return w * (y - (A @ g) ** 2)

    sol = least_squares(resid, x0, bounds=(0.0, np.inf), xtol=1e-14,
                        ftol=1e-14, gtol=1e-14, max_nfev=20000)
    g = sol.x
    G = np.concatenate([[0.0], np.cumsum(g)])
    pred = (A @ g) ** 2
    ss_res = float(np.sum(weights * (y - pred) ** 2))
    ybar = float(np.average(y, weights=weights))
    ss_tot = float(np.sum(weights * (y - ybar) ** 2))
    return G, g, 1.0 - ss_res / ss_tot


def smooth_derivative(t: np.ndarray, G: np.ndarray, grid: np.ndarray, bw=2.0):
    Gs = np.empty_like(grid); dG = np.empty_like(grid)
    for i, g0 in enumerate(grid):
        w = np.exp(-0.5 * ((t - g0) / bw) ** 2)
        X = np.column_stack([np.ones_like(t), t - g0])
        Wm = np.diag(w)
        try:
            beta = np.linalg.solve(X.T @ Wm @ X, X.T @ Wm @ G)
            Gs[i], dG[i] = beta[0], beta[1]
        except np.linalg.LinAlgError:
            Gs[i] = dG[i] = np.nan
    return Gs, np.maximum(dG, 0.0)


def pair_weights(bn: np.ndarray, nb: int) -> np.ndarray:
    pairs = [(a, b) for a in range(nb) for b in range(a + 1, nb)]
    return np.array([2 * bn[a] * bn[b] / (bn[a] + bn[b]) for a, b in pairs])


def run_once(sub: np.ndarray, members, centres: np.ndarray, grid: np.ndarray,
             bw: float = 2.0, ages: np.ndarray | None = None):
    bm, bv, bn = binned(sub, members, ages)
    D2 = distance2(bm, bv, bn)
    G, _, r2 = fit_monotone(D2, pair_weights(bn, len(members)), len(members))
    Gs, Phi = smooth_derivative(centres, G, grid, bw)
    return G, Gs, Phi, r2, D2, bn


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--annot", required=True)
    ap.add_argument("--profiles", required=True)
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--nboot", type=int, default=200)
    ap.add_argument("--nequal", type=int, default=120)
    ap.add_argument("--drop-bins", default="",
                    help="comma-separated bin indices to exclude (off-trajectory)")
    ap.add_argument("--tag", default="")
    ap.add_argument("--npc", type=int, default=0,
                    help="remove this many leading principal components first "
                         "(conservative control for cell composition)")
    args = ap.parse_args()

    st = np.load(args.stats, allow_pickle=True)
    prof = np.load(args.profiles, allow_pickle=True)
    pcw = st["pcw"].astype(float)
    bin_edges = st["bin_edges"].astype(float)
    probe_id = st["probe_id"]
    dyn = prof["dynamic"]
    annot = pd.read_csv(args.annot, low_memory=False).set_index("probe_id").reindex(probe_id)
    keep = (annot["sex_chrom"].to_numpy() == 0) & (annot["has_snp"].to_numpy() == 0)

    beta = np.load(args.beta, mmap_mode="r")
    beta = np.ascontiguousarray(beta[keep], dtype=np.float32)
    annot_k = annot.iloc[keep].reset_index()
    assert beta.shape[0] == dyn.shape[0]

    bin_idx = np.digitize(pcw, bin_edges, right=False) - 1
    nb = len(bin_edges) - 1
    members_all = [np.where(bin_idx == b)[0] for b in range(nb)]
    drop = {int(x) for x in args.drop_bins.split(",") if x.strip() != ""}
    use = [i for i in range(nb) if i not in drop]
    if drop:
        print(f"[info] excluding bin indices {sorted(drop)} "
              f"(off-trajectory / inadequate tissue representation)", flush=True)
    members = [members_all[i] for i in use]
    nb = len(members)
    centres = np.array([pcw[m].mean() for m in members])
    bn0 = np.array([len(m) for m in members], dtype=float)
    print(f"[info] bins {np.round(centres,2).tolist()}", flush=True)
    print(f"[info] donors per bin {bn0.astype(int).tolist()}", flush=True)

    sub = beta[dyn].astype(np.float64)
    print(f"[info] {dyn.sum()} developmentally dynamic probes", flush=True)

    if args.npc > 0:
        # Project out the leading sample-space principal components. These
        # absorb cell-composition variation, but they also absorb genuine
        # developmental signal because composition in bulk fetal tissue is
        # itself a function of gestational age, so this is a deliberately
        # conservative control rather than a clean adjustment.
        Xc = sub - sub.mean(axis=1, keepdims=True)
        Gm = Xc.T @ Xc
        w_, V = np.linalg.eigh(Gm)
        ordr = np.argsort(w_)[::-1]
        comps = V[:, ordr][:, : args.npc]
        share = (w_[ordr] / w_.sum())[: args.npc]
        ages_all = pcw
        for i in range(args.npc):
            r_i = float(np.corrcoef(ages_all, comps[:, i])[0, 1])
            print(f"[info] removing PC{i+1}: {share[i]:.3f} of variance, "
                  f"correlation with pcw r = {r_i:+.3f}", flush=True)
        Q = np.hstack([np.ones((sub.shape[1], 1)), comps])
        coefq, *_ = np.linalg.lstsq(Q, Xc.T, rcond=None)
        sub = (Xc.T - Q @ coefq).T + sub.mean(axis=1, keepdims=True)
    grid = np.arange(centres[0], centres[-1] + 1e-9, 0.25)

    G, Gs, Phi, r2, D2, _ = run_once(sub, members, centres, grid, ages=pcw)
    print(f"[info] monotone embedding R2 = {r2:.4f}", flush=True)
    print(f"[info] G(t) = {np.round(G,5).tolist()}", flush=True)
    sel = [7, 9, 11, 13, 15, 17, 19, 21]
    print("[info] Phi:", {w: float(np.round(Phi[np.argmin(np.abs(grid-w))],5))
                          for w in sel}, flush=True)
    print(f"[info] Phi peak at {grid[int(np.nanargmax(Phi))]:.2f} pcw", flush=True)

    # ---- dimensionality of the distance structure (classical MDS) --------
    Dm = np.sqrt(np.maximum(D2, 0.0))
    J = np.eye(nb) - np.ones((nb, nb)) / nb
    Bm = -0.5 * J @ (Dm ** 2) @ J
    ev, EV = np.linalg.eigh(Bm)
    order = np.argsort(ev)[::-1]
    ev = np.clip(ev[order], 0, None); EV = EV[:, order]
    share = ev / max(ev.sum(), 1e-18)
    mds1 = EV[:, 0] * np.sqrt(ev[0])
    print(f"[info] MDS eigenvalue share (first 4): "
          f"{np.round(share[:4], 4).tolist()}", flush=True)
    print(f"[info] MDS axis-1 coordinate by bin: "
          f"{np.round(mds1, 4).tolist()}", flush=True)

    # ---- equal-n diagnostic ---------------------------------------------
    rng = np.random.default_rng(RNG_SEED)
    n_eq = int(bn0.min())
    eq_phi = []
    for it in range(args.nequal):
        res = [rng.choice(m, size=n_eq, replace=False) for m in members]
        _, _, Ph, _, _, _ = run_once(sub, res, centres, grid, ages=pcw)
        eq_phi.append(Ph)
        if (it + 1) % 40 == 0:
            print(f"[info] equal-n {it+1}/{args.nequal}", flush=True)
    eq_phi = np.asarray(eq_phi)
    eq_mean = np.nanmean(eq_phi, axis=0)
    print(f"[info] equal-n (n={n_eq}/bin) Phi peak at "
          f"{grid[int(np.nanargmax(eq_mean))]:.2f} pcw", flush=True)
    print("[info] equal-n Phi:", {w: float(np.round(eq_mean[np.argmin(np.abs(grid-w))],5))
                                  for w in sel}, flush=True)
    rho = float(np.corrcoef(np.argsort(np.argsort(Phi)),
                            np.argsort(np.argsort(eq_mean)))[0, 1])
    print(f"[info] rank correlation full vs equal-n Phi: rho = {rho:.3f}", flush=True)

    # ---- core-window variant (bins with >= MIN_N_CORE donors) -----------
    core = np.where(bn0 >= MIN_N_CORE)[0]
    members_c = [members[i] for i in core]
    centres_c = centres[core]
    grid_c = np.arange(centres_c[0], centres_c[-1] + 1e-9, 0.25)
    Gc, Gsc, Phic, r2c, _, _ = run_once(sub, members_c, centres_c, grid_c, ages=pcw)
    print(f"[info] core window {centres_c[0]:.1f}-{centres_c[-1]:.1f} pcw "
          f"({len(core)} bins), R2={r2c:.4f}, Phi peak at "
          f"{grid_c[int(np.nanargmax(Phic))]:.2f} pcw", flush=True)

    # ---- strata ----------------------------------------------------------
    strata = {"dynamic_all": dyn}
    for rel in ("Island", "N_Shore", "S_Shore", "OpenSea"):
        strata[f"dyn_{rel}"] = dyn & (annot_k["island_relation"].to_numpy() == rel)
    for reg in ("TSS200", "TSS1500", "Body", "Intergenic"):
        strata[f"dyn_{reg}"] = dyn & (annot_k["region"].to_numpy() == reg)
    strat_rows = []
    for name, msk in strata.items():
        if msk.sum() < 500:
            continue
        Gx, _, Phix, r2x, _, _ = run_once(beta[msk].astype(np.float64), members,
                                          centres, grid, ages=pcw)
        pk = grid[int(np.nanargmax(Phix))]
        for i, w in enumerate(grid):
            strat_rows.append({"stratum": name, "n_probes": int(msk.sum()),
                               "pcw": w, "Phi": Phix[i]})
        print(f"[info] {name:16s} n={int(msk.sum()):6d} R2={r2x:.3f} "
              f"G_tot={Gx[-1]:.4f} peak={pk:.2f} pcw", flush=True)

    # ---- leave-one-bin-out sensitivity ----------------------------------
    lobo = []
    for drop in range(nb):
        idx = [i for i in range(nb) if i != drop]
        mm = [members[i] for i in idx]; cc = centres[idx]
        gg = np.arange(cc[0], cc[-1] + 1e-9, 0.25)
        _, _, Ph, r2x, _, _ = run_once(sub, mm, cc, gg, ages=pcw)
        pk = gg[int(np.nanargmax(Ph))]
        lobo.append({"dropped_pcw": float(centres[drop]), "peak_pcw": float(pk),
                     "r2": float(r2x)})
        print(f"[info] drop bin {centres[drop]:5.2f} pcw -> peak {pk:.2f} pcw, "
              f"R2={r2x:.3f}", flush=True)

    # ---- donor bootstrap -------------------------------------------------
    Gb, Pb = [], []
    for it in range(args.nboot):
        res = [rng.choice(m, size=len(m), replace=True) if len(m) > 1 else m
               for m in members]
        Gx, _, Phix, _, _, _ = run_once(sub, res, centres, grid, ages=pcw)
        Gb.append(Gx); Pb.append(Phix)
        if (it + 1) % 50 == 0:
            print(f"[info] bootstrap {it+1}/{args.nboot}", flush=True)
    Gb = np.asarray(Gb); Pb = np.asarray(Pb)
    peak_boot = grid[np.nanargmax(Pb, axis=1)]
    print(f"[info] Phi peak bootstrap median {np.median(peak_boot):.2f} pcw, "
          f"95% CI [{np.percentile(peak_boot,2.5):.2f}, "
          f"{np.percentile(peak_boot,97.5):.2f}]", flush=True)

    os.makedirs(args.outdir, exist_ok=True)
    pd.DataFrame({
        "pcw": grid, "G_smooth": Gs, "Phi": Phi,
        "Phi_lo95": np.percentile(Pb, 2.5, axis=0),
        "Phi_hi95": np.percentile(Pb, 97.5, axis=0),
        "Phi_equal_n": eq_mean,
        "Phi_equal_n_lo95": np.percentile(eq_phi, 2.5, axis=0),
        "Phi_equal_n_hi95": np.percentile(eq_phi, 97.5, axis=0),
    }).to_csv(os.path.join(args.outdir, f"cumulative_remodelling{args.tag}.csv"), index=False)
    pd.DataFrame({"pcw": grid_c, "G_smooth": Gsc, "Phi": Phic}).to_csv(
        os.path.join(args.outdir, f"cumulative_remodelling_core{args.tag}.csv"), index=False)
    pd.DataFrame(np.sqrt(np.maximum(D2, 0)), index=np.round(centres, 2),
                 columns=np.round(centres, 2)).to_csv(
        os.path.join(args.outdir, f"methylomic_distance{args.tag}.csv"))
    pd.DataFrame(strat_rows).to_csv(
        os.path.join(args.outdir, f"remodelling_strata{args.tag}.csv"), index=False)
    pd.DataFrame({"pcw": grid, "Phi_full": Phi, "Phi_equal_n": eq_mean}).to_csv(
        os.path.join(args.outdir, f"equal_n_diagnostic{args.tag}.csv"), index=False)
    pd.DataFrame(lobo).to_csv(
        os.path.join(args.outdir, f"leave_one_bin_out{args.tag}.csv"), index=False)

    np.savez_compressed(
        os.path.join(args.outdir, f"cumulative_remodelling{args.tag}.npz"),
        centres=centres, G=G, G_boot=Gb, grid=grid, Phi=Phi, Phi_boot=Pb,
        Phi_equal_n=eq_phi, D2=D2, r2=r2, bn=bn0, peak_boot=peak_boot,
        centres_core=centres_c, G_core=Gc, grid_core=grid_c, Phi_core=Phic,
        rank_corr_equal_n=rho, n_equal=n_eq,
        mds_share=share, mds_axis1=mds1, bins_used=np.array(use),
    )
    print("[done] wrote cumulative_remodelling*.csv, methylomic_distance.csv, "
          "remodelling_strata.csv, equal_n_diagnostic.csv, .npz", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
