#!/usr/bin/env python3
"""
09_figures.py

Builds every figure of the manuscript as vector PDF plus 600-dpi PNG.

Design constraints applied throughout: a fixed-order categorical palette that
passes colorblind-vision separation checks (Okabe-Ito derived), one value axis
per panel, a legend whenever two or more series are shown, direct labelling of
the quantities that carry the argument, recessive axes and grid, and line styles
and markers that keep every series distinguishable in grayscale.

Usage:
  python 09_figures.py --results results --outdir figures
"""
from __future__ import annotations

import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator

# fixed-order categorical palette (validated for CVD separation)
C = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9"]
INK = "#1a1a1a"
INK2 = "#555555"
MUTED = "#8a8a8a"
GRIDC = "#d9d9d9"
SURFACE = "#ffffff"
DASHES = [(None, None), (5, 2), (1.6, 1.6), (7, 2, 1.6, 2), (3, 1.4, 1.4, 1.4),
          (9, 2.5)]

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "legend.fontsize": 7.8,
    "axes.edgecolor": INK2, "axes.linewidth": 0.7,
    "xtick.color": INK2, "ytick.color": INK2,
    "xtick.direction": "out", "ytick.direction": "out",
    "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.labelcolor": INK, "text.color": INK,
    "legend.frameon": False, "axes.spines.top": False, "axes.spines.right": False,
    "lines.solid_capstyle": "round", "lines.linewidth": 1.7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})


def style(ax, grid_axis="y"):
    ax.grid(True, axis=grid_axis, color=GRIDC, linewidth=0.55, alpha=0.9)
    ax.set_axisbelow(True)


def panel_tag(ax, letter, dx=-0.16, dy=1.055):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=10.5,
            fontweight="bold", va="top", ha="left", color=INK)


def save(fig, outdir, name):
    fig.savefig(os.path.join(outdir, f"{name}.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(outdir, f"{name}.png"), dpi=600, bbox_inches="tight")
    plt.close(fig)
    print(f"[fig] {name}.pdf / .png", flush=True)


# ---------------------------------------------------------------------------
def figure1(R, outdir):
    st = np.load(os.path.join(R, "methylation_probe_stats.npz"), allow_pickle=True)
    cr = np.load(os.path.join(R, "cumulative_remodelling_primary.npz"), allow_pickle=True)
    dm = pd.read_csv(os.path.join(R, "methylomic_distance_primary.csv"), index_col=0)

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)

    # (a) donor age distribution
    ax = fig.add_subplot(gs[0, 0])
    pcw = st["pcw"].astype(float)
    bins = np.arange(3, 28, 1)
    ax.hist(pcw, bins=bins, color=C[0], edgecolor=SURFACE, linewidth=0.6)
    ind_meta = os.path.join(R, "independent_cohort_summary.json")
    if os.path.exists(ind_meta):
        with open(ind_meta) as fh:
            ij = json.load(fh)
        for w in ij.get("weeks", []):
            ax.plot([w], [-1.2], marker="v", ms=4.5, color=C[1],
                    clip_on=False, zorder=5)
        ax.text(0.97, 0.93, "▼ replication cohort", transform=ax.transAxes,
                ha="right", va="top", color=C[1], fontsize=7.4)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Donors")
    ax.set_title("Discovery cohort sampling", pad=6)
    ax.set_xlim(3, 27); ax.xaxis.set_major_locator(MultipleLocator(4))
    style(ax); panel_tag(ax, "a")

    # (b) methylomic distance matrix
    ax = fig.add_subplot(gs[0, 1])
    M = dm.to_numpy()
    im = ax.imshow(M, cmap="magma_r", origin="lower", aspect="auto",
                   extent=[0, M.shape[0], 0, M.shape[0]])
    labs = [f"{float(c):.0f}" for c in dm.columns]
    ticks = np.arange(M.shape[0]) + 0.5
    ax.set_xticks(ticks[::2]); ax.set_xticklabels(labs[::2])
    ax.set_yticks(ticks[::2]); ax.set_yticklabels(labs[::2])
    ax.set_xlabel("Post-conception week"); ax.set_ylabel("Post-conception week")
    ax.set_title("Methylomic distance", pad=6)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cb.set_label("RMS Δβ", fontsize=8); cb.ax.tick_params(labelsize=7)
    cb.outline.set_linewidth(0.5)
    ax.grid(False); panel_tag(ax, "b")

    # (c) one-dimensional trajectory
    ax = fig.add_subplot(gs[1, 0])
    cen = cr["centres"]; ax1 = cr["mds_axis1"]; share = cr["mds_share"]
    ax.plot(cen, ax1, color=C[0], marker="o", ms=4.5, mfc=SURFACE, mew=1.4, zorder=3)
    ax.axhline(0, color=MUTED, lw=0.6)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Trajectory coordinate")
    ax.set_title(f"Single dominant axis ({100*share[0]:.1f}% of distance)", pad=6)
    ax.xaxis.set_major_locator(MultipleLocator(2))
    style(ax); panel_tag(ax, "c")

    # (d) cumulative remodelling
    ax = fig.add_subplot(gs[1, 1])
    G = cr["G"]; Gb = cr["G_boot"]
    lo = np.percentile(Gb, 2.5, axis=0); hi = np.percentile(Gb, 97.5, axis=0)
    ax.fill_between(cen, lo, hi, color=C[0], alpha=0.18, lw=0)
    ax.plot(cen, G, color=C[0], marker="o", ms=4.0, mfc=SURFACE, mew=1.3)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Cumulative remodelling  $G$ (Δβ)")
    ax.set_title("Cumulative epigenetic remodelling", pad=6)
    ax.xaxis.set_major_locator(MultipleLocator(2))
    style(ax); panel_tag(ax, "d")

    save(fig, outdir, "figure1_remodelling_trajectory")


# ---------------------------------------------------------------------------
def figure2(R, outdir):
    rem = pd.read_csv(os.path.join(R, "cumulative_remodelling_primary.csv"))
    strata = pd.read_csv(os.path.join(R, "remodelling_strata_primary.csv"))
    lobo = pd.read_csv(os.path.join(R, "leave_one_bin_out_primary.csv"))
    cr = np.load(os.path.join(R, "cumulative_remodelling_primary.npz"), allow_pickle=True)

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)

    g = rem["pcw"].to_numpy(); phi = rem["Phi"].to_numpy()
    peak = g[int(np.nanargmax(phi))]

    # (a) remodelling intensity with CI
    ax = fig.add_subplot(gs[0, 0])
    ax.fill_between(g, rem["Phi_lo95"], rem["Phi_hi95"], color=C[0],
                    alpha=0.18, lw=0, label="95% CI (donor bootstrap)")
    ax.plot(g, phi, color=C[0], label="measured  $\\Phi(t)$")
    ax.axvline(peak, color=INK2, lw=0.8, dashes=(4, 2))
    ax.annotate(f"peak {peak:.1f} pcw", xy=(peak, np.nanmax(phi)),
                xytext=(peak + 0.9, np.nanmax(phi) * 0.97), fontsize=7.6,
                color=INK, ha="left")
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Remodelling intensity  $\\Phi$  (Δβ week$^{-1}$)")
    ax.set_title("Remodelling intensity peaks at mid-gestation", pad=6)
    ax.legend(loc="upper left", handlelength=1.6)
    ax.xaxis.set_major_locator(MultipleLocator(2))
    style(ax); panel_tag(ax, "a")

    # (b) equal-n diagnostic
    ax = fig.add_subplot(gs[0, 1])
    eq = cr["Phi_equal_n"]
    ax.fill_between(g, np.percentile(eq, 2.5, axis=0),
                    np.percentile(eq, 97.5, axis=0), color=C[1], alpha=0.16, lw=0)
    ax.plot(g, phi, color=C[0], label="all donors")
    ax.plot(g, rem["Phi_equal_n"], color=C[1], dashes=DASHES[1],
            label=f"equal n = {int(cr['n_equal'])} per week")
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Remodelling intensity  $\\Phi$")
    ax.set_title(f"Not driven by unequal sampling (ρ = "
                 f"{float(cr['rank_corr_equal_n']):.3f})", pad=6)
    ax.legend(loc="upper left", handlelength=2.1)
    ax.xaxis.set_major_locator(MultipleLocator(2))
    style(ax); panel_tag(ax, "b")

    # (c) by genomic context
    ax = fig.add_subplot(gs[1, 0])
    keys = ["dyn_Island", "dyn_N_Shore", "dyn_OpenSea", "dyn_TSS200", "dyn_Body"]
    labels = ["CpG island", "island shore", "open sea", "promoter (TSS200)",
              "gene body"]
    for i, (k, lab) in enumerate(zip(keys, labels)):
        sub = strata[strata["stratum"] == k]
        if sub.empty:
            continue
        ax.plot(sub["pcw"], sub["Phi"], color=C[i], dashes=DASHES[i], label=lab)
    ax.axvline(peak, color=MUTED, lw=0.7, dashes=(2, 2))
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Remodelling intensity  $\\Phi$")
    ax.set_title("Same timing in every genomic context", pad=6)
    ax.legend(loc="upper left", handlelength=2.1, ncol=1)
    ax.xaxis.set_major_locator(MultipleLocator(2))
    style(ax); panel_tag(ax, "c")

    # (d) leave-one-bin-out
    ax = fig.add_subplot(gs[1, 1])
    ax.axhspan(peak - 2, peak + 2, color=C[0], alpha=0.11, lw=0,
               label="± 2 weeks of the full-data peak")
    ax.axhline(peak, color=C[0], lw=1.2)
    ax.scatter(lobo["dropped_pcw"], lobo["peak_pcw"], s=26, color=C[1],
               zorder=4, edgecolor=SURFACE, linewidth=0.7,
               label="peak with one week removed")
    pk_boot = cr["peak_boot"]
    ax.set_xlabel("Gestational-age bin removed (pcw)")
    ax.set_ylabel("Estimated peak (pcw)")
    ax.set_title(f"Bootstrap peak {np.median(pk_boot):.1f} pcw "
                 f"[{np.percentile(pk_boot,2.5):.1f}, "
                 f"{np.percentile(pk_boot,97.5):.1f}]", pad=6)
    ax.legend(loc="lower right", handlelength=1.6)
    ax.set_ylim(peak - 4, peak + 4)
    style(ax); panel_tag(ax, "d")

    save(fig, outdir, "figure2_remodelling_intensity")


# ---------------------------------------------------------------------------
def figure3(R, outdir):
    ker = pd.read_csv(os.path.join(R, "permanence_kernel.csv"))
    genes = pd.read_csv(os.path.join(R, "brainspan_genes.csv"))
    with open(os.path.join(R, "permanence_summary.json")) as fh:
        S = json.load(fh)
    rem = pd.read_csv(os.path.join(R, "cumulative_remodelling_primary.csv"))

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)

    g = ker["pcw"].to_numpy()

    # (a) activity profiles
    ax = fig.add_subplot(gs[0, 0])
    for i, (col, lab) in enumerate([
            ("psi_prolif", "proliferation"), ("psi_denovo", "de novo (DNMT3A/B)"),
            ("psi_demeth", "demethylation (TET/TDG)"),
            ("psi_maint", "maintenance (DNMT1/UHRF1)"),
            ("psi_reader", "methyl-CpG readers")]):
        ax.plot(g, ker[col], color=C[i], dashes=DASHES[i], label=lab)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Relative activity (peak = 1)")
    ax.set_title("Machinery and proliferation trajectories", pad=6)
    ax.legend(loc="upper right", handlelength=2.1)
    ax.xaxis.set_major_locator(MultipleLocator(5))
    style(ax); panel_tag(ax, "a")

    # (b) individual genes
    ax = fig.add_subplot(gs[0, 1])
    piv = genes.pivot_table(index="gene", columns="pcw", values="log2_rpkm_mean")
    show = ["MKI67", "UHRF1", "DNMT1", "DNMT3A", "TET1", "TET3"]
    for i, gn in enumerate(show):
        if gn not in piv.index:
            continue
        ax.plot(piv.columns, piv.loc[gn], color=C[i], dashes=DASHES[i],
                marker="o", ms=3.0, mfc=SURFACE, mew=0.9, label=gn)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Expression  log$_2$(RPKM + 1)")
    ax.set_title("Replication-coupled genes fall first", pad=6)
    ax.legend(loc="upper right", handlelength=2.1, ncol=2)
    ax.xaxis.set_major_locator(MultipleLocator(5))
    style(ax); panel_tag(ax, "b")

    # (c) machinery mRNA does not predict remodelling
    ax = fig.add_subplot(gs[1, 0])
    inside = ker["measured"].to_numpy() == 1
    phi_g = np.interp(g, rem["pcw"], rem["Phi"])
    ax.scatter(ker["psi_E"][inside], phi_g[inside], s=13, color=C[4],
               alpha=0.75, edgecolor="none")
    ax.set_xlabel("Machinery activity  $\\psi_E$  (mRNA)")
    ax.set_ylabel("Measured remodelling  $\\Phi$")
    ax.set_title(f"mRNA abundance does not predict flux "
                 f"(r = {S['machinery_mrna_vs_phi_pearson_r']:.2f})", pad=6)
    style(ax, grid_axis="both"); panel_tag(ax, "c")

    # (d) proliferation vs remodelling
    ax = fig.add_subplot(gs[1, 1])
    ax.scatter(ker["psi_prolif"][inside], phi_g[inside], s=13, color=C[2],
               alpha=0.75, edgecolor="none")
    ax.set_xlabel("Proliferation  $\\psi_P$")
    ax.set_ylabel("Measured remodelling  $\\Phi$")
    ax.set_title(f"Remodelling is not proliferation "
                 f"(r = {S['proliferation_vs_phi_pearson_r']:.2f})", pad=6)
    style(ax, grid_axis="both"); panel_tag(ax, "d")

    save(fig, outdir, "figure3_machinery")


# ---------------------------------------------------------------------------
def figure4(R, outdir):
    ker = pd.read_csv(os.path.join(R, "permanence_kernel.csv"))
    mc = np.load(os.path.join(R, "permanence_mc.npz"), allow_pickle=True)
    with open(os.path.join(R, "permanence_summary.json")) as fh:
        S = json.load(fh)

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)
    g = ker["pcw"].to_numpy()
    meas = ker["measured"].to_numpy() == 1
    peak = S["peak_pcw_central"]

    # (a) the decomposition
    ax = fig.add_subplot(gs[0, 0])
    norm = lambda v: v / np.nanmax(v)
    ax.plot(g, norm(ker["inducibility_S"]), color=C[0], label="inducibility  $S$")
    ax.plot(g, ker["retention_R"], color=C[2], dashes=DASHES[1],
            label="retention  $R$")
    ax.plot(g, norm(ker["permanence_P"]), color=C[1], lw=2.2,
            label="permanence  $P = S\\,R$")
    ax.axvline(peak, color=INK2, lw=0.8, dashes=(4, 2))
    ax.axvspan(g[meas].max(), g.max(), color=MUTED, alpha=0.13, lw=0)
    ax.text(g[meas].max() + 0.4, 0.04, "no methylome data", rotation=90,
            fontsize=6.8, color=INK2, va="bottom")
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Normalised value")
    ax.set_title("Inducibility × retention = permanence", pad=6)
    ax.legend(loc="upper right", handlelength=2.1)
    ax.xaxis.set_major_locator(MultipleLocator(5))
    style(ax); panel_tag(ax, "a")

    # (b) relaxation rate decomposition
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(g, ker["k_relax"], color=C[0], label="total  $k$")
    ax.plot(g, ker["k_replicative"], color=C[3], dashes=DASHES[1],
            label="replicative dilution")
    ax.plot(g, ker["k_enzymatic"], color=C[2], dashes=DASHES[2],
            label="enzymatic turnover")
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Relaxation rate  $k$  (week$^{-1}$)")
    ax.set_title("What erases a perturbation, and when", pad=6)
    ax.legend(loc="upper right", handlelength=2.1)
    ax.xaxis.set_major_locator(MultipleLocator(5))
    style(ax); panel_tag(ax, "b")

    # (c) graphical solution of the stationarity condition
    ax = fig.add_subplot(gs[1, 0])
    dlnS = -np.gradient(np.log(ker["inducibility_S"].to_numpy()), g)
    sel = (g >= 9) & (g <= 21)
    ax.plot(g[sel], ker["k_relax"].to_numpy()[sel], color=C[0],
            label="$k(\\tau)$")
    ax.plot(g[sel], dlnS[sel], color=C[1], dashes=DASHES[1],
            label="$-\\,d\\ln S/d\\tau$")
    ax.plot([peak], [S["k_at_peak_per_week"]], marker="o", ms=7,
            mfc=SURFACE, mec=INK, mew=1.5, zorder=5)
    ax.annotate(f"$\\tau^*$ = {peak:.1f} pcw", xy=(peak, S["k_at_peak_per_week"]),
                xytext=(peak - 5.8, S["k_at_peak_per_week"] + 0.24),
                fontsize=8, color=INK,
                arrowprops=dict(arrowstyle="-", lw=0.7, color=INK2))
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Rate (week$^{-1}$)")
    ax.set_title("The window solves $k(\\tau^*) = -d\\ln S/d\\tau$", pad=6)
    ax.legend(loc="upper center", handlelength=2.1)
    ax.set_ylim(0, min(1.2, float(np.nanmax(dlnS[sel])) * 1.15))
    style(ax); panel_tag(ax, "c")

    # (d) posterior of the peak
    ax = fig.add_subplot(gs[1, 1])
    pk = mc["peaks"]; pk = pk[np.isfinite(pk)]
    ax.hist(pk, bins=np.arange(14.5, 19.3, 0.2), color=C[0],
            edgecolor=SURFACE, linewidth=0.5)
    lo, hi = S["peak_pcw_ci95"]
    ax.axvline(S["peak_pcw_median"], color=C[1], lw=1.6)
    ax.axvline(lo, color=INK2, lw=0.8, dashes=(3, 2))
    ax.axvline(hi, color=INK2, lw=0.8, dashes=(3, 2))
    ax.set_xlabel("Permanence window peak  $\\tau^*$  (pcw)")
    ax.set_ylabel("Monte Carlo draws")
    ax.set_title(f"{S['peak_pcw_median']:.1f} pcw  "
                 f"(95% CI {lo:.1f}–{hi:.1f})", pad=6)
    style(ax); panel_tag(ax, "d")

    save(fig, outdir, "figure4_permanence_kernel")


# ---------------------------------------------------------------------------
def figure5(R, outdir):
    rem = pd.read_csv(os.path.join(R, "cumulative_remodelling_primary.csv"))
    sc = pd.read_csv(os.path.join(R, "third_trimester_curves.csv"))
    scs = pd.read_csv(os.path.join(R, "third_trimester_scenarios.csv"))
    have_ind = os.path.exists(os.path.join(R, "independent_cohort_remodelling.csv"))

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)

    # (a) replication of the profile
    ax = fig.add_subplot(gs[0, 0])
    if have_ind:
        ind = pd.read_csv(os.path.join(R, "independent_cohort_remodelling.csv"))
        with open(os.path.join(R, "independent_cohort_summary.json")) as fh:
            ij = json.load(fh)
        lo, hi = ind["pcw"].min(), ind["pcw"].max()
        d = rem[(rem["pcw"] >= lo) & (rem["pcw"] <= hi)]
        ax.plot(d["pcw"], d["Phi"] / d["Phi"].max(), color=C[0],
                label="discovery (GSE58885)")
        ax.plot(ind["pcw"], ind["Phi"] / max(ind["Phi"].max(), 1e-12),
                color=C[1], dashes=DASHES[1], marker="o", ms=3.4,
                mfc=SURFACE, mew=0.9, label="replication (GSE74193)")
        ttl = (f"Replication, ρ = {ij.get('spearman_rho', float('nan')):.2f}"
               if "spearman_rho" in ij else "Independent replication")
        ax.set_title(ttl, pad=6)
        ax.legend(loc="upper left", handlelength=2.1)
    else:
        ax.text(0.5, 0.5, "replication pending", ha="center", va="center",
                transform=ax.transAxes, color=MUTED)
        ax.set_title("Independent replication", pad=6)
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Remodelling intensity (scaled)")
    style(ax); panel_tag(ax, "a")

    # (b) per-probe slope concordance
    ax = fig.add_subplot(gs[0, 1])
    if have_ind:
        with open(os.path.join(R, "independent_cohort_summary.json")) as fh:
            ij = json.load(fh)
        sr = ij.get("slope_replication")
        if sr:
            names = ["all CpGs", "top decile"]
            vals = [sr["sign_concordance"], sr["sign_concordance_top_decile"]]
            rs = [sr["pearson_r"], sr["pearson_r_top_decile"]]
            x = np.arange(2)
            ax.bar(x - 0.19, vals, width=0.34, color=C[0], label="sign concordance")
            ax.bar(x + 0.19, rs, width=0.34, color=C[2], label="Pearson r")
            for xi, v in zip(x - 0.19, vals):
                ax.text(xi, v + 0.02, f"{v:.2f}", ha="center", fontsize=7.4)
            for xi, v in zip(x + 0.19, rs):
                ax.text(xi, v + 0.02, f"{v:.2f}", ha="center", fontsize=7.4)
            ax.axhline(0.5, color=MUTED, lw=0.7, dashes=(3, 2))
            ax.set_xticks(x); ax.set_xticklabels(names)
            ax.set_ylim(0, 1.08)
            ax.set_ylabel("Cross-cohort agreement")
            ax.set_title(f"Per-CpG developmental slopes\n"
                         f"({sr['n_probes']:,} CpGs)", pad=6)
            ax.legend(loc="lower right", handlelength=1.4)
        else:
            ax.text(0.5, 0.5, "slope test unavailable", ha="center",
                    va="center", transform=ax.transAxes, color=MUTED)
    else:
        ax.text(0.5, 0.5, "replication pending", ha="center", va="center",
                transform=ax.transAxes, color=MUTED)
    style(ax); panel_tag(ax, "b")

    # (c) third-trimester scenarios: kernels
    ax = fig.add_subplot(gs[1, 0])
    labs = {"measured_decline": "measured decline", "slow_decline": "half-rate decline",
            "plateau": "plateau after 22 pcw", "late_rise": "late rise (+50%)",
            "late_surge": "late surge (+200%)"}
    for i, (k, lab) in enumerate(labs.items()):
        col = f"P_{k}"
        if col in sc.columns:
            ax.plot(sc["pcw"], sc[col], color=C[i], dashes=DASHES[i], label=lab)
    ax.axvline(22.11, color=MUTED, lw=0.8, dashes=(2, 2))
    ax.text(22.5, 0.97, "last measured week", rotation=90, fontsize=6.8,
            color=INK2, va="top")
    ax.set_xlabel("Post-conception week")
    ax.set_ylabel("Permanence  $P$ (scaled)")
    ax.set_title("Mid-gestation peak under every scenario", pad=6)
    ax.legend(loc="upper right", handlelength=2.1)
    ax.xaxis.set_major_locator(MultipleLocator(5))
    style(ax); panel_tag(ax, "c")

    # (d) scenario summary
    ax = fig.add_subplot(gs[1, 1])
    y = np.arange(len(scs))[::-1]
    ax.barh(y, scs["frac_global_peak_after_20pcw"], color=C[1], height=0.5)
    for yi, v in zip(y, scs["frac_global_peak_after_20pcw"]):
        ax.text(v + 0.008, yi, f"{v:.3f}", va="center", fontsize=7.4)
    ax.set_yticks(y)
    ax.set_yticklabels([labs.get(s, s) for s in scs["scenario"]], fontsize=7.6)
    ax.set_xlabel("P(global peak after 20 pcw)")
    ax.set_xlim(0, max(0.33, scs["frac_global_peak_after_20pcw"].max() * 1.35))
    ax.set_title("A late window cannot be excluded", pad=6)
    style(ax, grid_axis="x"); panel_tag(ax, "d", dx=-0.42)

    save(fig, outdir, "figure5_replication_scenarios")


# ---------------------------------------------------------------------------
def figure6(R, outdir):
    cur = pd.read_csv(os.path.join(R, "deconvolution_curves.csv"))
    sett = pd.read_csv(os.path.join(R, "deconvolution_settings.csv"))
    pw = pd.read_csv(os.path.join(R, "deconvolution_power.csv"))

    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, hspace=0.46, wspace=0.34)
    w = cur["gestational_week"].to_numpy()

    # (a) recovered lag curves
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(w, cur["true_kernel"], color=INK, lw=2.4, label="true kernel")
    cols = [c for c in cur.columns if c.startswith("dlm_curve_")]
    for i, c in enumerate(cols[:5]):
        r = c.replace("dlm_curve_r", "")
        ax.plot(w, cur[c], color=C[i], dashes=DASHES[i], lw=1.3,
                label=f"recovered, $r_{{13}}$ = {r}")
    ax.axhline(0, color=MUTED, lw=0.6)
    ax.set_xlabel("Gestational week")
    ax.set_ylabel("Effect (scaled)")
    ax.set_title("One kernel, many apparent windows", pad=6)
    ax.legend(loc="lower center", handlelength=2.1, fontsize=6.6, ncol=2,
              columnspacing=1.0, bbox_to_anchor=(0.5, -0.02))
    ax.set_ylim(-0.62, 1.12)
    ax.xaxis.set_major_locator(MultipleLocator(6))
    style(ax); panel_tag(ax, "a")

    # (b) apparent trimester odds ratios
    ax = fig.add_subplot(gs[0, 1])
    x = sett["achieved_r_T1T3"].to_numpy()
    for i, t in enumerate(["T1", "T2", "T3"]):
        ax.plot(x, sett[f"sep_{t}_OR"], color=C[i], dashes=DASHES[i],
                marker="o", ms=4.0, mfc=SURFACE, mew=1.0,
                label=f"trimester {t[1]}")
    ax.axhline(1.0, color=INK2, lw=0.8)
    ax.set_xlabel("Exposure correlation  $r$(T1, T3)")
    ax.set_ylabel("Apparent odds ratio per SD")
    ax.set_title("Trimester estimates track correlation,\nnot biology", pad=6)
    ax.legend(loc="lower right", handlelength=2.1)
    style(ax); panel_tag(ax, "b")

    # (c) bias of the recovered peak
    ax = fig.add_subplot(gs[1, 0])
    ax.axhline(0, color=INK2, lw=0.9)
    ax.errorbar(x, sett["dlm_peak_bias_gw"], yerr=sett["dlm_peak_sd_gw"],
                fmt="o", ms=5, color=C[1], ecolor=C[1], elinewidth=1.1,
                capsize=2.5, mfc=SURFACE, mew=1.2)
    ax.axhspan(-2, 2, color=C[0], alpha=0.12, lw=0)
    ax.text(x.min(), 2.25, "± 2 weeks", fontsize=7.2, color=INK2)
    ax.set_xlabel("Exposure correlation  $r$(T1, T3)")
    ax.set_ylabel("Peak bias (weeks)")
    ax.set_title("Distributed-lag peak wanders by weeks", pad=6)
    style(ax); panel_tag(ax, "c")

    # (d) cohort size required
    ax = fig.add_subplot(gs[1, 1])
    ax.plot(pw["n"], pw["frac_within_4wk"], color=C[0], marker="o", ms=4.5,
            mfc=SURFACE, mew=1.2, label="within ± 4 weeks")
    ax.plot(pw["n"], pw["frac_within_2wk"], color=C[1], dashes=DASHES[1],
            marker="s", ms=4.2, mfc=SURFACE, mew=1.2, label="within ± 2 weeks")
    for n_pub, lab in ((294937, "Rahman 2022"), (1547244, "Shupler 2026"),
                       (2183324, "Cloutier 2025")):
        ax.axvline(n_pub, color=MUTED, lw=0.7, dashes=(2, 2))
        ax.text(n_pub * 0.93, 0.97, lab, rotation=90, fontsize=6.2,
                color=INK2, ha="right", va="top")
    ax.set_xscale("log")
    ax.set_xlabel("Pregnancies in cohort")
    ax.set_ylabel("P(peak correctly localised)")
    ax.set_title("What it would take", pad=6)
    ax.set_ylim(0, 1.0)
    ax.legend(loc="upper left", handlelength=2.1)
    style(ax); panel_tag(ax, "d")

    save(fig, outdir, "figure6_identifiability")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--outdir", default="figures")
    ap.add_argument("--only", default="")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    todo = {"1": figure1, "2": figure2, "3": figure3, "4": figure4,
            "5": figure5, "6": figure6}
    want = [c for c in (args.only or "123456")]
    for c in want:
        try:
            todo[c](args.results, args.outdir)
        except Exception as exc:                                  # noqa: BLE001
            print(f"[warn] figure {c} failed: {type(exc).__name__}: {exc}",
                  flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
