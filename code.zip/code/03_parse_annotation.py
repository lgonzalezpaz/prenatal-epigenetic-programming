#!/usr/bin/env python3
"""
03_parse_annotation.py

Parses the Illumina HumanMethylation450 manifest (GEO platform GPL13534,
supplementary file GPL13534_HumanMethylation450_15017482_v.1.1.csv.gz) and
writes a compact per-probe annotation table restricted to the probes retained by
01_extract_methylation_stats.py.

Retained fields: chromosome, position, Infinium design type, CpG-island
relation (Island / N_Shore / S_Shore / N_Shelf / S_Shelf / OpenSea), RefGene
symbols, RefGene region class (TSS1500 / TSS200 / 5'UTR / 1stExon / Body /
3'UTR), and enhancer flag. Probes on sex chromosomes and probes overlapping
documented SNPs are flagged so that downstream analyses can exclude them.

Usage:
  python 03_parse_annotation.py --manifest <manifest.csv.gz> \
      --stats results/methylation_probe_stats.npz --out results/probe_annotation.csv.gz
"""
from __future__ import annotations

import argparse
import csv
import gzip

import numpy as np

ISLAND_CLASSES = ("Island", "N_Shore", "S_Shore", "N_Shelf", "S_Shelf", "OpenSea")
REGION_PRIORITY = ("TSS200", "TSS1500", "1stExon", "5'UTR", "Body", "3'UTR")


def pick_region(raw: str) -> str:
    """Collapse the semicolon-separated RefGene_Group field to one class."""
    if not raw:
        return "Intergenic"
    parts = {p.strip() for p in raw.split(";") if p.strip()}
    for r in REGION_PRIORITY:
        if r in parts:
            return r
    return "Other"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    keep = set(np.load(args.stats, allow_pickle=True)["probe_id"].tolist())
    print(f"[info] {len(keep)} probes to annotate", flush=True)

    with gzip.open(args.manifest, "rt", errors="replace") as fh:
        # Skip the manifest preamble: the assay header starts at the IlmnID line.
        header = None
        for line in fh:
            if line.startswith("IlmnID,"):
                header = next(csv.reader([line]))
                break
        if header is None:
            raise RuntimeError("manifest assay header not found")
        idx = {name: i for i, name in enumerate(header)}
        need = ["Name", "CHR", "MAPINFO", "Infinium_Design_Type",
                "Relation_to_UCSC_CpG_Island", "UCSC_RefGene_Name",
                "UCSC_RefGene_Group", "Enhancer", "Probe_SNPs", "Probe_SNPs_10"]
        for c in need:
            if c not in idx:
                raise RuntimeError(f"manifest lacks column {c}")

        n_written = 0
        with gzip.open(args.out, "wt", newline="") as out:
            w = csv.writer(out)
            w.writerow(["probe_id", "chr", "pos", "design", "island_relation",
                        "gene", "region", "enhancer", "has_snp", "sex_chrom"])
            for row in csv.reader(fh):
                if len(row) <= idx["Probe_SNPs_10"]:
                    continue
                name = row[idx["Name"]].strip()
                if name not in keep:
                    continue
                chrom = row[idx["CHR"]].strip()
                rel = row[idx["Relation_to_UCSC_CpG_Island"]].strip() or "OpenSea"
                if rel not in ISLAND_CLASSES:
                    rel = "OpenSea"
                genes = row[idx["UCSC_RefGene_Name"]].strip()
                gene = sorted({g.strip() for g in genes.split(";") if g.strip()})
                snp = bool(row[idx["Probe_SNPs"]].strip() or row[idx["Probe_SNPs_10"]].strip())
                w.writerow([
                    name, chrom, row[idx["MAPINFO"]].strip(),
                    row[idx["Infinium_Design_Type"]].strip(), rel,
                    "|".join(gene), pick_region(row[idx["UCSC_RefGene_Group"]].strip()),
                    int(bool(row[idx["Enhancer"]].strip())), int(snp),
                    int(chrom in ("X", "Y")),
                ])
                n_written += 1
    print(f"[done] wrote {args.out} with {n_written} annotated probes", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
