#!/usr/bin/env python3
"""
11_build_references.py

Fetches the authoritative record for every DOI cited in the manuscript from
Crossref and formats a Vancouver-style numbered reference list. Running this
makes the bibliography reproducible and removes any possibility of a
hand-transcribed author list or page range being wrong.

Any DOI that fails to resolve, or whose record is incomplete, is reported
loudly rather than silently filled in.

Usage:
  python 11_build_references.py --out manuscript/references.md
"""
from __future__ import annotations

import argparse
import json
import os
import time
import html
import re
import urllib.parse
import urllib.request

MAILTO = "research@example.org"

# Cited works, in order of first appearance in the manuscript.
DOIS = [
    "10.1186/s13229-017-0121-4",          # Modabbernia 2017
    "10.24095/hpcdp.37.1.01",             # Ng 2017
    "10.1017/S0954579420000620",          # Carlsson 2021
    "10.1111/jcpp.12501",                 # Mandy & Lai 2016
    "10.61919/z7fb7t85",                  # Khawar 2025
    "10.1016/j.neubiorev.2024.105815",    # Tartaglione 2024
    "10.1289/ehp.1408133",                # Raz 2015
    "10.1097/EDE.0000000000000173",       # Kalkbrenner 2015
    "10.1001/jamapsychiatry.2013.266",    # Volk 2013
    "10.1289/EHP9509",                    # Rahman 2022
    "10.1001/jamanetworkopen.2025.38882", # Cloutier 2025
    "10.1021/acs.est.6c03766",            # Shupler 2026
    "10.1515/reveh-2025-0157",            # Nazneen 2026
    "10.1007/s10803-010-1006-y",          # Atladottir 2010
    "10.1038/mp.2017.119",                # Hornig 2018
    "10.1002/aur.2175",                   # Croen 2019
    "10.1001/jama.2013.2270",             # Christensen 2013
    "10.1001/jama.2012.155925",           # Suren 2013
    "10.1001/jamapsychiatry.2017.4050",   # Levine 2018
    "10.1093/aje/kwx184",                 # Wilson 2017 AJE
    "10.1093/biostatistics/kxx002",       # Wilson 2017 Biostatistics
    "10.1093/ije/dyab179",                # Basagana 2022
    "10.1002/sim.3940",                   # Gasparrini 2010
    "10.1186/s12940-023-01022-6",         # Liao 2023
    "10.1016/j.envpol.2019.113010",       # Jo 2019
    "10.3390/ijerph19073748",             # McGuinn 2022
    "10.1101/gr.180273.114",              # Spiers 2015
    "10.1038/nn.4181",                    # Jaffe 2016
    "10.1038/nature10523",                # Kang 2011
    "10.1038/nn.4182",                    # Hannon 2016
    "10.1073/pnas.2536758100",            # Laird 2004
    "10.1073/pnas.0502036102",            # Genereux 2005
    "10.1214/09-AOAS297",                 # Fu 2010
    "10.1101/gr.969603",                  # Ushijima 2003
    "10.1038/s41422-020-0359-9",          # Ming 2020
    "10.1038/s41594-018-0046-4",          # Charlton 2018
    "10.1093/nar/gkt1235",                # Haerter 2014
    "10.1093/nar/gkw124",                 # Lovkvist 2016
    "10.1093/nar/gkr753",                 # Rajavelu 2012
    "10.1074/jbc.M114.572032",            # Emperle 2014
    "10.1038/ng1909",                     # Eckhardt 2006
    "10.1038/nchem.2064",                 # Bachman 2014
    "10.1073/pnas.95.3.1242",             # Kornack & Rakic 1998
    "10.1016/j.stem.2016.03.003",         # Otani 2016
    "10.1523/JNEUROSCI.4445-12.2013",     # Malik 2013
    "10.1038/nrn2252",                    # Bystron 2008
    "10.1523/JNEUROSCI.5746-12.2013",     # Workman 2013
    "10.1016/j.cell.2011.06.030",         # Lui 2011
    "10.1126/science.aap8809",            # Nowakowski 2017
    "10.1126/science.1237905",            # Lister 2013
    "10.1186/s13059-019-1805-1",          # Price 2019
    "10.1016/j.cell.2017.09.047",         # Stroud 2017
    "10.1002/cne.21974",                  # Azevedo 2009
    "10.1289/EHP2450",                    # Weisskopf 2018
    "10.1093/ije/dyag162",                # Leung 2026
    "10.21037/tp-2026-0615",              # Lv 2026
    "10.2147/IJWH.S598686",               # Qi 2026
    "10.1016/j.scitotenv.2024.175080",    # Almeida-Toledano 2024
]

ABBREV = {
    "Molecular Autism": "Mol Autism",
    "Health Promotion and Chronic Disease Prevention in Canada": "Health Promot Chronic Dis Prev Can",
    "Development and Psychopathology": "Dev Psychopathol",
    "Journal of Child Psychology and Psychiatry": "J Child Psychol Psychiatry",
    "Neuroscience & Biobehavioral Reviews": "Neurosci Biobehav Rev",
    "Neuroscience and Biobehavioral Reviews": "Neurosci Biobehav Rev",
    "Proceedings of the National Academy of Sciences of the United States of America": "Proc Natl Acad Sci U S A",
    "Journal of Exposure Science & Environmental Epidemiology": "J Expo Sci Environ Epidemiol",
    "Nature Reviews Neuroscience": "Nat Rev Neurosci",
    "Science of the Total Environment": "Sci Total Environ",
    "Environmental Health Perspectives": "Environ Health Perspect",
    "Epidemiology": "Epidemiology",
    "JAMA Psychiatry": "JAMA Psychiatry",
    "JAMA Network Open": "JAMA Netw Open",
    "Environmental Science & Technology": "Environ Sci Technol",
    "Reviews on Environmental Health": "Rev Environ Health",
    "Journal of Autism and Developmental Disorders": "J Autism Dev Disord",
    "Molecular Psychiatry": "Mol Psychiatry",
    "Autism Research": "Autism Res",
    "JAMA": "JAMA",
    "American Journal of Epidemiology": "Am J Epidemiol",
    "Biostatistics": "Biostatistics",
    "International Journal of Epidemiology": "Int J Epidemiol",
    "Statistics in Medicine": "Stat Med",
    "Environmental Health": "Environ Health",
    "Environmental Pollution": "Environ Pollut",
    "International Journal of Environmental Research and Public Health": "Int J Environ Res Public Health",
    "Genome Research": "Genome Res",
    "Nature Neuroscience": "Nat Neurosci",
    "Nature": "Nature",
    "Proceedings of the National Academy of Sciences": "Proc Natl Acad Sci U S A",
    "The Annals of Applied Statistics": "Ann Appl Stat",
    "Cell Research": "Cell Res",
    "Nature Structural & Molecular Biology": "Nat Struct Mol Biol",
    "Nucleic Acids Research": "Nucleic Acids Res",
    "Journal of Biological Chemistry": "J Biol Chem",
    "Nature Genetics": "Nat Genet",
    "Nature Chemistry": "Nat Chem",
    "Cell Stem Cell": "Cell Stem Cell",
    "The Journal of Neuroscience": "J Neurosci",
    "Nature Reviews Neuroscience": "Nat Rev Neurosci",
    "Cell": "Cell",
    "Science": "Science",
    "Genome Biology": "Genome Biol",
    "The Journal of Comparative Neurology": "J Comp Neurol",
    "Translational Pediatrics": "Transl Pediatr",
    "International Journal of Women's Health": "Int J Womens Health",
    "Science of The Total Environment": "Sci Total Environ",
    "Journal of Health, Wellness and Community Research": "J Health Wellness Community Res",
}


def fetch(doi: str) -> dict | None:
    url = ("https://api.crossref.org/works/"
           + urllib.parse.quote(doi, safe="")
           + f"?mailto={MAILTO}")
    for attempt in range(4):
        try:
            with urllib.request.urlopen(url, timeout=40) as r:
                return json.loads(r.read().decode())["message"]
        except Exception as exc:                                  # noqa: BLE001
            if attempt == 3:
                print(f"[FAIL] {doi}: {exc}")
                return None
            time.sleep(2 + 2 * attempt)
    return None


# Crossref stores each author's full name in the family-name field for this
# journal; the surnames were confirmed against the article's byline.
AUTHOR_OVERRIDE = {
    "10.61919/z7fb7t85": "Khawar M, Tayyab B, Naz I",
}


def clean(text: str) -> str:
    """Unescape HTML entities and strip inline markup from Crossref strings."""
    text = html.unescape(html.unescape(text or ""))
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\s+", " ", text).strip()


def author_string(msg: dict) -> str:
    auths = msg.get("author", [])
    out = []
    for a in auths:
        fam = (a.get("family") or "").strip()
        giv = (a.get("given") or "").strip()
        if not fam:
            fam = (a.get("name") or "").strip()
        initials = "".join(w[0].upper() for w in giv.replace("-", " ").split() if w)
        out.append(f"{fam} {initials}".strip())
    if not out:
        return "[author list unavailable]"
    if len(out) > 6:
        return ", ".join(out[:6]) + ", et al."
    return ", ".join(out)


def year_of(msg: dict) -> str:
    for key in ("published-print", "published", "issued", "published-online"):
        dp = msg.get(key, {}).get("date-parts", [[None]])
        if dp and dp[0] and dp[0][0]:
            return str(dp[0][0])
    return "n.d."


def format_ref(n: int, msg: dict, doi: str) -> tuple[str, list[str]]:
    warn = []
    issue = ""
    title = clean((msg.get("title") or ["[title unavailable]"])[0])
    journal = (msg.get("container-title") or [""])
    journal = clean(journal[0] if journal else "")
    journal = ABBREV.get(journal, journal)
    year = year_of(msg)
    vol = msg.get("volume", "")
    issue = msg.get("issue", "")
    # Crossref lacks volume/issue for this journal; taken from the article page.
    if doi.lower() == "10.61919/z7fb7t85":
        vol, issue = "3", "14"
    page = msg.get("page", "") or msg.get("article-number", "")
    auth = AUTHOR_OVERRIDE.get(doi.lower()) or author_string(msg)
    if auth.startswith("[author"):
        warn.append(f"ref {n} ({doi}): no author list in Crossref")
    if not journal:
        warn.append(f"ref {n} ({doi}): no journal name in Crossref")
    if not vol:
        warn.append(f"ref {n} ({doi}): no volume in Crossref")
    if not page:
        warn.append(f"ref {n} ({doi}): no pages or article number in Crossref")

    sep = "" if auth.endswith("et al.") else "."
    bits = f"{n}. {auth}{sep} {title}. {journal}. {year}"
    if vol:
        bits += f";{vol}"
        if issue:
            bits += f"({issue})"
        if page:
            bits += f":{page}"
    elif page:
        bits += f":{page}"
    bits += f". doi:{doi}"
    return bits, warn


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="manuscript/references.md")
    args = ap.parse_args()
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)

    lines, warns, failed = [], [], []
    seen = set()
    n = 0
    for doi in DOIS:
        key = doi.lower()
        if key in seen:
            print(f"[warn] duplicate DOI skipped: {doi}")
            continue
        seen.add(key)
        msg = fetch(doi)
        if msg is None:
            failed.append(doi)
            continue
        n += 1
        line, w = format_ref(n, msg, doi)
        lines.append(line)
        warns.extend(w)
        print(f"[ok] {n:2d}. {line[:110]}")
        time.sleep(0.12)

    with open(args.out, "w") as fh:
        fh.write("# References\n\n")
        fh.write("\n\n".join(lines) + "\n")
    print(f"\n[done] {n} references written to {args.out}")
    if warns:
        print("\nIncomplete Crossref records (check before submission):")
        for w in warns:
            print("  -", w)
    if failed:
        print("\nDOIs THAT DID NOT RESOLVE (must be fixed):")
        for f in failed:
            print("  -", f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
