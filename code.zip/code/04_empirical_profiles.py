#!/usr/bin/env python3
"""
04_empirical_profiles.py

Model-free characterisation of epigenetic remodelling in the human fetal brain
from GSE58885 (Illumina 450K, n = 179 donors, 3.3-26.3 post-conception weeks).

The script produces the quantities that the mechanistic model of the companion
analysis is later required to reproduce, none of which are used to fit it:

1. Remodelling intensity Phi_obs(t): the root-mean-square rate of change of
   locus methylation per week, corrected for the sampling noise of the binned
   means by a method-of-moments subtraction,

       Phi_obs(t) = sqrt( max( E[(dm)^2] - E[s^2], 0 ) ) / dt                (1)

   where s^2 is the summed squared standard error of the two bracketing bin
   means. Without this correction the estimator is upward biased.

2. Cumulative remodelling R_cum(t), the integral of Phi_obs.

3. Inter-individual dispersion D_obs(t) = Var_i(m) / (mbar (1 - mbar)), the
   variance normalised by its maximal scale, reported both unadjusted and after
   removing array-slide (batch) effects. Because slides are randomised with
   respect to gestational age in this series, the time trend of D_obs is not
   attributable to batch.

4. The dominant temporal mode of developmental change (first right singular
   vector of the per-probe centred trajectories) and its variance share.

All quantities are reported for the whole autosomal probe set and stratified by
CpG-island relation and gene region, with 95% confidence intervals from a
donor-level bootstrap.

Usage:
  python 04_empirical_profiles.py --beta results/beta_matrix.npy \
      --stats results/methylation_probe_stats.npz \
      --annot results/probe_annotation.csv.gz \
      --meta results/sample_metadata.csv --outdir results [--nboot 300]
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd
from scipy import stats as sps

RNG_SEED = 20261027
EPS = 1e-12


def bh_fdr(p: np.ndarray) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    ok = np.isfinite(p)
    q = np.full(p.shape, np.nan)
    pv = p[ok]
    order = np.argsort(pv)
    n = pv.size
    ranked = pv[order] * n / (np.arange(n) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.minimum(ranked, 1.0)
    q[ok] = out
    return q


def binned(beta: np.ndarray, members: list[np.ndarray]):
    """Per-probe bin mean, unbiased variance and bin size."""
    nb = len(members)
    bm = np.empty((beta.shape[0], nb))
    bv = np.empty((beta.shape[0], nb))
    bn = np.empty(nb)
    for b, idx in enumerate(members):
        sub = beta[:, idx]
        bm[:, b] = sub.mean(axis=1)
        bv[:, b] = sub.var(axis=1, ddof=1) if len(idx) > 1 else np.nan
        bn[b] = len(idx)
    return bm, bv, bn


def profiles(bm: np.ndarray, bv: np.ndarray, bn: np.ndarray,
             centres: np.ndarray) -> dict:
    """Remodelling intensity, cumulative remodelling and dispersion."""
    dt = np.diff(centres)
    dm = np.diff(bm, axis=1)
    sem2 = bv / bn[None, :]
    noise = sem2[:, 1:] + sem2[:, :-1]

    m2 = np.nanmean(dm ** 2, axis=0)
    nz = np.nanmean(noise, axis=0)
    phi = np.sqrt(np.maximum(m2 - nz, 0.0)) / dt

    # signed ensemble drift (net directional remodelling)
    drift_net = np.nanmean(dm, axis=0) / dt

    mbar = np.nanmean(bm, axis=0)
    scale = np.maximum(mbar * (1.0 - mbar), EPS)
    disp = np.nanmean(bv, axis=0) / scale

    return {"phi": phi, "drift_net": drift_net,
            "cum": np.concatenate([[0.0], np.cumsum(phi * dt)]),
            "disp": disp, "var_mean": np.nanmean(bv, axis=0),
            "mbar": mbar, "noise_share": nz / np.maximum(m2, EPS)}


def remove_slide(beta: np.ndarray, slide_codes: np.ndarray) -> np.ndarray:
    """Subtract per-slide probe means (batch adjustment), restoring the grand mean."""
    out = beta.copy()
    grand = beta.mean(axis=1, keepdims=True)
    for s in np.unique(slide_codes):
        cols = np.where(slide_codes == s)[0]
        if len(cols) < 2:
            continue
        out[:, cols] -= beta[:, cols].mean(axis=1, keepdims=True) - grand
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", required=True)
    ap.add_argument("--stats", required=True)
    ap.add_argument("--annot", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--nboot", type=int, default=300)
    ap.add_argument("--fdr", type=float, default=0.05)
    args = ap.parse_args()

    st = np.load(args.stats, allow_pickle=True)
    pcw = st["pcw"].astype(float)
    bin_edges = st["bin_edges"].astype(float)
    probe_id = st["probe_id"]
    meta = pd.read_csv(args.meta)
    assert (meta["gsm"].to_numpy() == st["gsm"]).all(), "sample order mismatch"
    slide_codes = pd.factorize(meta["slide"])[0]

    annot = pd.read_csv(args.annot, low_memory=False).set_index("probe_id").reindex(probe_id)
    beta = np.load(args.beta, mmap_mode="r")

    keep = (annot["sex_chrom"].to_numpy() == 0) & (annot["has_snp"].to_numpy() == 0)
    print(f"[info] QC retains {keep.sum()} of {len(keep)} probes", flush=True)
    beta = np.ascontiguousarray(beta[keep], dtype=np.float32)
    annot = annot.iloc[keep].reset_index()
    probe_id = probe_id[keep]

    bin_idx = np.digitize(pcw, bin_edges, right=False) - 1
    n_bins = len(bin_edges) - 1
    members = [np.where(bin_idx == b)[0] for b in range(n_bins)]
    centres = np.array([pcw[m].mean() for m in members])
    mid = 0.5 * (centres[1:] + centres[:-1])
    print(f"[info] {n_bins} bins, centres {np.round(centres,2).tolist()}", flush=True)

    bm, bv, bn = binned(beta.astype(np.float64), members)

    # ---- developmentally dynamic probe set -------------------------------
    ntot = bn.sum()
    grand = np.nansum(bm * bn, axis=1) / ntot
    ssb = np.nansum(bn * (bm - grand[:, None]) ** 2, axis=1)
    ssw = np.nansum((bn - 1.0) * bv, axis=1)
    F = (ssb / (n_bins - 1)) / (ssw / (ntot - n_bins))
    q = bh_fdr(sps.f.sf(F, n_bins - 1, ntot - n_bins))
    dynamic = np.isfinite(q) & (q < args.fdr)
    print(f"[info] dynamic probes FDR<{args.fdr}: {int(dynamic.sum())} "
          f"({100*dynamic.mean():.1f}%)", flush=True)

    # ---- point estimates -------------------------------------------------
    strata: dict[str, np.ndarray] = {"all": np.ones(len(probe_id), bool),
                                     "dynamic": dynamic}
    for rel in ("Island", "N_Shore", "S_Shore", "OpenSea"):
        strata[f"island_{rel}"] = (annot["island_relation"].to_numpy() == rel)
    for reg in ("TSS200", "TSS1500", "Body", "Intergenic"):
        strata[f"region_{reg}"] = (annot["region"].to_numpy() == reg)
    strata["dynamic_Island"] = dynamic & (annot["island_relation"].to_numpy() == "Island")
    strata["dynamic_OpenSea"] = dynamic & (annot["island_relation"].to_numpy() == "OpenSea")

    point = {k: profiles(bm[m], bv[m], bn, centres) for k, m in strata.items()}

    # slide-adjusted dispersion (dynamic probes)
    beta_adj = remove_slide(beta[dynamic].astype(np.float64), slide_codes)
    bm_a, bv_a, _ = binned(beta_adj, members)
    adj = profiles(bm_a, bv_a, bn, centres)
    del beta_adj

    # ---- dominant temporal mode -----------------------------------------
    Yc = bm[dynamic] - bm[dynamic].mean(axis=1, keepdims=True)
    _, S, Vt = np.linalg.svd(Yc, full_matrices=False)
    var_share = (S ** 2) / (S ** 2).sum()
    pc1 = Vt[0] * np.sign(Vt[0][0] - Vt[0][-1])     # orient: early-high
    print(f"[info] dominant mode variance share {var_share[0]:.4f}; "
          f"next {var_share[1]:.4f}", flush=True)

    # ---- donor bootstrap -------------------------------------------------
    rng = np.random.default_rng(RNG_SEED)
    keys = ("phi", "drift_net", "cum", "disp", "var_mean")
    boot: dict[str, dict[str, list]] = {k: {kk: [] for kk in keys} for k in strata}
    boot_pc1, boot_share = [], []
    dyn_beta = beta[dynamic].astype(np.float64)

    for b in range(args.nboot):
        resampled = [rng.choice(m, size=len(m), replace=True) if len(m) > 1 else m
                     for m in members]
        bmb, bvb, bnb = binned(beta.astype(np.float64), resampled)
        for k, msk in strata.items():
            pr = profiles(bmb[msk], bvb[msk], bnb, centres)
            for kk in keys:
                boot[k][kk].append(pr[kk])
        Ycb = bmb[dynamic] - bmb[dynamic].mean(axis=1, keepdims=True)
        _, Sb, Vtb = np.linalg.svd(Ycb, full_matrices=False)
        v = Vtb[0] * np.sign(Vtb[0][0] - Vtb[0][-1])
        boot_pc1.append(v)
        boot_share.append((Sb ** 2 / (Sb ** 2).sum())[0])
        if (b + 1) % 50 == 0:
            print(f"[info] bootstrap {b+1}/{args.nboot}", flush=True)

    def ci(arr_list):
        a = np.asarray(arr_list)
        return np.percentile(a, 2.5, axis=0), np.percentile(a, 97.5, axis=0)

    # ---- assemble outputs ------------------------------------------------
    os.makedirs(args.outdir, exist_ok=True)
    rows = []
    for j in range(len(mid)):
        lo, hi = ci(boot["dynamic"]["phi"])
        lon, hin = ci(boot["dynamic"]["drift_net"])
        rows.append({
            "pcw_mid": mid[j], "dt_weeks": np.diff(centres)[j],
            "phi_dynamic": point["dynamic"]["phi"][j],
            "phi_lo95": lo[j], "phi_hi95": hi[j],
            "phi_all": point["all"]["phi"][j],
            "drift_net": point["dynamic"]["drift_net"][j],
            "drift_net_lo95": lon[j], "drift_net_hi95": hin[j],
            "noise_share": point["dynamic"]["noise_share"][j],
        })
    pd.DataFrame(rows).to_csv(os.path.join(args.outdir, "remodelling_rate.csv"),
                              index=False)

    drows = []
    lo_d, hi_d = ci(boot["dynamic"]["disp"])
    lo_a, hi_a = ci(boot["all"]["disp"])
    for b in range(n_bins):
        drows.append({
            "pcw": centres[b], "n_donors": bn[b],
            "disp_dynamic": point["dynamic"]["disp"][b],
            "disp_dynamic_lo95": lo_d[b], "disp_dynamic_hi95": hi_d[b],
            "disp_all": point["all"]["disp"][b],
            "disp_all_lo95": lo_a[b], "disp_all_hi95": hi_a[b],
            "disp_dynamic_slideadj": adj["disp"][b],
            "mean_beta": point["all"]["mbar"][b],
            "pc1_loading": pc1[b],
            "pc1_lo95": np.percentile(np.asarray(boot_pc1)[:, b], 2.5),
            "pc1_hi95": np.percentile(np.asarray(boot_pc1)[:, b], 97.5),
            "cum_remodelling": point["dynamic"]["cum"][b],
        })
    pd.DataFrame(drows).to_csv(os.path.join(args.outdir, "dispersion_trajectory.csv"),
                               index=False)

    strat_rows = []
    for k in strata:
        lo, hi = ci(boot[k]["phi"])
        for j in range(len(mid)):
            strat_rows.append({"stratum": k, "n_probes": int(strata[k].sum()),
                               "pcw_mid": mid[j], "phi": point[k]["phi"][j],
                               "phi_lo95": lo[j], "phi_hi95": hi[j]})
    pd.DataFrame(strat_rows).to_csv(
        os.path.join(args.outdir, "remodelling_by_stratum.csv"), index=False)

    np.savez_compressed(
        os.path.join(args.outdir, "empirical_profiles.npz"),
        centres=centres, mid=mid, bn=bn, pc1=pc1, pc1_var_share=var_share[:10],
        pc1_share_boot=np.asarray(boot_share),
        pc1_boot=np.asarray(boot_pc1),
        phi=point["dynamic"]["phi"], phi_boot=np.asarray(boot["dynamic"]["phi"]),
        phi_all=point["all"]["phi"],
        disp=point["dynamic"]["disp"], disp_boot=np.asarray(boot["dynamic"]["disp"]),
        disp_slideadj=adj["disp"],
        drift_net=point["dynamic"]["drift_net"],
        cum=point["dynamic"]["cum"],
        anova_F=F, anova_q=q, dynamic=dynamic, probe_id=probe_id,
        mean_beta=point["all"]["mbar"],
    )

    print("\n pcw_mid   Phi(1/wk)   95% CI            net drift   noise share")
    for j in range(len(mid)):
        lo, hi = ci(boot["dynamic"]["phi"])
        print(f"{mid[j]:8.2f} {point['dynamic']['phi'][j]:10.5f}  "
              f"[{lo[j]:.5f},{hi[j]:.5f}]  {point['dynamic']['drift_net'][j]:+10.5f}  "
              f"{point['dynamic']['noise_share'][j]:8.3f}")
    print("\n pcw    dispersion   slide-adj    PC1 loading")
    for b in range(n_bins):
        print(f"{centres[b]:6.2f} {point['dynamic']['disp'][b]:11.5f} "
              f"{adj['disp'][b]:11.5f} {pc1[b]:+12.4f}")
    print("[done] wrote remodelling_rate.csv, dispersion_trajectory.csv, "
          "remodelling_by_stratum.csv, empirical_profiles.npz", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
