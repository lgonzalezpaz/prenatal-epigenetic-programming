#!/usr/bin/env python3
"""
12_build_docx.py

Compiles manuscript/manuscript.md into a submission-formatted Word document.

Applied styling: A4 with 2.54 cm margins; Times New Roman throughout; 12 pt
double-spaced body text, left aligned, no first-line indent; a 16 pt bold
title; 12 pt centred author line with superscript affiliation markers; 10 pt
affiliations and correspondence; an 11 pt single-paragraph abstract; 10 pt
keywords; 13 pt bold level-1 headings and 11.5 pt bold-italic level-2 headings,
unnumbered; centred equations with right-aligned numbers on a tab stop;
9.5 pt references; page numbers in the top-right header; and continuous line
numbers in the left margin.

Figures are embedded at their callout positions at full column width, with the
corresponding legend beneath. Tables are inserted at their callouts from the
generated CSV files, with the caption above.

Usage:
  python 12_build_docx.py --md manuscript/manuscript.md \
      --refs manuscript/references.md --figures figures --tables tables \
      --out manuscript/manuscript.docx
"""
from __future__ import annotations

import argparse
import os
import re

import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT = "Times New Roman"
BLACK = RGBColor(0, 0, 0)

FIG_FILES = {
    1: "figure1_remodelling_trajectory.png",
    2: "figure2_remodelling_intensity.png",
    3: "figure3_machinery.png",
    4: "figure4_permanence_kernel.png",
    5: "figure5_replication_scenarios.png",
    6: "figure6_identifiability.png",
}
TABLE_FILES = {
    1: ("table1_datasets.csv",
        "Table 1. Public datasets used, with the role of each in the analysis."),
    2: ("table2_parameters.csv",
        "Table 2. Model parameters, prior distributions and their empirical basis."),
    3: ("table3_remodelling_by_week.csv",
        "Table 3. Measured epigenetic remodelling intensity by gestational week, "
        "with donor-bootstrap confidence intervals and the equal-sampling control."),
    4: ("table4_robustness.csv",
        "Table 4. Robustness of the measured remodelling peak."),
    5: ("table5_replication.csv",
        "Table 5. Cross-cohort comparison over the shared gestational window "
        "(12-18 post-conception weeks)."),
    6: ("table6_scenarios.csv",
        "Table 6. Sensitivity of the permanence window to assumptions about the "
        "unmeasured third trimester."),
    7: ("table7_identifiability.csv",
        "Table 7. A single permanence kernel produces different apparent windows "
        "depending only on the correlation structure of exposure."),
    8: ("table8_power.csv",
        "Table 8. Cohort size required to localise the permanence window by a "
        "distributed-lag analysis."),
}


# --------------------------------------------------------------------------
def set_base_style(doc: Document) -> None:
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(12)
    st.font.color.rgb = BLACK
    rpr = st.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), FONT)
    pf = st.paragraph_format
    pf.line_spacing = 2.0
    pf.space_after = Pt(10)
    pf.first_line_indent = Pt(0)
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT


def page_setup(doc: Document) -> None:
    for s in doc.sections:
        s.page_width = Cm(21.0)
        s.page_height = Cm(29.7)
        for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
            setattr(s, m, Cm(2.54))


def add_line_numbers(doc: Document) -> None:
    """Continuous line numbering in the left margin."""
    for s in doc.sections:
        sect_pr = s._sectPr
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:start"), "1")
        ln.set(qn("w:restart"), "continuous")
        ln.set(qn("w:distance"), "360")
        sect_pr.append(ln)


def add_page_number_header(doc: Document) -> None:
    for s in doc.sections:
        p = s.header.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.paragraph_format.line_spacing = 1.0
        run = p.add_run()
        for instr in ("begin", None, "end"):
            el = OxmlElement("w:fldChar") if instr else OxmlElement("w:instrText")
            if instr:
                el.set(qn("w:fldCharType"), instr)
            else:
                el.set(qn("xml:space"), "preserve")
                el.text = " PAGE "
            run._r.append(el)
        run.font.name = FONT
        run.font.size = Pt(10)


def para(doc, text="", size=12, bold=False, italic=False, align="left",
         spacing=2.0, space_after=10, keep_with_next=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = spacing
    pf.space_after = Pt(space_after)
    pf.first_line_indent = Pt(0)
    pf.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                    "center": WD_ALIGN_PARAGRAPH.CENTER,
                    "right": WD_ALIGN_PARAGRAPH.RIGHT,
                    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY}[align]
    pf.keep_with_next = keep_with_next
    if text:
        add_rich(p, text, size, bold, italic)
    return p


INLINE = re.compile(r"(\*\*.+?\*\*|\*[^*]+?\*|\^[^^]+?\^|`[^`]+?`)", re.S)


def add_rich(p, text: str, size=12, bold=False, italic=False) -> None:
    """Render **bold**, *italic*, ^superscript^ and `code` inline."""
    text = text.replace("&nbsp;", " ").replace("\\*", "\u0001")
    for tok in INLINE.split(text):
        if not tok:
            continue
        b, i, sup, mono = bold, italic, False, False
        if tok.startswith("**") and tok.endswith("**") and len(tok) > 4:
            tok, b = tok[2:-2], True
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            tok, i = tok[1:-1], True
        elif tok.startswith("^") and tok.endswith("^") and len(tok) > 2:
            tok, sup = tok[1:-1], True
        elif tok.startswith("`") and tok.endswith("`") and len(tok) > 2:
            tok, mono = tok[1:-1], True
        run = p.add_run(tok.replace("\u0001", "*"))
        run.font.name = mono and "Courier New" or FONT
        run.font.size = Pt(size - (1 if mono else 0))
        run.font.bold = b
        run.font.italic = i
        run.font.color.rgb = BLACK
        if sup:
            run.font.superscript = True
        rpr = run._element.get_or_add_rPr()
        rf = rpr.find(qn("w:rFonts"))
        if rf is None:
            rf = OxmlElement("w:rFonts"); rpr.append(rf)
        for a in ("w:ascii", "w:hAnsi", "w:cs"):
            rf.set(qn(a), run.font.name)


def add_equation(doc, body: str, number: str | None) -> None:
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_after = Pt(10)
    pf.space_before = Pt(6)
    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf.tab_stops.add_tab_stop(Cm(7.6), WD_TAB_ALIGNMENT.CENTER)
    pf.tab_stops.add_tab_stop(Cm(15.9), WD_TAB_ALIGNMENT.RIGHT)
    p.add_run("\t")
    add_rich(p, body, size=12, italic=True)
    if number:
        p.add_run("\t")
        r = p.add_run(number)
        r.font.name = FONT; r.font.size = Pt(12); r.font.color.rgb = BLACK


def add_table(doc, csv_path: str, caption: str) -> None:
    df = pd.read_csv(csv_path).fillna("")
    para(doc, caption, size=10, bold=True, spacing=1.0, space_after=4,
         keep_with_next=True)
    t = doc.add_table(rows=1, cols=len(df.columns))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for j, c in enumerate(df.columns):
        hdr[j].text = ""
        p = hdr[j].paragraphs[0]
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.space_after = Pt(2)
        add_rich(p, str(c), size=8.5, bold=True)
    for _, row in df.iterrows():
        cells = t.add_row().cells
        for j, v in enumerate(row):
            cells[j].text = ""
            p = cells[j].paragraphs[0]
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.space_after = Pt(2)
            add_rich(p, str(v), size=8.5)
    para(doc, "", spacing=1.0, space_after=6)


def add_figure(doc, path: str, number: int) -> None:
    if not os.path.exists(path):
        para(doc, f"[Figure {number} image not found: {path}]", size=10,
             italic=True)
        return
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_after = Pt(4)
    p.add_run().add_picture(path, width=Cm(15.9))


# --------------------------------------------------------------------------
def build(md_path, refs_path, figdir, tabdir, out_path) -> None:
    md = open(md_path).read()
    doc = Document()
    set_base_style(doc)
    page_setup(doc)
    add_line_numbers(doc)
    add_page_number_header(doc)

    lines = md.split("\n")
    i = 0
    state = "front"
    legends: dict[int, str] = {}

    # pre-scan legends so each can be placed under its figure
    for m in re.finditer(r"\*\*Figure (\d)\.(.+?)\*\*\n(.+?)(?=\n\n|\Z)", md, re.S):
        legends[int(m.group(1))] = (f"Figure {m.group(1)}.{m.group(2)} "
                                    + " ".join(m.group(3).split()))

    while i < len(lines):
        ln = lines[i].rstrip()
        s = ln.strip()

        if s.startswith("# "):
            para(doc, s[2:], size=16, bold=True, align="left", spacing=1.3,
                 space_after=12)
        elif s.startswith("## "):
            head = s[3:]
            if head == "Figure legends":
                state = "legends"
            para(doc, head, size=13, bold=True, spacing=1.2, space_after=8,
                 keep_with_next=True)
        elif s.startswith("### "):
            para(doc, s[4:], size=11.5, bold=True, italic=True, spacing=1.2,
                 space_after=6, keep_with_next=True)
        elif s in ("---", "***"):
            pass
        elif re.fullmatch(r"\*\*\[Figure (\d) near here\]\*\*", s):
            n = int(re.findall(r"\d", s)[0])
            para(doc, f"[Figure {n} near here]", size=10, bold=True,
                 align="center", spacing=1.0, space_after=4)
            add_figure(doc, os.path.join(figdir, FIG_FILES[n]), n)
            if n in legends:
                para(doc, legends[n], size=9.5, spacing=1.0, space_after=10)
        elif re.fullmatch(r"\*\*\[Table (\d) near here\]\*\*", s):
            n = int(re.findall(r"\d", s)[0])
            fn, cap = TABLE_FILES[n]
            para(doc, f"[Table {n} near here]", size=10, bold=True,
                 align="center", spacing=1.0, space_after=4)
            add_table(doc, os.path.join(tabdir, fn), cap)
        elif s.startswith("&nbsp;") or ln.startswith("&nbsp;"):
            body = s.replace("&nbsp;", " ").strip()
            m = re.search(r"\((\d+)\)\s*$", body)
            num = f"({m.group(1)})" if m else None
            if num:
                body = body[: m.start()].strip()
            add_equation(doc, body, num)
        elif s.startswith("**Keywords:**"):
            para(doc, s, size=10, spacing=1.3, space_after=12)
        elif state == "front" and s.startswith("^"):
            para(doc, s, size=10, align="center", spacing=1.1, space_after=2)
        elif state == "front" and s.startswith("\\*Correspondence"):
            para(doc, s.replace("\\*", "*"), size=10, align="center",
                 spacing=1.1, space_after=12)
        elif state == "front" and s.startswith("**[AUTHOR"):
            para(doc, s, size=12, align="center", spacing=1.3, space_after=6)
        elif state == "legends":
            if s.startswith("**Figure"):
                blk = [s]
                while i + 1 < len(lines) and lines[i + 1].strip():
                    i += 1
                    blk.append(lines[i].strip())
                para(doc, " ".join(blk), size=10, spacing=1.3, space_after=10)
        elif s == "":
            pass
        else:
            if md[: md.find(ln)].count("## Abstract") and \
               md[: md.find(ln)].count("## Keywords") == 0 and \
               "## Introduction" not in md[: md.find(ln)]:
                para(doc, s, size=11, align="justify", spacing=1.4,
                     space_after=10)
            else:
                para(doc, s, size=12, align="left", spacing=2.0, space_after=10)
        i += 1

    # ---- references ------------------------------------------------------
    doc.add_page_break()
    para(doc, "References", size=13, bold=True, spacing=1.2, space_after=8)
    refs = open(refs_path).read()
    for line in refs.split("\n"):
        t = line.strip()
        if not t or t.startswith("#"):
            continue
        para(doc, t, size=9.5, spacing=1.15, space_after=4)

    doc.save(out_path)
    print(f"[done] wrote {out_path}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", default="manuscript/manuscript.md")
    ap.add_argument("--refs", default="manuscript/references.md")
    ap.add_argument("--figures", default="figures")
    ap.add_argument("--tables", default="tables")
    ap.add_argument("--out", default="manuscript/manuscript.docx")
    a = ap.parse_args()
    build(a.md, a.refs, a.figures, a.tables, a.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
