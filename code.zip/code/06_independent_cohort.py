#!/usr/bin/env python3
"""
06_independent_cohort.py

Out-of-cohort replication of the fetal epigenetic remodelling profile in an
independent dataset: GSE74193 (Jaffe et al., Nat Neurosci 2016), dorsolateral
prefrontal cortex, Illumina 450K. Only prenatal, non-psychiatric control arrays
that pass the depositors' own quality flag are used; these span seven one-week
bins from about 12 to 18 post-conception weeks, which overlaps the most densely
sampled part of GSE58885.

The same estimator as script 04b is applied: noise-corrected pairwise
methylomic distances between weekly bins, a monotone one-dimensional embedding,
and the derivative of the cumulative curve. Replication is assessed by (i) the
rank correlation of the two remodelling profiles over the shared window, (ii)
agreement of the monotone ordering, and (iii) whether remodelling accelerates
across the shared window in both cohorts.

GSE74193 ships per-sample cell-composition estimates (neuronal, non-neuronal,
NPC, embryonic-stem and dopaminergic fractions). These are used to test directly
whether the remodelling signal survives adjustment for cell composition, which
cannot be done within GSE58885.

Usage:
  python 06_independent_cohort.py --proc <GSE74193_procData.csv.gz> \
      --meta <gse74193_meta.csv> --probes results/methylation_probe_stats.npz \
      --annot results/probe_annotation.csv.gz --outdir results
"""
from __future__ import annotations

import argparse
import csv
import gzip
import os

import numpy as np
import pandas as pd

RNG_SEED = 20261027
# The depositors applied their own array-level quality control and provide a
# per-array "dropsample" flag, which is used instead. The distributed detectP
# column in this series does not behave like a conventional detection p-value
# (values are broadly spread over [0, 1]), so it is not used for filtering.
DETECT_P_MAX = None


def load_meta(path: str) -> pd.DataFrame:
    m = pd.read_csv(path)
    m["age"] = pd.to_numeric(m["age"], errors="coerce")
    m = m[np.isfinite(m["age"])]
    pren = m[m["age"] < 0].copy()
    pren["ga_weeks"] = 40.0 + pren["age"] * 52.1775
    pren["pcw"] = pren["ga_weeks"] - 2.0
    keep = (pren["group"].astype(str).str.strip() == "Control") & \
           (pren["dropsample"].astype(str).str.upper().str.strip() == "FALSE")
    pren = pren[keep].copy()
    pren["sample_tag"] = pren["title"].astype(str).str.split("_").str[0]
    return pren


def stream_betas(proc_path: str, want_cols: list[str], probe_keep: set[str]):
    """Stream the processed matrix, keeping requested Beta columns and probes."""
    with gzip.open(proc_path, "rt", newline="") as fh:
        rdr = csv.reader(fh)
        header = next(rdr)
        idx_beta, idx_p = [], []
        for tag in want_cols:
            bcol, pcol = f"{tag}_Beta", f"{tag}_detectP"
            if bcol not in header:
                raise RuntimeError(f"column {bcol} absent")
            idx_beta.append(header.index(bcol))
            idx_p.append(header.index(pcol) if pcol in header else -1)
        ids, rows = [], []
        for rec in rdr:
            pid = rec[0].strip().strip('"')
            if pid not in probe_keep:
                continue
            vals = np.empty(len(idx_beta), dtype=np.float32)
            for j, (bi, pi) in enumerate(zip(idx_beta, idx_p)):
                try:
                    v = float(rec[bi])
                except (ValueError, IndexError):
                    v = np.nan
                if pi >= 0 and DETECT_P_MAX is not None:
                    try:
                        if float(rec[pi]) > DETECT_P_MAX:
                            v = np.nan
                    except (ValueError, IndexError):
                        pass
                vals[j] = v
            ids.append(pid); rows.append(vals)
            if len(ids) % 50000 == 0:
                print(f"[info] {len(ids)} probes read", flush=True)
    return np.asarray(ids), np.vstack(rows)


def binned(beta: np.ndarray, members, ages=None):
    nb = len(members)
    bm = np.empty((beta.shape[0], nb)); bv = np.empty((beta.shape[0], nb))
    bn = np.empty(nb)
    for b, idx in enumerate(members):
        sub = beta[:, idx]; n = len(idx)
        bm[:, b] = np.nanmean(sub, axis=1); bn[b] = n
        bv[:, b] = np.nanvar(sub, axis=1, ddof=1) if n > 1 else np.nan
    return bm, bv, bn


def distance2(bm, bv, bn):
    nb = bm.shape[1]
    sem2 = bv / bn[None, :]
    D2 = np.zeros((nb, nb))
    for a in range(nb):
        for b in range(a + 1, nb):
            d = bm[:, a] - bm[:, b]
            D2[a, b] = D2[b, a] = (float(np.nanmean(d * d))
                                   - float(np.nanmean(sem2[:, a] + sem2[:, b])))
    return D2


def fit_monotone(D2, weights, nb):
    from scipy.optimize import least_squares
    pairs = [(a, b) for a in range(nb) for b in range(a + 1, nb)]
    y = np.array([D2[a, b] for a, b in pairs])
    A = np.zeros((len(pairs), nb - 1))
    for r, (a, b) in enumerate(pairs):
        A[r, a:b] = 1.0
    w = np.sqrt(weights)
    x0 = np.full(nb - 1, np.sqrt(max(np.nanmax(y), 1e-8)) / max(nb - 1, 1))
    sol = least_squares(lambda g: w * (y - (A @ g) ** 2), x0,
                        bounds=(0.0, np.inf), max_nfev=20000)
    g = sol.x
    pred = (A @ g) ** 2
    ss_res = float(np.sum(weights * (y - pred) ** 2))
    ybar = float(np.average(y, weights=weights))
    ss_tot = float(np.sum(weights * (y - ybar) ** 2))
    return np.concatenate([[0.0], np.cumsum(g)]), 1.0 - ss_res / ss_tot


def smooth_derivative(t, G, grid, bw=1.8):
    Gs = np.empty_like(grid); dG = np.empty_like(grid)
    for i, g0 in enumerate(grid):
        w = np.exp(-0.5 * ((t - g0) / bw) ** 2)
        X = np.column_stack([np.ones_like(t), t - g0])
        Wm = np.diag(w)
        try:
            b = np.linalg.solve(X.T @ Wm @ X, X.T @ Wm @ G)
            Gs[i], dG[i] = b[0], b[1]
        except np.linalg.LinAlgError:
            Gs[i] = dG[i] = np.nan
    return Gs, np.maximum(dG, 0.0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--proc", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--probes", required=True)
    ap.add_argument("--annot", required=True)
    ap.add_argument("--reference", default="results/cumulative_remodelling_primary.csv")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--nboot", type=int, default=300)
    ap.add_argument("--discovery-beta", default="results/beta_matrix.npy")
    args = ap.parse_args()

    pren = load_meta(args.meta)
    print(f"[info] GSE74193 prenatal control QC-pass arrays: {len(pren)} "
          f"from {pren['brnum'].nunique()} subjects", flush=True)
    print(f"[info] pcw values: {sorted(pren['pcw'].round(2).unique().tolist())}",
          flush=True)

    st = np.load(args.probes, allow_pickle=True)
    annot = pd.read_csv(args.annot, low_memory=False).set_index("probe_id")
    annot = annot.reindex(st["probe_id"])
    ok = (annot["sex_chrom"].to_numpy() == 0) & (annot["has_snp"].to_numpy() == 0)
    probe_keep = set(np.asarray(st["probe_id"])[ok].tolist())
    print(f"[info] target probe set: {len(probe_keep)}", flush=True)

    tags = pren["sample_tag"].tolist()
    ids, B = stream_betas(args.proc, tags, probe_keep)
    print(f"[info] matrix {B.shape} (probes x arrays)", flush=True)

    # collapse technical replicates of the same subject at the same age
    pren = pren.reset_index(drop=True)
    key = pren["brnum"].astype(str) + "_" + pren["pcw"].round(3).astype(str)
    uniq = key.unique()
    Bs = np.empty((B.shape[0], len(uniq)), dtype=np.float32)
    pcw_s = np.empty(len(uniq)); plate_s = []
    comp_cols = [c for c in pren.columns if c.startswith("comp_")]
    comps = np.empty((len(uniq), len(comp_cols)))
    for j, k in enumerate(uniq):
        sel = np.where((key == k).to_numpy())[0]
        Bs[:, j] = np.nanmean(B[:, sel], axis=1)
        pcw_s[j] = pren["pcw"].to_numpy()[sel][0]
        plate_s.append(pren["plate"].to_numpy()[sel][0])
        comps[j] = pd.to_numeric(
            pren.iloc[sel][comp_cols].mean(), errors="coerce").to_numpy()
    print(f"[info] {Bs.shape[1]} unique subject-age samples", flush=True)

    # a complete-case probe set keeps every weekly bin estimable
    good = np.all(np.isfinite(Bs), axis=1)
    Bs = Bs[good].astype(np.float64); ids = ids[good]
    print(f"[info] probes retained after missingness filter: {Bs.shape[0]}",
          flush=True)

    # Adaptive binning: merge consecutive weeks until each bin holds at least
    # MIN_N donors, because a bin of one donor has no estimable within-bin
    # variance and therefore no noise correction.
    MIN_N = 4
    order = np.argsort(pcw_s)
    members, cur = [], []
    for j in order:
        cur.append(j)
        if len(cur) >= MIN_N:
            members.append(np.array(cur)); cur = []
    if cur:
        if members:
            members[-1] = np.concatenate([members[-1], np.array(cur)])
        else:
            members.append(np.array(cur))
    weeks = np.array([pcw_s[m].mean() for m in members])
    bn = np.array([len(m) for m in members], dtype=float)
    print(f"[info] adaptive bins (centres) {np.round(weeks,2).tolist()} "
          f"with n {bn.astype(int).tolist()}", flush=True)

    def run(mat, members_):
        bm, bv, bnx = binned(mat, members_)
        D2 = distance2(bm, bv, bnx)
        pairs = [(a, b) for a in range(len(members_)) for b in range(a + 1, len(members_))]
        w = np.array([2 * bnx[a] * bnx[b] / (bnx[a] + bnx[b]) for a, b in pairs])
        G, r2 = fit_monotone(D2, w, len(members_))
        return G, r2, D2

    grid = np.arange(weeks[0], weeks[-1] + 1e-9, 0.25)
    G, r2, D2 = run(Bs, members)
    Gs, Phi = smooth_derivative(weeks, G, grid)
    print(f"[info] GSE74193 monotone embedding R2 = {r2:.4f}", flush=True)
    print(f"[info] G(t) = {np.round(G,5).tolist()}", flush=True)
    print(f"[info] Phi: {dict(zip(np.round(grid[::4],1), np.round(Phi[::4],5)))}",
          flush=True)

    # ---- composition-adjusted variant -----------------------------------
    cvalid = np.all(np.isfinite(comps), axis=0)
    Xc = comps[:, cvalid]
    print(f"[info] composition covariates used: "
          f"{[c for c, k in zip(comp_cols, cvalid) if k]}", flush=True)
    Q = np.hstack([np.ones((Xc.shape[0], 1)), Xc])
    coef, *_ = np.linalg.lstsq(Q, (Bs - Bs.mean(axis=1, keepdims=True)).T, rcond=None)
    resid = (Bs - Bs.mean(axis=1, keepdims=True)).T - Q @ coef
    Badj = (resid.T + Bs.mean(axis=1, keepdims=True))
    Ga, r2a, _ = run(Badj, members)
    _, Phia = smooth_derivative(weeks, Ga, grid)
    print(f"[info] composition-adjusted R2 = {r2a:.4f}, "
          f"G_total {Ga[-1]:.5f} vs unadjusted {G[-1]:.5f}", flush=True)

    # composition itself vs age
    for j, c in enumerate([c for c, k in zip(comp_cols, cvalid) if k]):
        r = np.corrcoef(pcw_s, Xc[:, j])[0, 1]
        print(f"[info]   {c}: correlation with pcw r = {r:+.3f}", flush=True)

    # ---- bootstrap -------------------------------------------------------
    rng = np.random.default_rng(RNG_SEED)
    Pb = []
    for it in range(args.nboot):
        res = [rng.choice(m, size=len(m), replace=True) if len(m) > 1 else m
               for m in members]
        try:
            Gx, _, _ = run(Bs, res)
            _, Px = smooth_derivative(weeks, Gx, grid)
            Pb.append(Px)
        except Exception:                                        # noqa: BLE001
            continue
    Pb = np.asarray(Pb)

    # ---- per-probe developmental slope replication ----------------------
    # The strongest binning-free replication test: do the same CpGs change in
    # the same direction and at the same rate in both cohorts, over the window
    # the two datasets share?
    def probe_slopes(mat, ages):
        xc = ages - ages.mean()
        sxx = float(np.dot(xc, xc))
        return (mat - mat.mean(axis=1, keepdims=True)) @ xc / sxx

    slope_ind = probe_slopes(Bs, pcw_s)
    slope_rep = None
    if os.path.exists(args.discovery_beta) and os.path.exists(args.probes):
        stq = np.load(args.probes, allow_pickle=True)
        pcw_d = stq["pcw"].astype(float)
        annot_all = pd.read_csv(args.annot, low_memory=False).set_index("probe_id")
        annot_all = annot_all.reindex(stq["probe_id"])
        okq = ((annot_all["sex_chrom"].to_numpy() == 0)
               & (annot_all["has_snp"].to_numpy() == 0))
        pid_d = np.asarray(stq["probe_id"])[okq]
        Bd = np.load(args.discovery_beta, mmap_mode="r")
        Bd = np.ascontiguousarray(Bd[okq], dtype=np.float64)
        win = (pcw_d >= weeks.min() - 0.6) & (pcw_d <= weeks.max() + 0.6)
        print(f"[info] discovery donors inside the shared window "
              f"{weeks.min():.1f}-{weeks.max():.1f} pcw: {int(win.sum())}",
              flush=True)
        slope_d_all = probe_slopes(Bd[:, win], pcw_d[win])
        pos = {p: i for i, p in enumerate(pid_d.tolist())}
        sel = np.array([pos[p] for p in ids if p in pos])
        keep_ind = np.array([i for i, p in enumerate(ids) if p in pos])
        a = slope_ind[keep_ind]; b = slope_d_all[sel]
        pr = float(np.corrcoef(a, b)[0, 1])
        ra = np.argsort(np.argsort(a)); rb = np.argsort(np.argsort(b))
        sr = float(np.corrcoef(ra, rb)[0, 1])
        conc = float(np.mean(np.sign(a) == np.sign(b)))
        # restrict to CpGs with a clear developmental signal in the discovery set
        strong = np.abs(b) > np.percentile(np.abs(b), 90)
        pr_s = float(np.corrcoef(a[strong], b[strong])[0, 1])
        conc_s = float(np.mean(np.sign(a[strong]) == np.sign(b[strong])))
        print(f"[result] per-probe slope replication on {len(a)} CpGs: "
              f"Pearson r = {pr:.3f}, Spearman rho = {sr:.3f}, "
              f"sign concordance = {conc:.3f}", flush=True)
        print(f"[result] restricted to the top decile of discovery effect size: "
              f"Pearson r = {pr_s:.3f}, sign concordance = {conc_s:.3f}",
              flush=True)
        slope_rep = {"n_probes": int(len(a)), "pearson_r": pr,
                     "spearman_rho": sr, "sign_concordance": conc,
                     "pearson_r_top_decile": pr_s,
                     "sign_concordance_top_decile": conc_s,
                     "n_discovery_donors_in_window": int(win.sum())}
        del Bd

    # ---- comparison with the discovery cohort ---------------------------
    out = {"n_arrays": int(len(pren)), "n_samples": int(Bs.shape[1]),
           "n_subjects": int(pren["brnum"].nunique()),
           "n_probes": int(Bs.shape[0]), "r2_embedding": float(r2),
           "r2_embedding_composition_adjusted": float(r2a),
           "G_total": float(G[-1]), "G_total_adj": float(Ga[-1]),
           "weeks": weeks.tolist(), "G": G.tolist(), "G_adj": Ga.tolist(),
           "bin_n": bn.astype(int).tolist()}
    if slope_rep is not None:
        out["slope_replication"] = slope_rep

    if os.path.exists(args.reference):
        ref = pd.read_csv(args.reference)
        lo, hi = max(grid[0], ref["pcw"].min()), min(grid[-1], ref["pcw"].max())
        gg = np.arange(lo, hi + 1e-9, 0.25)
        a = np.interp(gg, grid, Phi)
        b = np.interp(gg, ref["pcw"].to_numpy(), ref["Phi"].to_numpy())
        pr = float(np.corrcoef(a, b)[0, 1])
        sr = float(np.corrcoef(np.argsort(np.argsort(a)),
                               np.argsort(np.argsort(b)))[0, 1])
        # permutation test on the Spearman correlation of the profiles
        rngp = np.random.default_rng(RNG_SEED)
        null = []
        for _ in range(10000):
            bp = rngp.permutation(b)
            null.append(np.corrcoef(np.argsort(np.argsort(a)),
                                    np.argsort(np.argsort(bp)))[0, 1])
        p = float((np.sum(np.abs(null) >= abs(sr)) + 1) / (len(null) + 1))
        print(f"[result] replication over {lo:.1f}-{hi:.1f} pcw: "
              f"Pearson r = {pr:.3f}, Spearman rho = {sr:.3f}, "
              f"permutation p = {p:.4g}", flush=True)
        out.update({"overlap_pcw": [float(lo), float(hi)],
                    "pearson_r": pr, "spearman_rho": sr, "perm_p": p})
        # both cohorts should show acceleration across the shared window
        out["slope_independent"] = float(np.polyfit(gg, a, 1)[0])
        out["slope_discovery"] = float(np.polyfit(gg, b, 1)[0])
        print(f"[result] d(Phi)/d(pcw) over overlap: independent "
              f"{out['slope_independent']:+.5f}, discovery "
              f"{out['slope_discovery']:+.5f} per week^2", flush=True)

    os.makedirs(args.outdir, exist_ok=True)
    pd.DataFrame({
        "pcw": grid, "G_smooth": Gs, "Phi": Phi, "Phi_comp_adj": Phia,
        "Phi_lo95": np.percentile(Pb, 2.5, axis=0) if Pb.size else np.nan,
        "Phi_hi95": np.percentile(Pb, 97.5, axis=0) if Pb.size else np.nan,
    }).to_csv(os.path.join(args.outdir, "independent_cohort_remodelling.csv"),
              index=False)
    pd.DataFrame(np.sqrt(np.maximum(D2, 0)), index=np.round(weeks, 2),
                 columns=np.round(weeks, 2)).to_csv(
        os.path.join(args.outdir, "independent_cohort_distance.csv"))
    import json
    with open(os.path.join(args.outdir, "independent_cohort_summary.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    np.savez_compressed(
        os.path.join(args.outdir, "independent_cohort.npz"),
        weeks=weeks, G=G, G_adj=Ga, grid=grid, Phi=Phi, Phi_adj=Phia,
        Phi_boot=Pb, D2=D2, bn=bn, pcw_samples=pcw_s, comps=Xc,
        comp_names=np.array([c for c, k in zip(comp_cols, cvalid) if k]),
    )
    print("[done] wrote independent_cohort_*.csv/.json/.npz", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
