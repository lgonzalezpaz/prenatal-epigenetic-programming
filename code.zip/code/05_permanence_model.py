#!/usr/bin/env python3
"""
05_permanence_model.py

The inducibility-retention decomposition of fetal epigenetic vulnerability.

Framework
---------
An environmental perturbation delivered at gestational time tau leaves a
permanent epigenetic trace only if it is both inducible, meaning the
methylation machinery is actively writing at tau so that a transient change in
enzyme flux displaces the locus, and retained, meaning the displacement is not
erased before the end of the developmental period. Writing the normalised
probability that a standardised perturbation at tau survives to horizon T as
the permanence kernel P(tau),

    P(tau) = S(tau) . R(tau),                                              (1)
    R(tau) = exp( - int_tau^T k(t) dt ),                                   (2)

with S inducibility and k the local relaxation rate of the epigenetic state.
Differentiating (1) and setting the derivative to zero gives

    k(tau*) = - d ln S / d tau |_{tau*}.                                   (3)

The permanence window therefore sits where the relaxation rate has fallen to
the fractional rate of decline of inducibility. It is neither the period of
maximal plasticity, where S is large but k is also large, nor the end of
gestation, where k is small but S has already collapsed.

Empirical anchoring
-------------------
Both factors are tied to measurement rather than to enzyme mRNA abundance.

S(tau) is the remodelling intensity Phi(tau) measured in 408,608 CpGs across
179 human fetal brains (GSE58885; script 04b). A locus that is being actively
rewritten is a locus whose machinery is engaged at that locus and therefore
perturbable; one that is static is not.

k(t) has two terms. Replicative dilution contributes rho_0 psi_P(t), where
psi_P is the BrainSpan proliferation profile and rho_0 the peak dilution rate,
with a prior from measured maintenance fidelity (0.960, Laird et al. 2004;
0.90-0.98 across sites, Genereux et al. 2005; 0.976 after correction for
bisulfite error, Fu et al. 2010) combined with primate cortical cell-cycle
lengths (22.7-54.1 h, Kornack and Rakic 1998). Enzymatic turnover contributes
eta Phi(t) / (mbar (1 - mbar)): for a two-state locus at equilibrium the gross
flux equals k mbar (1 - mbar), so the measured net drift divided by
mbar (1 - mbar) is a lower bound on the enzymatic relaxation rate, and eta >= 1
is the gross-to-net flux ratio. Cooperative stabilisation of the methylated
state (Haerter et al. 2014; Lovkvist et al. 2016) enters as a multiplicative
reduction of k.

This parameterisation deliberately avoids using machinery mRNA to predict
remodelling flux, because the two do not agree (reported as a result).

Uncertainty is propagated by Monte Carlo over the priors and over the
donor-level bootstrap replicates of Phi, and a variance-based global
sensitivity analysis attributes the spread of tau* to individual parameters.
Beyond the last well-sampled methylation bin the behaviour of S is unknown, so
the primary peak search is confined to the measured window and the consequences
of alternative extrapolations are reported separately.

Usage:
  python 05_permanence_model.py --remodelling results/cumulative_remodelling_primary.csv \
      --genes results/brainspan_genes.csv --modules results/brainspan_modules.csv \
      --outdir results [--ndraw 20000]
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd

RNG_SEED = 20261027

MOD_DENOVO = ["DNMT3A", "DNMT3B"]
MOD_DEMETH = ["TET1", "TET2", "TET3", "TDG"]
MOD_READER = ["MECP2", "MBD1", "MBD2", "MBD3", "MBD4", "ZBTB33"]
MOD_MAINT = ["DNMT1", "UHRF1"]

GRID_LO, GRID_HI, GRID_STEP = 8.0, 40.0, 0.25
MIN_N_PER_WEEK = 3
# primary peak search window: inside the measured methylation range
SEARCH_LO, SEARCH_HI = 9.0, 20.0


def kernel_smooth(x, y, w, grid, bw):
    d = (grid[:, None] - x[None, :]) / bw
    K = np.exp(-0.5 * d * d) * w[None, :]
    return (K @ y) / np.maximum(K.sum(axis=1), 1e-12)


def build_activities(genes_csv, modules_csv, grid, bw=2.0):
    g = pd.read_csv(genes_csv)
    mod = pd.read_csv(modules_csv)
    n_by_week = mod.set_index("pcw")["n_samples"].to_dict()
    piv = g.pivot_table(index="gene", columns="pcw", values="log2_rpkm_mean")
    weeks = np.array([w for w in piv.columns if n_by_week.get(w, 0) >= MIN_N_PER_WEEK])
    wts = np.array([n_by_week[w] for w in weeks], dtype=float)
    cc = mod[mod["pcw"].isin(weeks)].sort_values("pcw")

    def smooth_norm(vals_log2):
        centred = vals_log2 - np.average(vals_log2, weights=wts)
        sm = kernel_smooth(weeks, np.power(2.0, centred), wts, grid, bw)
        sm = np.maximum(sm, 1e-6)
        return sm / sm.max()

    out = {"prolif": smooth_norm(cc["cell_cycle"].to_numpy()),
           "weeks_used": weeks, "weights": wts}
    for name, genes in (("denovo", MOD_DENOVO), ("demeth", MOD_DEMETH),
                        ("reader", MOD_READER), ("maint", MOD_MAINT)):
        present = [x for x in genes if x in piv.index]
        sub = piv.loc[present, weeks]
        rel = sub.sub(np.average(sub.to_numpy(), axis=1, weights=wts), axis=0)
        out[name] = smooth_norm(rel.mean(axis=0).to_numpy())
    return out


def build_inducibility(obs_pcw, obs_phi, grid, gamma_tail):
    """Measured remodelling intensity on the grid, with a declining extension.

    Inside the measured range S is a light smooth of the measured Phi. Beyond
    each edge S continues from the boundary value with exponential decay at rate
    gamma_tail, so the extension is continuous and monotonically decreasing
    rather than being free to rise.
    """
    lo, hi = obs_pcw.min(), obs_pcw.max()
    S = np.interp(grid, obs_pcw, obs_phi)
    S = kernel_smooth(grid, S, np.ones_like(grid), grid, 0.5)
    s_hi = float(np.interp(hi, obs_pcw, obs_phi))
    s_lo = float(np.interp(lo, obs_pcw, obs_phi))
    above = grid > hi
    below = grid < lo
    S = np.where(above, s_hi * np.exp(-gamma_tail * (grid - hi)), S)
    S = np.where(below, s_lo * np.exp(-gamma_tail * (lo - grid)), S)
    return np.maximum(S, 1e-10), (lo, hi)


def relaxation_rate(grid, act, S, mbar, rho0, eta, c_coop):
    """k(t) = replicative dilution + enzymatic turnover, less cooperative hold."""
    k_rep = rho0 * act["prolif"]
    k_enz = eta * S / max(mbar * (1.0 - mbar), 1e-6)
    coop = c_coop * act["reader"] / act["reader"].max()
    return np.maximum((k_rep + k_enz) * (1.0 - coop), 1e-8), k_rep, k_enz


def permanence(grid, S, k, horizon):
    step = grid[1] - grid[0]
    inT = grid <= horizon
    cum = np.cumsum(np.where(inT, k, 0.0)) * step
    total = cum[inT][-1]
    R = np.where(inT, np.exp(-(total - cum)), np.nan)
    return R, S * R


def peak_of(grid, P, lo, hi):
    sel = (grid >= lo) & (grid <= hi) & np.isfinite(P)
    gs, ps = grid[sel], P[sel]
    if gs.size < 3:
        return float("nan")
    i = int(np.argmax(ps))
    if 0 < i < len(gs) - 1:
        y0, y1, y2 = ps[i - 1], ps[i], ps[i + 1]
        den = y0 - 2 * y1 + y2
        d = 0.5 * (y0 - y2) / den if abs(den) > 1e-18 else 0.0
        return float(gs[i] + float(np.clip(d, -1, 1)) * (gs[1] - gs[0]))
    return float(gs[i])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--remodelling", default="results/cumulative_remodelling_primary.csv")
    ap.add_argument("--genes", default="results/brainspan_genes.csv")
    ap.add_argument("--modules", default="results/brainspan_modules.csv")
    ap.add_argument("--profiles", default="results/empirical_profiles.npz")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--ndraw", type=int, default=20000)
    ap.add_argument("--horizon", type=float, default=40.0)
    args = ap.parse_args()

    grid = np.arange(GRID_LO, GRID_HI + 1e-9, GRID_STEP)
    rem = pd.read_csv(args.remodelling)
    obs_pcw = rem["pcw"].to_numpy()
    obs_phi = rem["Phi"].to_numpy()
    prof = np.load(args.profiles, allow_pickle=True)
    mbar = float(np.nanmean(prof["mean_beta"]))
    print(f"[info] measured Phi on {obs_pcw.min():.2f}-{obs_pcw.max():.2f} pcw, "
          f"peak {obs_pcw[int(np.nanargmax(obs_phi))]:.2f} pcw; "
          f"mean beta = {mbar:.4f}", flush=True)

    act = build_activities(args.genes, args.modules, grid)
    print(f"[info] BrainSpan weeks used: {act['weeks_used'].tolist()}", flush=True)

    # ---- reported negative control: does machinery mRNA predict Phi? ----
    psi_E = 0.5 * act["denovo"] + 0.5 * act["demeth"]
    psi_E /= psi_E.max()
    inside = (grid >= obs_pcw.min()) & (grid <= obs_pcw.max())
    phi_on_grid = np.interp(grid, obs_pcw, obs_phi)
    a, b = phi_on_grid[inside], psi_E[inside]
    r_mrna = float(np.corrcoef(a, b)[0, 1])
    rho_mrna = float(np.corrcoef(np.argsort(np.argsort(a)),
                                 np.argsort(np.argsort(b)))[0, 1])
    r_prolif = float(np.corrcoef(a, act["prolif"][inside])[0, 1])
    print(f"[result] machinery mRNA vs measured remodelling intensity: "
          f"Pearson r = {r_mrna:.3f}, Spearman rho = {rho_mrna:.3f}; "
          f"proliferation vs Phi r = {r_prolif:.3f}", flush=True)

    # terminal decline rate of the measured Phi (used for the tail extension)
    tail = obs_pcw >= obs_pcw[int(np.nanargmax(obs_phi))]
    tp, tphi = obs_pcw[tail], np.maximum(obs_phi[tail], 1e-8)
    gamma_hat = float(-np.polyfit(tp, np.log(tphi), 1)[0])
    print(f"[info] terminal decline rate of Phi: gamma = {gamma_hat:.3f} /week",
          flush=True)

    # ---- priors ----------------------------------------------------------
    rng = np.random.default_rng(RNG_SEED)
    N = args.ndraw

    def lognorm_range(lo, hi, size):
        mu = 0.5 * (np.log(lo) + np.log(hi))
        sd = (np.log(hi) - np.log(lo)) / (2 * 1.959964)
        return np.exp(rng.normal(mu, sd, size))

    rho0 = lognorm_range(0.076, 0.30, N)      # week^-1, literature anchored
    eta = lognorm_range(1.0, 10.0, N)         # gross-to-net flux ratio
    c_coop = rng.uniform(0.0, 0.5, N)
    horizon = rng.uniform(37.0, 42.0, N)
    gamma = lognorm_range(max(gamma_hat * 0.4, 0.05), gamma_hat * 2.5, N)

    # bootstrap replicates of Phi, resampled alongside the parameters
    boot_lo = rem["Phi_lo95"].to_numpy(); boot_hi = rem["Phi_hi95"].to_numpy()
    sd_phi = np.maximum((boot_hi - boot_lo) / (2 * 1.959964), 1e-6)

    peaks = np.empty(N)
    peaks_free = np.empty(N)
    Psamp, Rsamp, ksamp = [], [], []
    for i in range(N):
        phi_i = np.maximum(obs_phi + rng.normal(0, sd_phi), 1e-8)
        S_i, _ = build_inducibility(obs_pcw, phi_i, grid, gamma[i])
        k_i, _, _ = relaxation_rate(grid, act, S_i, mbar, rho0[i], eta[i], c_coop[i])
        R_i, P_i = permanence(grid, S_i, k_i, horizon[i])
        peaks[i] = peak_of(grid, P_i, SEARCH_LO, SEARCH_HI)
        peaks_free[i] = peak_of(grid, P_i, GRID_LO + 1.0, 36.0)
        if i < 400:
            Psamp.append(P_i); Rsamp.append(R_i); ksamp.append(k_i)
        if (i + 1) % 5000 == 0:
            print(f"[info] draw {i+1}/{N}", flush=True)

    ok = np.isfinite(peaks)
    q = np.percentile(peaks[ok], [2.5, 25, 50, 75, 97.5])
    print(f"\n[result] permanence window peak: median {q[2]:.2f} pcw, "
          f"95% CI [{q[0]:.2f}, {q[4]:.2f}], IQR [{q[1]:.2f}, {q[3]:.2f}]",
          flush=True)
    okf = np.isfinite(peaks_free)
    qf = np.percentile(peaks_free[okf], [2.5, 50, 97.5])
    frac_late = float(np.mean(peaks_free[okf] > 20.0))
    print(f"[result] unconstrained search: median {qf[1]:.2f} pcw, "
          f"95% CI [{qf[0]:.2f}, {qf[2]:.2f}]; fraction of draws placing the "
          f"peak after 20 pcw = {frac_late:.3f}", flush=True)

    # ---- central estimate ------------------------------------------------
    cen = dict(rho0=float(np.median(rho0)), eta=float(np.median(eta)),
               c_coop=0.25, gamma=gamma_hat)
    S_c, meas_range = build_inducibility(obs_pcw, obs_phi, grid, cen["gamma"])
    k_c, k_rep, k_enz = relaxation_rate(grid, act, S_c, mbar, cen["rho0"],
                                        cen["eta"], cen["c_coop"])
    R_c, P_c = permanence(grid, S_c, k_c, args.horizon)
    peak_c = peak_of(grid, P_c, SEARCH_LO, SEARCH_HI)
    dlnS = np.gradient(np.log(S_c), grid)
    j = int(np.argmin(np.abs(grid - peak_c)))
    print(f"[check] equation (3) at tau* = {peak_c:.2f} pcw: "
          f"k = {k_c[j]:.4f} /week vs -dlnS/dtau = {-dlnS[j]:.4f} /week",
          flush=True)
    Pn = P_c / np.nanmax(P_c)
    inw = np.where(np.isfinite(Pn) & (Pn >= 0.5))[0]
    print(f"[result] half-maximum permanence window: "
          f"{grid[inw[0]]:.1f}-{grid[inw[-1]]:.1f} pcw", flush=True)
    print(f"[info] retention at the peak R(tau*) = {R_c[j]:.3f}; "
          f"R(9 pcw) = {R_c[int(np.argmin(np.abs(grid-9)))]:.3f}; "
          f"R(12 pcw) = {R_c[int(np.argmin(np.abs(grid-12)))]:.3f}", flush=True)

    # ---- global sensitivity ---------------------------------------------
    names = ["rho0", "eta", "c_coop", "horizon", "gamma"]
    X = np.column_stack([rho0, eta, c_coop, horizon, gamma])[ok]
    y = peaks[ok]
    sens = {}
    nbin = 12
    for i_, nm in enumerate(names):
        xs = X[:, i_]
        edges = np.percentile(xs, np.linspace(0, 100, nbin + 1)); edges[-1] += 1e-9
        idx = np.clip(np.digitize(xs, edges) - 1, 0, nbin - 1)
        means = np.array([y[idx == b].mean() if np.sum(idx == b) > 5 else np.nan
                          for b in range(nbin)])
        cnt = np.array([np.sum(idx == b) for b in range(nbin)], float)
        m = np.isfinite(means)
        wbar = np.average(means[m], weights=cnt[m])
        sens[nm] = float(np.average((means[m] - wbar) ** 2, weights=cnt[m]) / y.var())
    print("\n[sensitivity] first-order effect indices on tau*:")
    for nm in names:
        print(f"   {nm:8s} {sens[nm]:.3f}")

    # ---- outputs ---------------------------------------------------------
    os.makedirs(args.outdir, exist_ok=True)
    pd.DataFrame({
        "pcw": grid, "psi_prolif": act["prolif"], "psi_denovo": act["denovo"],
        "psi_demeth": act["demeth"], "psi_reader": act["reader"],
        "psi_maint": act["maint"], "psi_E": psi_E,
        "inducibility_S": S_c, "k_relax": k_c, "k_replicative": k_rep,
        "k_enzymatic": k_enz, "retention_R": R_c, "permanence_P": P_c,
        "permanence_P_norm": Pn,
        "measured": ((grid >= meas_range[0]) & (grid <= meas_range[1])).astype(int),
    }).to_csv(os.path.join(args.outdir, "permanence_kernel.csv"), index=False)

    np.savez_compressed(
        os.path.join(args.outdir, "permanence_mc.npz"),
        grid=grid, peaks=peaks, peaks_free=peaks_free, rho0=rho0, eta=eta,
        c_coop=c_coop, horizon=horizon, gamma=gamma,
        P_sample=np.asarray(Psamp), R_sample=np.asarray(Rsamp),
        k_sample=np.asarray(ksamp), S=S_c, k_cen=k_c, P_cen=P_c, R_cen=R_c,
        psi_prolif=act["prolif"], psi_denovo=act["denovo"],
        psi_demeth=act["demeth"], psi_reader=act["reader"], psi_maint=act["maint"],
    )
    summary = {
        "peak_pcw_median": float(q[2]), "peak_pcw_ci95": [float(q[0]), float(q[4])],
        "peak_pcw_iqr": [float(q[1]), float(q[3])], "peak_pcw_central": float(peak_c),
        "peak_unconstrained_median": float(qf[1]),
        "peak_unconstrained_ci95": [float(qf[0]), float(qf[2])],
        "fraction_draws_peak_after_20pcw": frac_late,
        "halfmax_window_pcw": [float(grid[inw[0]]), float(grid[inw[-1]])],
        "measured_phi_peak_pcw": float(obs_pcw[int(np.nanargmax(obs_phi))]),
        "machinery_mrna_vs_phi_pearson_r": r_mrna,
        "machinery_mrna_vs_phi_spearman_rho": rho_mrna,
        "proliferation_vs_phi_pearson_r": r_prolif,
        "gamma_terminal_decline_per_week": gamma_hat,
        "k_at_peak_per_week": float(k_c[j]),
        "neg_dlnS_dtau_at_peak_per_week": float(-dlnS[j]),
        "retention_at_peak": float(R_c[j]),
        "mean_beta": mbar, "sensitivity_first_order": sens,
        "n_draws": int(ok.sum()), "horizon_default": args.horizon,
        "search_window": [SEARCH_LO, SEARCH_HI],
        "prior_rho0_range": [0.076, 0.30], "prior_eta_range": [1.0, 10.0],
        "measured_range_pcw": [float(meas_range[0]), float(meas_range[1])],
    }
    with open(os.path.join(args.outdir, "permanence_summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2)
    print("\n[done] wrote permanence_kernel.csv, permanence_mc.npz, "
          "permanence_summary.json", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
