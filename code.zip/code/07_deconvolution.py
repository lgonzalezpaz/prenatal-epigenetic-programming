#!/usr/bin/env python3
"""
07_deconvolution.py

Why a narrow permanence window is not recoverable from conventional
epidemiology, and what would be required to recover it.

Setting
-------
Let V(w) be the permanence kernel over gestational weeks w and E_i(w) the
weekly exposure of pregnancy i. The biologically effective dose is

    Z_i = sum_w V(w) E_i(w),                                               (4)

and risk follows logit Pr(Y_i = 1) = beta_0 + beta Z_i. An analyst who does not
know V must choose a summary of E. Trimester averages and distributed-lag
models are the two standard choices.

Exposure is simulated with the two correlation-generating components that
operate in real cohorts:

    E_i(w) = L_i + A sin(2 pi (theta_i + w/52) + phi) + eps_iw             (5)

L_i is a time-invariant location or household level, which makes exposures in
different trimesters positively correlated; the seasonal term, with conception
date theta_i uniform over the year, makes first- and third-trimester exposures
negatively correlated because they fall about six months apart. Varying the
ratio of A to the standard deviation of L reproduces the whole range of
first-to-third-trimester correlations reported in the literature, from about
-0.76 (Liao et al. 2023, PM2.5, Shanghai) and -0.7 (Kalkbrenner et al. 2015,
PM10) through about +0.2 to +0.54 (McGuinn et al. 2022; Jo et al. 2019).

Analyses applied to each simulated cohort
-----------------------------------------
1. Separate trimester-average logistic regressions, one per trimester.
2. A joint logistic regression containing all three trimester averages.
3. A distributed-lag model: a cubic B-spline basis over weeks, which is the
   basis used by the published week-resolved studies.

Reported for each setting: the apparent window, the sign and significance
pattern across trimesters, the bias of the distributed-lag peak, and the cohort
size required to localise the peak to within a stated tolerance.

Usage:
  python 07_deconvolution.py --kernel results/permanence_kernel.csv --outdir results
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import pandas as pd
from scipy.interpolate import BSpline

RNG_SEED = 20261027
WEEKS = np.arange(1, 38)                  # gestational weeks modelled
T1 = (WEEKS >= 1) & (WEEKS <= 13)
T2 = (WEEKS >= 14) & (WEEKS <= 27)
T3 = (WEEKS >= 28) & (WEEKS <= 37)
PCW_OFFSET = 2.0                          # gestational week = pcw + 2


def spline_basis(x: np.ndarray, n_basis: int = 6, degree: int = 3) -> np.ndarray:
    """Cubic B-spline design matrix over x with equally spaced interior knots."""
    lo, hi = x.min(), x.max()
    n_int = n_basis - degree - 1
    interior = np.linspace(lo, hi, n_int + 2)[1:-1] if n_int > 0 else np.array([])
    knots = np.concatenate([[lo] * (degree + 1), interior, [hi] * (degree + 1)])
    B = np.empty((len(x), n_basis))
    for j in range(n_basis):
        c = np.zeros(n_basis); c[j] = 1.0
        B[:, j] = BSpline(knots, c, degree, extrapolate=False)(x)
    return np.nan_to_num(B)


def irls_logistic(X: np.ndarray, y: np.ndarray, n_iter: int = 30):
    """Maximum-likelihood logistic regression with an intercept, via IRLS."""
    Xd = np.hstack([np.ones((X.shape[0], 1)), X])
    b = np.zeros(Xd.shape[1])
    for _ in range(n_iter):
        eta = Xd @ b
        p = 1.0 / (1.0 + np.exp(-np.clip(eta, -30, 30)))
        W = np.maximum(p * (1 - p), 1e-9)
        z = eta + (y - p) / W
        A = Xd.T @ (Xd * W[:, None])
        rhs = Xd.T @ (W * z)
        try:
            b_new = np.linalg.solve(A + 1e-10 * np.eye(A.shape[0]), rhs)
        except np.linalg.LinAlgError:
            break
        if np.max(np.abs(b_new - b)) < 1e-9:
            b = b_new
            break
        b = b_new
    eta = Xd @ b
    p = 1.0 / (1.0 + np.exp(-np.clip(eta, -30, 30)))
    W = np.maximum(p * (1 - p), 1e-9)
    A = Xd.T @ (Xd * W[:, None])
    cov = np.linalg.pinv(A + 1e-10 * np.eye(A.shape[0]))
    return b, cov


def simulate_exposure(n: int, amp: float, sd_loc: float, sd_week: float,
                      rng: np.random.Generator) -> np.ndarray:
    theta = rng.uniform(0, 1, n)[:, None]
    phase = rng.uniform(0, 2 * np.pi, n)[:, None]
    seasonal = amp * np.sin(2 * np.pi * (theta + WEEKS[None, :] / 52.0) + phase)
    loc = rng.normal(0, sd_loc, n)[:, None]
    noise = rng.normal(0, sd_week, (n, len(WEEKS)))
    E = loc + seasonal + noise
    return (E - E.mean()) / E.std()


def tri_corr(E: np.ndarray) -> dict[str, float]:
    a = E[:, T1].mean(axis=1); b = E[:, T2].mean(axis=1); c = E[:, T3].mean(axis=1)
    return {"r_T1T3": float(np.corrcoef(a, c)[0, 1]),
            "r_T1T2": float(np.corrcoef(a, b)[0, 1]),
            "r_T2T3": float(np.corrcoef(b, c)[0, 1])}


def calibrate_amp(target_r13: float, rng: np.random.Generator,
                  sd_week: float = 0.6, n: int = 20000):
    """Choose the seasonal amplitude and location SD giving a target r(T1,T3)."""
    best, best_err = None, np.inf
    for amp in np.linspace(0.0, 2.5, 26):
        for sd_loc in np.linspace(0.05, 2.0, 20):
            E = simulate_exposure(n, amp, sd_loc, sd_week, rng)
            err = abs(tri_corr(E)["r_T1T3"] - target_r13)
            if err < best_err:
                best_err, best = err, (amp, sd_loc)
    return best[0], best[1], best_err


def analyse(E: np.ndarray, y: np.ndarray, basis: np.ndarray):
    """Trimester-average (separate and joint) and distributed-lag analyses."""
    out: dict[str, float] = {}
    tri = {"T1": T1, "T2": T2, "T3": T3}
    Xs = {k: E[:, m].mean(axis=1) for k, m in tri.items()}
    for k, x in Xs.items():
        xs = (x - x.mean()) / x.std()
        b, cov = irls_logistic(xs[:, None], y)
        se = np.sqrt(cov[1, 1])
        out[f"sep_{k}_OR"] = float(np.exp(b[1]))
        out[f"sep_{k}_lo"] = float(np.exp(b[1] - 1.96 * se))
        out[f"sep_{k}_hi"] = float(np.exp(b[1] + 1.96 * se))
    Xj = np.column_stack([(Xs[k] - Xs[k].mean()) / Xs[k].std() for k in tri])
    bj, covj = irls_logistic(Xj, y)
    for i, k in enumerate(tri):
        se = np.sqrt(covj[i + 1, i + 1])
        out[f"joint_{k}_OR"] = float(np.exp(bj[i + 1]))
        out[f"joint_{k}_lo"] = float(np.exp(bj[i + 1] - 1.96 * se))
        out[f"joint_{k}_hi"] = float(np.exp(bj[i + 1] + 1.96 * se))

    # distributed-lag model: project weekly exposure onto the spline basis
    Xd = E @ basis
    Xd = (Xd - Xd.mean(axis=0)) / Xd.std(axis=0)
    bd, covd = irls_logistic(Xd, y)
    coef = bd[1:]
    Cb = covd[1:, 1:]
    scale = (E @ basis).std(axis=0)
    curve = basis @ (coef / scale)
    var = np.einsum("wi,ij,wj->w", basis / scale, Cb, basis / scale)
    se = np.sqrt(np.maximum(var, 0))
    out["dlm_peak_gw"] = float(WEEKS[int(np.argmax(curve))])
    sig = (curve - 1.96 * se) > 0
    out["dlm_sig_weeks"] = ",".join(str(int(w)) for w in WEEKS[sig]) if sig.any() else ""
    out["dlm_sig_lo"] = float(WEEKS[sig].min()) if sig.any() else np.nan
    out["dlm_sig_hi"] = float(WEEKS[sig].max()) if sig.any() else np.nan
    return out, curve, se


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kernel", default="results/permanence_kernel.csv")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--n", type=int, default=60000)
    ap.add_argument("--nrep", type=int, default=20)
    ap.add_argument("--or-per-sd", type=float, default=1.30)
    ap.add_argument("--prevalence", type=float, default=0.02)
    args = ap.parse_args()

    k = pd.read_csv(args.kernel)
    gw = k["pcw"].to_numpy() + PCW_OFFSET
    V = np.interp(WEEKS, gw, np.nan_to_num(k["permanence_P"].to_numpy()))
    V = np.maximum(V, 0.0)
    V = V / V.sum()
    true_peak = float(WEEKS[int(np.argmax(V))])
    cum = np.cumsum(V)
    half = WEEKS[(V >= 0.5 * V.max())]
    print(f"[info] true kernel: peak at gestational week {true_peak:.0f} "
          f"({true_peak - PCW_OFFSET:.0f} pcw); half-maximum "
          f"{half.min()}-{half.max()} GW; "
          f"mass in T1/T2/T3 = {V[T1].sum():.3f}/{V[T2].sum():.3f}/{V[T3].sum():.3f}",
          flush=True)

    rng = np.random.default_rng(RNG_SEED)
    basis = spline_basis(WEEKS.astype(float), n_basis=6)
    beta = np.log(args.or_per_sd)
    b0 = np.log(args.prevalence / (1 - args.prevalence))

    targets = [-0.76, -0.70, -0.40, 0.00, 0.20, 0.40]
    rows, curves = [], {}
    for tgt in targets:
        amp, sd_loc, err = calibrate_amp(tgt, rng)
        acc = []
        curve_acc, se_acc = [], []
        for rep in range(args.nrep):
            E = simulate_exposure(args.n, amp, sd_loc, 0.6, rng)
            Z = E @ V
            Z = (Z - Z.mean()) / Z.std()
            p = 1.0 / (1.0 + np.exp(-(b0 + beta * Z)))
            y = (rng.uniform(size=args.n) < p).astype(float)
            res, curve, se = analyse(E, y, basis)
            res.update(tri_corr(E))
            acc.append(res); curve_acc.append(curve); se_acc.append(se)
        df = pd.DataFrame(acc)
        row = {"target_r_T1T3": tgt, "achieved_r_T1T3": df["r_T1T3"].mean(),
               "r_T1T2": df["r_T1T2"].mean(), "r_T2T3": df["r_T2T3"].mean(),
               "seasonal_amp": amp, "sd_location": sd_loc,
               "n_per_cohort": args.n, "n_cases_mean": float(args.n * args.prevalence)}
        for kk in ("sep_T1", "sep_T2", "sep_T3", "joint_T1", "joint_T2", "joint_T3"):
            row[f"{kk}_OR"] = df[f"{kk}_OR"].mean()
            row[f"{kk}_sig_frac"] = float(np.mean(df[f"{kk}_lo"] > 1.0))
        row["dlm_peak_mean_gw"] = df["dlm_peak_gw"].mean()
        row["dlm_peak_sd_gw"] = df["dlm_peak_gw"].std()
        row["dlm_peak_bias_gw"] = df["dlm_peak_gw"].mean() - true_peak
        row["dlm_sig_lo_mean"] = df["dlm_sig_lo"].mean()
        row["dlm_sig_hi_mean"] = df["dlm_sig_hi"].mean()
        row["dlm_within2wk_frac"] = float(np.mean(np.abs(df["dlm_peak_gw"] - true_peak) <= 2))
        rows.append(row)
        curves[tgt] = (np.mean(curve_acc, axis=0), np.mean(se_acc, axis=0))
        # which trimester an analyst would name, from separate models
        ors = {t: row[f"sep_{t}_OR"] for t in ("T1", "T2", "T3")}
        named = max(ors, key=ors.get)
        print(f"[result] r(T1,T3) = {row['achieved_r_T1T3']:+.2f}: separate-model "
              f"ORs T1 {ors['T1']:.3f}, T2 {ors['T2']:.3f}, T3 {ors['T3']:.3f} "
              f"-> analyst names {named}; DLM peak "
              f"{row['dlm_peak_mean_gw']:.1f} GW (bias "
              f"{row['dlm_peak_bias_gw']:+.1f} wk), apparent significant window "
              f"{row['dlm_sig_lo_mean']:.0f}-{row['dlm_sig_hi_mean']:.0f} GW",
              flush=True)

    res_df = pd.DataFrame(rows)
    res_df.to_csv(os.path.join(args.outdir, "deconvolution_settings.csv"), index=False)

    cdf = {"gestational_week": WEEKS, "true_kernel": V / V.max()}
    for tgt, (c, s) in curves.items():
        cdf[f"dlm_curve_r{tgt:+.2f}"] = c / np.max(np.abs(c))
        cdf[f"dlm_se_r{tgt:+.2f}"] = s / np.max(np.abs(c))
    pd.DataFrame(cdf).to_csv(
        os.path.join(args.outdir, "deconvolution_curves.csv"), index=False)

    # ---- how large must a cohort be to localise the peak? ---------------
    print("\n[info] cohort size required to localise the peak", flush=True)
    amp, sd_loc, _ = calibrate_amp(-0.40, rng)
    power_rows = []
    for n in (10000, 30000, 100000, 300000, 600000, 1000000):
        hits2, hits4, peaks = 0, 0, []
        nrep = int(np.clip(4e6 / n, 24, 120))
        for _ in range(nrep):
            E = simulate_exposure(n, amp, sd_loc, 0.6, rng)
            Z = E @ V; Z = (Z - Z.mean()) / Z.std()
            p = 1.0 / (1.0 + np.exp(-(b0 + beta * Z)))
            y = (rng.uniform(size=n) < p).astype(float)
            res, _, _ = analyse(E, y, basis)
            peaks.append(res["dlm_peak_gw"])
            hits2 += abs(res["dlm_peak_gw"] - true_peak) <= 2
            hits4 += abs(res["dlm_peak_gw"] - true_peak) <= 4
        power_rows.append({"n": n, "n_reps": nrep, "n_cases": n * args.prevalence,
                           "peak_mean_gw": float(np.mean(peaks)),
                           "peak_sd_gw": float(np.std(peaks)),
                           "frac_within_2wk": hits2 / nrep,
                           "frac_within_4wk": hits4 / nrep})
        print(f"   n = {n:>8d} ({int(n*args.prevalence):>6d} cases): "
              f"peak {np.mean(peaks):.1f} +/- {np.std(peaks):.1f} GW, "
              f"within 2 wk {hits2/nrep:.2f}, within 4 wk {hits4/nrep:.2f}",
              flush=True)
    pd.DataFrame(power_rows).to_csv(
        os.path.join(args.outdir, "deconvolution_power.csv"), index=False)

    summary = {
        "true_peak_gw": true_peak, "true_peak_pcw": true_peak - PCW_OFFSET,
        "kernel_halfmax_gw": [int(half.min()), int(half.max())],
        "kernel_mass_T1": float(V[T1].sum()), "kernel_mass_T2": float(V[T2].sum()),
        "kernel_mass_T3": float(V[T3].sum()),
        "or_per_sd": args.or_per_sd, "prevalence": args.prevalence,
        "n_per_cohort": args.n, "n_replicates": args.nrep,
        "settings": rows, "power": power_rows,
    }
    with open(os.path.join(args.outdir, "deconvolution_summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2)
    print("\n[done] wrote deconvolution_settings.csv, deconvolution_curves.csv, "
          "deconvolution_power.csv, deconvolution_summary.json", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
