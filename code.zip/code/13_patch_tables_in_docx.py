#!/usr/bin/env python3
"""
13_patch_tables_in_docx.py

Repairs the table defects in an already-edited manuscript DOCX without
disturbing any other authored content (author list, affiliations, section
numbering, wording).

Three defects are corrected:

1. Table 3 was emitted with a header row and no data. Its generator selected
   rows on (pcw % 1 == 0), but the estimation grid runs in quarter-week steps
   from 8.357 pcw and so never lands on an integer week, selecting nothing.
   Whole-week values are now interpolated from the grid and written into the
   existing table.

2. Tables were numbered out of order: the cross-cohort replication table was
   labelled 8 but appeared fifth, so the document ran 1, 2, 3, 4, 8, 5, 6, 7.
   Labels are remapped 8 -> 5, 5 -> 6, 6 -> 7, 7 -> 8 in captions, callouts and
   in-text citations, which puts them in order of first appearance.

3. Tables 2 and 4 carried captions but were never cited in the text; citations
   are inserted at the points where each is first relevant.

Three whole-week values quoted in the Results are also brought into line with
the interpolated table.

Usage:
  python 13_patch_tables_in_docx.py --in <edited.docx> --out <repaired.docx> \
      --remodelling results/cumulative_remodelling_primary.csv
"""
from __future__ import annotations

import argparse
import re

import numpy as np
import pandas as pd
from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

FONT = "Times New Roman"
BLACK = RGBColor(0, 0, 0)

# label remap that puts tables in order of first appearance
REMAP = {"5": "6", "6": "7", "7": "8", "8": "5"}
SENTINEL = {k: chr(0xE000 + i) for i, k in enumerate(REMAP)}

CAPTIONS = {
    "5": "Table 5. Cross-cohort comparison over the shared gestational window "
         "(12-18 post-conception weeks).",
    "6": "Table 6. Sensitivity of the permanence window to assumptions about "
         "the unmeasured third trimester.",
    "7": "Table 7. A single permanence kernel produces different apparent "
         "windows depending only on the correlation structure of exposure.",
    "8": "Table 8. Cohort size required to localise the permanence window by a "
         "distributed-lag analysis.",
}


def set_cell(cell, text: str, size: float = 8.5, bold: bool = False) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(str(text))
    r.font.name = FONT
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.color.rgb = BLACK
    rpr = r._element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        from docx.oxml import OxmlElement
        rf = OxmlElement("w:rFonts")
        rpr.append(rf)
    for a in ("w:ascii", "w:hAnsi", "w:cs"):
        rf.set(qn(a), FONT)


def replace_in_paragraph(par, pairs: list[tuple[str, str]]) -> int:
    """Replace text run by run, so inline formatting elsewhere is preserved.

    Falls back to collapsing the runs of the paragraph only when a target
    string is split across run boundaries.
    """
    n = 0
    for old, new in pairs:
        if old not in par.text:
            continue
        done = False
        for run in par.runs:
            if old in run.text:
                run.text = run.text.replace(old, new)
                n += 1
                done = True
        if not done:
            # the string straddles runs: rewrite the paragraph text on the
            # first run and blank the others, keeping the first run's format
            full = par.text.replace(old, new)
            if par.runs:
                par.runs[0].text = full
                for r in par.runs[1:]:
                    r.text = ""
                n += 1
    return n


def table3_rows(csv_path: str) -> pd.DataFrame:
    rem = pd.read_csv(csv_path)
    weeks = np.arange(int(np.ceil(rem["pcw"].min())),
                      int(np.floor(rem["pcw"].max())) + 1)
    f = lambda c: np.interp(weeks, rem["pcw"].to_numpy(),
                            rem[c].to_numpy()) * 1e3
    return pd.DataFrame({
        "Post-conception week": weeks,
        "Phi (x10^-3 beta/week)": f("Phi").round(2),
        "95% CI lower": f("Phi_lo95").round(2),
        "95% CI upper": f("Phi_hi95").round(2),
        "Phi, equal n per week": f("Phi_equal_n").round(2),
    })


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--remodelling",
                    default="results/cumulative_remodelling_primary.csv")
    ap.add_argument("--reference", default="manuscript/manuscript.docx",
                    help="verified source DOCX used to restore equation text")
    a = ap.parse_args()

    doc = Document(a.inp)
    report = []

    # ---- 1. fill Table 3 -------------------------------------------------
    df = table3_rows(a.remodelling)
    target = None
    for t in doc.tables:
        hdr = [c.text.strip() for c in t.rows[0].cells]
        if hdr and hdr[0] == "Post-conception week":
            target = t
            break
    if target is None:
        raise RuntimeError("Table 3 not found by its header row")
    if len(target.rows) > 1:
        report.append(f"Table 3 already had {len(target.rows)-1} data rows; "
                      "they were replaced")
        for row in list(target.rows)[1:]:
            row._element.getparent().remove(row._element)
    for _, r in df.iterrows():
        cells = target.add_row().cells
        for j, v in enumerate(r):
            set_cell(cells[j], int(v) if j == 0 else f"{v:.2f}")
    report.append(f"Table 3 filled with {len(df)} data rows "
                  f"({df['Post-conception week'].min()}-"
                  f"{df['Post-conception week'].max()} pcw)")

    # ---- 2. renumber tables ---------------------------------------------
    to_sent = [(f"Table {k}", f"Table {v}") for k, v in SENTINEL.items()]
    from_sent = [(f"Table {v}", f"Table {REMAP[k]}") for k, v in SENTINEL.items()]
    changed = 0
    for par in doc.paragraphs:
        if "Table" in par.text:
            changed += replace_in_paragraph(par, to_sent)
    for par in doc.paragraphs:
        if "Table" in par.text:
            replace_in_paragraph(par, from_sent)
    report.append(f"renumbered table labels in {changed} paragraph runs "
                  "(8->5, 5->6, 6->7, 7->8)")

    # make sure each renumbered caption reads correctly end to end
    for par in doc.paragraphs:
        t = par.text.strip()
        m = re.match(r"^Table ([5-8])\. ", t)
        if m and t != CAPTIONS[m.group(1)]:
            if par.runs:
                par.runs[0].text = CAPTIONS[m.group(1)]
                for r in par.runs[1:]:
                    r.text = ""
                report.append(f"caption of Table {m.group(1)} normalised")

    # ---- 3. whole-week values quoted in the Results ----------------------
    val_pairs = [
        ("rises from 4.0 × 10⁻³", "rises from 3.8 × 10⁻³"),
        ("falls to 5.5 × 10⁻³ by 19 weeks", "falls to 5.9 × 10⁻³ by 19 weeks"),
        ("and 1.2 × 10⁻³ by 21 weeks", "and 1.3 × 10⁻³ by 21 weeks"),
    ]
    hits = sum(replace_in_paragraph(p, val_pairs) for p in doc.paragraphs)
    report.append(f"synchronised {hits} whole-week values with the table")

    # ---- 4. cite Tables 2 and 4 ------------------------------------------
    cites = [
        ("The horizon T was drawn from U(37, 42) post-conception weeks.",
         "The horizon T was drawn from U(37, 42) post-conception weeks. All "
         "parameters, their prior distributions and the measurements each is "
         "based on are listed in Table 2."),
        ("16.10 weeks (Figure 2d).", "16.10 weeks (Figure 2d, Table 4)."),
    ]
    for old, new in cites:
        done = False
        for p in doc.paragraphs:
            if old in p.text:
                replace_in_paragraph(p, [(old, new)])
                done = True
                break
        report.append(("cited " if done else "COULD NOT cite ")
                      + ("Table 2" if "horizon" in old else "Table 4"))

    # ---- 5. restore equation subscript notation -------------------------
    # A Markdown-aware conversion step stripped the underscores and carets that
    # mark subscripts and superscripts, turning for example "exp(-int_tau^T k)"
    # into "exp(-int tau T k)". The verified source text is restored verbatim.
    if a.reference:
        ref = Document(a.reference)
        want = {}
        for par in ref.paragraphs:
            t = par.text.strip()
            m = re.search(r"\((\d)\)$", t)
            if m and "=" in t:
                want[m.group(1)] = t
        fixed = 0
        for par in doc.paragraphs:
            t = par.text.strip()
            m = re.search(r"\((\d)\)$", t)
            if not (m and "=" in t):
                continue
            good = want.get(m.group(1))
            if good and good.replace(" ", "") != t.replace(" ", ""):
                if par.runs:
                    par.runs[0].text = good
                    for r in par.runs[1:]:
                        r.text = ""
                    fixed += 1
        report.append(f"restored subscript notation in {fixed} of "
                      f"{len(want)} equations")

    doc.save(a.out)
    print(f"[done] wrote {a.out}")
    for line in report:
        print("  -", line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
